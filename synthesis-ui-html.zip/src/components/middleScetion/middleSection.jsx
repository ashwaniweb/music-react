import React from 'react';
import './middle.scss'

// Other file call
import DashLeftMenu from '../dashleft';
import DashRightMenu from '../dashright';
import MainDashboard from '../mainDashboard';

class DashBoard extends React.Component {
  render() {
    return (
      <div className="container-mine">
        <div className="mainArea">
          <DashLeftMenu />
          <MainDashboard />
          <DashRightMenu />
        </div>
      </div>
    );
  }
}

export default DashBoard;