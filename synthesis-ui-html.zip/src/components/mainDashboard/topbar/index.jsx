import React from 'react';
import { Navbar, Nav, NavItem, NavDropdown, FormGroup, MenuItem, FormControl } from 'react-bootstrap';
import { IndexLinkContainer } from 'react-router-bootstrap';
import { Link } from 'react-router-dom'
import './topbar.scss';

class Topbar extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      popoverMenu: false,
      subNavbar: false

    };
    this.popoverShow = this.popoverShow.bind(this);
    this.popoverHide = this.popoverHide.bind(this);
    this.subNavbar = this.subNavbar.bind(this);
  }
  popoverShow() {
    this.setState({
      popoverMenu: true
    });
  }

  popoverHide() {
    this.setState({
      popoverMenu: false
    });
  }
  subNavbar(callback) {
    console.log("onclick");
    if (!this.state.subNavbar) {
      this.setState({
        subNavbar: true,
      })
    } else {
      this.setState({
        subNavbar: false
      })
    }
  }

  render() {
    return (
      <div className="navigation">
        <Navbar collapseOnSelect className="nav-synthesis">
          <Navbar.Collapse>
            <Nav>
              <IndexLinkContainer to="/dashboard">
                <NavItem eventKey={1}><i className="icon-dashboard"></i> Dashboard</NavItem>
              </IndexLinkContainer>
              <IndexLinkContainer to="/">
              <NavItem eventKey={2}><i className="icon-myaccount"></i> My Account</NavItem>
              </IndexLinkContainer>
              <IndexLinkContainer to="/">              
              <NavItem eventKey={2}><i className="icon-support"></i> Support</NavItem>
              </IndexLinkContainer>           
            </Nav>
            <Navbar.Header>
              <Navbar.Brand>
                <a href="/"><img src="/images/logo.png" alt="Synthesis Dashboard" /></a>
                <span onClick={this.subNavbar}><i className="icon-app pointer"></i></span>
              </Navbar.Brand>
              <Navbar.Toggle />
            </Navbar.Header>
            <div className="nav navbar-nav navbar-right">
              <FormGroup controlId="formBasicText" className={!this.state.popoverMenu ? "btnGroup" : "btnGroup focus"}>
                <form name="search-message" onSubmit={this.props.handleSearch} autoComplete="off">
                  <FormControl type="text" name="searchInput" placeholder="Search" onBlur={this.popoverHide} value={this.state.search} onFocus={this.popoverShow}></FormControl>
                  <span className="form-control-feedback material-icons">search</span>
                </form>
              </FormGroup>
              <Nav>
                <NavDropdown eventKey={1}
                  title={
                    <img src='/images/avatar.png'  alt="Avatar"/>
                  } id="user-dropdown">
                  <MenuItem eventKey={1.1}>Action</MenuItem>
                  <MenuItem eventKey={1.2}>Another action</MenuItem>
                  <MenuItem eventKey={1.3}>Something else here</MenuItem>
                  <MenuItem divider />
                  <MenuItem eventKey={1.4}>Separated link</MenuItem>
                </NavDropdown>
                <NavItem eventKey={2} href="/"><i className="icon-notifications"></i></NavItem>
                <NavItem eventKey={3} href="/"><i className="icon-settings"></i></NavItem>
              </Nav>
            </div>
          </Navbar.Collapse>
        </Navbar>
        {this.state.subNavbar &&
          <Navbar collapseOnSelect className="nav-synthesis bottom">
            <Navbar.Collapse>
              <Nav>
                <IndexLinkContainer to="/audio">
                  <NavItem eventKey={2}>
                    <i className="material-icons">headset_mic</i> Audio Conferencing
                  </NavItem>
                </IndexLinkContainer>
                <IndexLinkContainer to="/video">
                  <NavItem eventKey={2}><i className="material-icons">ondemand_video</i> Video Conferencing</NavItem>
                </IndexLinkContainer>
                <IndexLinkContainer to="/">
                  <NavItem eventKey={2}><i className='material-icons'>phone_in_talk</i> VoIP Outbound</NavItem>
                </IndexLinkContainer>
                <IndexLinkContainer to="/">
                  <NavItem eventKey={2}><i className="material-icons">assignment_ind</i> Contact Centre</NavItem>
                </IndexLinkContainer>
                <IndexLinkContainer to="/">
                  <NavItem eventKey={2}><i className="material-icons">tv</i> WHITE BOARD</NavItem>
                </IndexLinkContainer>
                <IndexLinkContainer to="/">
                  <NavItem eventKey={2} className='crm'><i className="icon-crm"></i> CRM</NavItem>
                </IndexLinkContainer>
                <IndexLinkContainer to="/">
                  <NavItem eventKey={2}><i className="fa fa-eur" aria-hidden="true"></i> Sales Management</NavItem>
                </IndexLinkContainer>
                <IndexLinkContainer to="/">
                  <NavItem eventKey={2}><i className="material-icons">filter_9_plus</i> MI Number</NavItem>
                </IndexLinkContainer>
                <IndexLinkContainer to="/cloud-telephony">
                  <NavItem eventKey={2}><i className="material-icons">settings_system_daydream</i> Cloud Telephony</NavItem>
                </IndexLinkContainer>
                <IndexLinkContainer to="/">
                  <NavItem eventKey={2}><i className="material-icons">forum</i> Message Centre</NavItem>
                </IndexLinkContainer>
                <IndexLinkContainer to="/">
                  <NavItem eventKey={2}><i className="material-icons">perm_phone_msg</i> IVR</NavItem>
                </IndexLinkContainer>
                <IndexLinkContainer to="/did-management">
                  <NavItem eventKey={2}><i className="material-icons">dialpad</i> DID Management</NavItem>
                </IndexLinkContainer>
              </Nav>
            </Navbar.Collapse>
          </Navbar>
        }
      </div>
    )
  }
}

export default Topbar;
