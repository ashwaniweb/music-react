import React from 'react';
// import { MenuItem } from 'react-bootstrap';
import { ResponsiveContainer, PieChart, Pie, Sector, Cell } from 'recharts';
import './invoice.scss'

const data = [
  { name: 'Group A', value: 700,value2:'Days' },
  { name: 'Group B', value: 200,value2:'Month' },
  { name: 'Group C', value: 100,value2:'Year' }
];

const renderActiveShape = (props) => {
  const RADIAN = Math.PI / 180;
  const { cx, cy, midAngle, innerRadius, outerRadius, startAngle, endAngle, fill, payload, percent, value } = props;
  const sin = Math.sin(-RADIAN * midAngle);
  const cos = Math.cos(-RADIAN * midAngle);
  const sx = cx + (outerRadius + 10) * cos;
  const sy = cy + (outerRadius + 10) * sin;
  const mx = cx + (outerRadius + 30) * cos;
  const my = cy + (outerRadius + 30) * sin;
  const ex = mx + (cos >= 0 ? 1 : -1) * 22;
  const ey = my;
  const textAnchor = cos >= 0 ? 'start' : 'end';

  return (
    <g>
      <text dy={8} textAnchor="middle" >
      <tspan x={cx} y={cy-10} fill={'#4c5e70'} fontFamily={"Source Sans Pro"} fontSize={"21px"} fontWeight={"bold"}>{payload.value}</tspan>
      <tspan x={cx} y={cy+20} fill={'#7b8da0'} fontFamily={"Source Sans Pro"} fontSize={"13px"} fontWeight={"300"}>{payload.value2}</tspan>
      </text>
      <Sector
        cx={cx}
        cy={cy}
        innerRadius={innerRadius}
        outerRadius={outerRadius}
        startAngle={startAngle}
        endAngle={endAngle}
        fill={fill}
      />
    </g>
  );
};
const COLORS = ['#c29cfb', '#c9c9ff', '#ffbdbd'];
const RADIAN = Math.PI / 180;
class DashInvoice extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      getInitialState: true,
      onPieEnter: false

    };
    this.getInitialState = this.getInitialState.bind(this);
    this.onPieEnter      = this.onPieEnter.bind(this);
  }

  getInitialState() {
    this.setState({
      getInitialState: true,
    })
  }
  onPieEnter(data, index) {
    this.setState({
      activeIndex: index
    });
  }

  render() {
    return (
      <div className="ibox">
        <div className="ibox-title">
          <h5>Invoice</h5>
        </div>
        <div className="ibox-content">
          <ResponsiveContainer height={210}>
            <PieChart>
              <Pie
                activeIndex={this.state.activeIndex}
                activeShape={renderActiveShape}
                data={data}
                cx={100} 
                cy={100} 
                innerRadius={60}
                outerRadius={100}
                fill="#8884d8"
                paddingAngle={5}
                stroke={0}
                startAngle={-155}
                onMouseEnter={this.onPieEnter}
                dataKey="value"
              >
                {data.map((entry, index) => <Cell fill={COLORS[index % COLORS.length]} />)
                }
              </Pie>
            </PieChart>
          </ResponsiveContainer>
          <h4 className="top">Next Invoice
            <br/><span>Jan 01, 2018</span>
          </h4>
          <h4>Pending Invoice <span className="pull-right">2,500 INR</span>
          </h4>
          <h4>Paid Invoice <span className="pull-right">15,000 INR</span>
          </h4>
        </div>
      </div>
    );
  }
}

export default DashInvoice;