import React from 'react';
import {BrowserRouter} from 'react-router-dom';
import './myServices.scss'

class MyServices extends React.Component {
  render() {
    return (
      <div className="ibox">
        <div className="ibox-title">
          <h5>My Services</h5>
        </div>
        <div className="ibox-content">
          
          <div className="my-service">
            <ul>
              <li>
                <b>Audio Conferencing</b>
                <small className="active">Active</small>
                <i className="material-icons">keyboard_arrow_right</i>
              </li>
              <li>
                <b>Video Conferencing</b>
                <small className="pending">Pending invoice</small>
                <i className="material-icons">keyboard_arrow_right</i>
              </li>
              <li>
                <b>Voice Over Internet Protocol</b>
                <small className="pending">Pending invoice</small>
                <i className="material-icons">keyboard_arrow_right</i>
              </li>
              <li>
                <b>Interactive Voice Response</b>
                <small className="delay">Delayed</small>
                <i className="material-icons">keyboard_arrow_right</i>
              </li>
            </ul>
          </div>
        </div>
      </div>
    );
  }
}

export default MyServices;