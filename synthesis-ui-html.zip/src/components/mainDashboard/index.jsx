import React from 'react';
// import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';

import { Row, Col, Grid } from 'react-bootstrap';
// import ActivityLog from './activitylog';
import CallUsage from './callUsage';
import MyServices from './myServices';
import FullCalendar from './fullCalendar';
import AccountManager from './accountManager';
import LastLogin from './lastLogin';
// import AudioConferencingDashboard from '../Audio-Conferencing-Service/index';

// import GlobalPopLocation from './globalPopLocation';
import DashInvoice from './Invoice';
import './dashbody.scss'

class MainDashboard extends React.Component {
  render() {
    return (
      <div className="middleArea"> 
        <Grid fluid>
          {/* <Row>
            <Col md={4}>
              <ActivityLog />
            </Col>
            <Col md={6}>
            </Col>
            <Col md={3}>
              <MyServices />
            </Col>
            <Col md={9}>
              <GlobalPopLocation />
            </Col>
          </Row> */}
          <Row>
            <Col md={8}>
              <CallUsage />
            </Col>
            <Col md={4}>
              <LastLogin />
              <MyServices />
            </Col>
          </Row>
          <Row>
            <Col md={4}>
              <AccountManager />
              <DashInvoice />
            </Col>
            <Col md={8}>
              <FullCalendar />
            </Col>
          </Row>
          <Row>
            <Col md={4}>

            </Col>
            <Col md={4}>
              Hello 2
            </Col>
            <Col md={4}>
              Hello 3
            </Col>
          </Row>
        </Grid>
        <div className="clearfix"></div>
      </div>
    );
  }
}

export default MainDashboard;