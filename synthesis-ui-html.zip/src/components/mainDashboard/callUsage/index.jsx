import React from 'react';
import { ButtonToolbar, DropdownButton, MenuItem } from 'react-bootstrap';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip } from 'recharts';
import './callUsage.scss'

const data = [
  { name: 'January', uv: 4000, pv: 2400 },
  { name: 'February', uv: 3000, pv: 1398 },
  { name: 'March', uv: 2000, pv: 9800 },
  { name: 'April', uv: 2780, pv: 3908 },
  { name: 'May', uv: 1890, pv: 4800 },
  { name: 'June', uv: 2390, pv: 3800 },
  { name: 'July', uv: 3490, pv: 4300 },
];

class CallUsage extends React.Component {

  render() {
    return (
      <div className="ibox">
        <div className="ibox-title">
          <h5>Call Usage</h5>
          <div className="barBtn">
            <ButtonToolbar>
              <DropdownButton title="Audio Conferencing" id="dropdown-size-medium">
                <MenuItem eventKey="1">Video Conferencing</MenuItem>
                <MenuItem eventKey="2">Voice Over</MenuItem>
                <MenuItem eventKey="3">Interactive Voice</MenuItem>
                {/* <MenuItem divider />
                <MenuItem eventKey="4">Separated link</MenuItem> */}
              </DropdownButton>
            </ButtonToolbar>
          </div>
        </div>
        <div className="ibox-content">
          <div className="toplegend">
            <div>
              <span><b className="color1"></b></span> Reserved Conference
            </div>
            <div>
              <span><b className="color2"></b></span> UnReserved Conference
            </div>
            <div>
              <span><b className="color3"></b></span> Recurring Conference
            </div>
          </div>
          <ResponsiveContainer height={250}>
            <AreaChart data={data} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
              <XAxis dataKey="name" />
              <YAxis />
              <CartesianGrid stroke='#f1f1f1' />
              <Tooltip />
              <Area type='monotone' dataKey='uv' stackId="1" stroke='#fbbdc0' fill='#ffe5e7' />
              <Area type='monotone' dataKey='pv' stackId="1" stroke='#e5e7e6' fill='#f4fcef' />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    );
  }
}

export default CallUsage;