import React from 'react';
import { Row, Col, Image } from 'react-bootstrap';

import './accountManager.scss'

class AccountManager extends React.Component {
  render() {
    return (
      <div className="ibox">
        <div className="ibox-content">
          <div className="accountHead">
            <Row>
              <Col md={4} className="img">
                <Image src="../images/account-icon.jpg" circle />
              </Col>
              <Col md={8} className="ac-info">
                <h4>Jessica Lopez</h4>
                <p>Account Manager</p>
                <p><i className="material-icons">location_on</i> India, IN</p>
              </Col>
            </Row>
            <hr />
            <Row>
              <Col md={12} className="ac-details">
                <p><i className="material-icons">email</i> jessica.lopez@asergis.in</p>
                <p><i className="material-icons">location_on</i> support@asergis.in</p>
                <p><i className="material-icons">call</i> + 91 (0) 9845562114</p>
                <p><i className="material-icons">phone_iphone</i> + 91 (0) 9845562114</p>
              </Col>
            </Row>
          </div>
        </div>
      </div>
    );
  }
}

export default AccountManager;