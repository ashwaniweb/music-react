import React from 'react';
import Topbar from '../mainDashboard/topbar';
import MiddleSection from '../middleScetion/middleSection';

class DashboardPage extends React.Component {
  render() {
    return (
        <div className="main">
          <Topbar />
          <MiddleSection />
        </div>
    );
  }
}

export default DashboardPage;
