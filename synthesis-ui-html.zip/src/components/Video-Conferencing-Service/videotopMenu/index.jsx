import React from 'react';
import { Button, Navbar, Nav, NavItem, NavDropdown, DropdownButton, FormGroup, MenuItem, FormControl, Col } from 'react-bootstrap';
import { IndexLinkContainer } from 'react-router-bootstrap';
import {
  Link
} from 'react-router-dom'
//import './topMenu.scss';

class AcTopMenu extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      popoverMenu: false,
      subNavbar: false,
      subSubNavbar: false
    };
    this.popoverShow = this.popoverShow.bind(this);
    this.popoverHide = this.popoverHide.bind(this);
    this.subNavbar = this.subNavbar.bind(this);
    this.subSubNavbar = this.subSubNavbar.bind(this);
  }
  popoverShow() {
    this.setState({
      popoverMenu: true
    });
  }
  popoverHide() {
    this.setState({
      popoverMenu: false
    });
  }

  subNavbar() {
    if (!this.state.subNavbar) {
      this.setState({
        subNavbar: true
      })
    } else {
      this.setState({
        subNavbar: false
      })
    }
  }

  subSubNavbar() {
    if (!this.state.subSubNavbar) {
      this.setState({
        subSubNavbar: true
      })
    } else {
      this.setState({
        subSubNavbar: false
      })
    }
  }

  render() {
    return (
      <div className="navigation">
        <Navbar collapseOnSelect className="nav-audioConf">
          <Navbar.Collapse>
            <Nav>
              <Navbar.Brand>
                <Link to="/"><img src="/images/logo.png" alt="Synthesis Dashboard" /></Link>
                <span onClick={this.subNavbar}><i className="icon-app pointer"></i></span>
              </Navbar.Brand>
              <Navbar.Toggle />
            </Nav>
            <Navbar.Header>
              <h1>Video Conference</h1>
            </Navbar.Header>
            <div className="nav navbar-nav navbar-right">
              <FormGroup controlId="formBasicText" className={!this.state.popoverMenu ? "btnGroup" : "btnGroup focus"}>
                <form name="search-message" onSubmit={this.props.handleSearch} autoComplete="off">
                  <FormControl type="text" name="searchInput" placeholder="Search" onBlur={this.popoverHide} value={this.state.search} onFocus={this.popoverShow}></FormControl>
                  <span className="form-control-feedback material-icons">search</span>
                </form>
              </FormGroup>
              <Nav>
                <NavDropdown eventKey={1}
                  title={
                    <img src='/images/avatar.png' alt="Avatar" />
                  } id="user-dropdown">
                  <MenuItem eventKey={1.1}>Action</MenuItem>
                  <MenuItem eventKey={1.2}>Another action</MenuItem>
                  <MenuItem eventKey={1.3}>Something else here</MenuItem>
                  <MenuItem divider />
                  <MenuItem eventKey={1.4}>Separated link</MenuItem>
                </NavDropdown>
                <NavItem eventKey={2} href="/"><i className="icon-notifications"></i></NavItem>
                <NavItem eventKey={3} href="/"><i className="icon-settings"></i></NavItem>
              </Nav>
            </div>
          </Navbar.Collapse>
        </Navbar>
        {this.state.subNavbar &&
          <Navbar collapseOnSelect className="nav-audioConf bottom">
            <Navbar.Collapse>
              <Nav>
                <IndexLinkContainer to="/dashboard">
                  <NavItem eventKey={1}>Dashboard</NavItem>
                </IndexLinkContainer>
                <NavItem eventKey={2} onClick={this.subSubNavbar}>
                  <i className="material-icons">add_circle_outline</i> VC Management
                </NavItem>
                <NavItem eventKey={2}>
                  <i className="material-icons">add_circle_outline</i> Contact Management
                </NavItem>
                <NavItem eventKey={2}>
                  <i className="material-icons">add_circle_outline</i> Account Management
                </NavItem>
                <NavItem eventKey={2}>
                  <i className="material-icons">add_circle_outline</i> Support
                </NavItem>
              </Nav>
            </Navbar.Collapse>
            {this.state.subSubNavbar &&
              <Navbar.Collapse className="thirdlevelMenu">
                <Nav>
                  <IndexLinkContainer to="/video/video-management/create-new-conference">
                    <NavItem eventKey={3}>
                      Create New Video Conference
                    </NavItem>
                  </IndexLinkContainer>
                  <IndexLinkContainer to="/video/video-management/conference-list">
                    <NavItem eventKey={3}>
                      Conference list
                    </NavItem>
                  </IndexLinkContainer>
                  {/* <IndexLinkContainer to="/video/video-management/conference-report">
                    <NavItem eventKey={3}>
                      Conference report
                  </NavItem>
                  </IndexLinkContainer>
                  <IndexLinkContainer to="/video/video-management/live-conference">
                    <NavItem eventKey={3}>
                      live conference
                  </NavItem>
                  </IndexLinkContainer>
                  <IndexLinkContainer to="/video/video-management/video-schedule">
                    <NavItem eventKey={3}>
                      Video schedule
                  </NavItem>
                  </IndexLinkContainer> */}
                </Nav>
              </Navbar.Collapse>
            }
          </Navbar>
        }
      </div>
    )
  }
}

export default AcTopMenu;