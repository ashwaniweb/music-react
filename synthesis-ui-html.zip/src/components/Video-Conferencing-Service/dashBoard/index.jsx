import React from 'react';
import { Route, Switch } from 'react-router-dom';
// Other file call
import DashLeftMenu from '../../dashleft';
import DashRightMenu from '../../dashright';
import CreateNewVideoConference from '../vcManagement/createNewVideoConference';
import ConferenceList from '../vcManagement/conferenceList';
import ConferenceReport from '../vcManagement/conferenceReport';
import RecordingList from '../vcManagement/conferenceList/recordingList';
import ViewConference from '../vcManagement/conferenceList/viewConference';

class VcMiddleSection extends React.Component {
  render() {
    return (
      <div className="container-flud">
        <div className="mainArea">
          <DashLeftMenu />
          <Switch>
            <div className="middleArea">
              <Route exact path="/video/video-management/create-new-conference" component={CreateNewVideoConference} />
              <Route path="/video/video-management/conference-list" component={ConferenceList} />
              <Route path="/video/video-management/conference-report" component={ConferenceReport} />
              <Route path="/video/video-management/recording-list" component={RecordingList} />
              <Route path="/video/video-management/view-conference" component={ViewConference} />
              <div className="clearfix"></div>
            </div>
          </Switch>
          <DashRightMenu />
        </div>
      </div>
    );
  }
}

export default VcMiddleSection;