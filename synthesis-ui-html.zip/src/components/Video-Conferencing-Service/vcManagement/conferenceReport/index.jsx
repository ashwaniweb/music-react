import React from 'react';
import { Row, Col, Table, FormControl, Pagination, FormGroup, InputGroup, Image } from 'react-bootstrap';
import Dropdown from 'react-dropdown';

// Other file call
// import VideoTopMenu from './conferenceReport.scss';

const options = [
  '5', '10', '50', '100'
]
const options2 = [
  'Reserved', 'Un-Reserved'
]

class ConferenceReport extends React.Component {
  render() {
    return (
      <div className="ibox">
        <div className="ibox-title">
          <h5>Conference Report</h5>
        </div>
        <div className="ibox-content">
          <Row className="m-b-15">
            <Col md={6} className="m-b-15 showD">
              <span>Show</span>
              <span className="droptablelist"><Dropdown options={options} onChange={this._onSelect} placeholder="0" /></span>
              <span>entries</span>
            </Col>
            <Col md={6} className="m-b-15">
              <ul className="tableallSearch">
                <li>Search:</li>
                <li>
                  <FormGroup>
                    <InputGroup>
                      <FormControl type="text" placeholder="Search" className="fShadow" />
                      <a href="#" className="input-group-addon">
                        <i className="fa fa-search"></i>
                      </a>
                    </InputGroup>
                  </FormGroup>
                </li>
                <li>
                  <a href="#"><Image responsive src="../../images/tpsd-icon.png"></Image></a>
                </li>
                <li>
                  <a href="#"><Image responsive src="../../images/texcel-icon.png"></Image></a>
                </li>
              </ul>
            </Col>
          </Row>

          <Row className="gTable">
            <Table responsive className="table-bordered">
              <thead>
                <tr>
                  <th className="sorting">Conference Name</th>
                  <th className="sorting">Conference Type</th>
                  <th className="sorting">Total Conference Cost</th>
                  <th>Details</th>
                </tr>
                <tr>
                  <th>
                    <FormControl type="text" placeholder="country" />
                  </th>
                  <th>
                    <Dropdown options={options2} onChange={this._onSelect} placeholder="Select" />
                  </th>
                  <th>
                    <FormControl type="text" placeholder="cost required" />
                  </th>
                  <th>&nbsp;</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>Malta</td>
                  <td>Reserved</td>
                  <td className="text-center">$ 20.00</td>
                  <td>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  </td>
                </tr>
                <tr>
                  <td>Malta</td>
                  <td>Reserved</td>
                  <td className="text-center">$ 20.00</td>
                  <td>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  </td>
                </tr>
                <tr>
                  <td>Malta</td>
                  <td>Un-Reserved</td>
                  <td className="text-center">$ 20.00</td>
                  <td>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  </td>
                </tr>
                <tr>
                  <td>Malta</td>
                  <td>Un-Reserved</td>
                  <td className="text-center">$ 20.00</td>
                  <td>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  </td>
                </tr>
              </tbody>
            </Table>
          </Row>

          <Row>
            <Col md={6} className="allentries">
              Showing 1 to 1 of 1 entries
            </Col>
            <Col md={6}>
              <div className="table-pag">
                <Pagination
                  first='fast_rewind'
                  next='play_arrow'
                  prev='play_arrow'
                  last='fast_forward'
                  ellipsis
                  boundaryLinks
                  items={5}
                  maxButtons={5}
                />
              </div>
            </Col>
          </Row>
        </div>
      </div>
    );
  }
}

export default ConferenceReport;