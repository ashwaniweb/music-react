import React from 'react';
import { Row, Col, Table, Pagination, OverlayTrigger, Tooltip, SplitButton, MenuItem } from 'react-bootstrap';
// Other file call
import './recordingList.scss';
var createReactClass = require('create-react-class');

const options = [
  'Reserved', 'Un-Reserved'
]

const LinkWithTooltip = createReactClass({
  render() {
    let tooltip = <Tooltip id={this.props.id}>{this.props.tooltip}</Tooltip>;
    return (
      <OverlayTrigger
        overlay={tooltip}
        placement="top"
        delayShow={300}
        delayHide={150}
      >
        <a href={this.props.href}>{this.props.children}</a>
      </OverlayTrigger>
    );
  }
});
const list = [
  {
    id: 1,
    Date: '14/12/2017',
    sTime: '03:30 PM',
    eTime: '04:30 PM',
    Duration: '01h 25m 06s',
    duration: '01:25:06',
    Dialledno: '202-555-0101',
    audio: 'a.mp3'
  },
  {
    id: 2,
    Date: '14/12/2017',
    sTime: '03:30 PM',
    eTime: '04:30 PM',
    Duration: '01h 25m 06s',
    duration: '15:20',
    Dialledno: '202-555-0101',
    audio: 'b.mp3'
  },
  {
    id: 3,
    Date: '14/12/2017',
    sTime: '03:30 PM',
    eTime: '04:30 PM',
    Duration: '01h 25m 06s',
    duration: '10:55',
    Dialledno: '202-555-0101',
    audio: 'c.mp3'
  },
  {
    id: 4,
    Date: '14/12/2017',
    sTime: '03:30 PM',
    eTime: '04:30 PM',
    Duration: '01h 25m 06s',
    duration: '05:10',
    Dialledno: '202-555-0101',
    audio: 'a.mp3'
  },
  {
    id: 5,
    Date: '14/12/2017',
    sTime: '03:30 PM',
    eTime: '04:30 PM',
    Duration: '01h 25m 06s',
    duration: '45:20',
    Dialledno: '202-555-0101',
    audio: 'b.mp3'
  },
  {
    id: 6,
    Date: '14/12/2017',
    sTime: '03:30 PM',
    eTime: '04:30 PM',
    Duration: '01h 25m 06s',
    duration: '25:06',
    Dialledno: '202-555-0101',
    audio: 'c.mp3'
  },
];

class RecordingList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      list: list,
      audioPlay: false,
      audioPause: false,
      audioDownload: false,
      audioDelete: false
    };
    this.handleClick = this.handleClick.bind(this);
    this.audioPlay = this.audioPlay.bind(this);
    this.audioPause = this.audioPause.bind(this);
    this.audioDownload = this.audioDownload.bind(this);
    this.audioDelete = this.audioDelete.bind(this);
  }

  handleClick(item) {
    let updatedList = this.state.list.map(obj => {
      if (obj.id === item.id) {
        return Object.assign({}, obj, {
          hidden: !item.hidden
        });
      }
      return obj;
    });
    this.setState({
      list: updatedList,
    });
  }
  audioPlay(e) {
    this.setState(
      function (prevState) {
        var audioElement = document.getElementById('beep-' + 1);
        audioElement.setAttribute("preload", "auto");
        audioElement.autobuffer = true;
        audioElement.load();
        audioElement.play();
        return {
          audioPlay: true
        };
      });
  }

  audioPause(e) {
    if (this.state.audioPlay) {
      this.setState({
        audioPlay: false,
      }, function () {
        var audioElement = document.getElementById('beep-' + 1);
        audioElement.pause();
      });
    }
  }

  audioDownload(e) {
    if (this.state.audioDownload) {
      this.setState({
        audioDownload: false,
      }, function () {
        var audioElement = document.getElementById('beep');
        audioElement.download();
      });
    }
  }
  audioDelete(e) {
    alert('Delete');
    if (this.state.audioDelete) {
      this.setState({
        audioDelete: false,
      }, function () {
        var audioElement = document.getElementById('beep');
        audioElement.pause();
      });
    }
  }

  playLine(e) {

  }

  render() {
    return (
      <div className="ibox">
        <div className="ibox-title">
          <h5>Recording List</h5>
          <div className="topBarbtn">
            <SplitButton title="Dropdown" pullRight id="split-button-pull-right">
              <MenuItem eventKey="3">Download CSV</MenuItem>
              <MenuItem divider />
              <MenuItem eventKey="4">Download Excel</MenuItem>
            </SplitButton>
          </div>

          <Row className="cdrGroupinfo">
            <Row>
              <Col md={4}>
                <Row>
                  <div className="form-group">
                    <div className="col-sm-12">
                      Conference Name: &nbsp;&nbsp;<span>Asergis UI/UX Group Call</span>
                    </div>
                  </div>
                </Row>
              </Col>
              <Col md={4}>
                <Row>
                  <div className="form-group">
                    <div className="col-sm-12">
                      Call Type: &nbsp;&nbsp;<span>Unreserved Call</span>
                    </div>
                  </div>
                </Row>
              </Col>
            </Row>
          </Row>
        </div>
        <div className="ibox-content">
          <Row className="gTable-new">
            <Table responsive className="table-bordered">
              <thead>
                <tr>
                  <th width="10%">Dialled No.</th>
                  <th width="10%" className="sorting">Date</th>
                  <th width="10%" className="sorting">Start Time</th>
                  <th width="10%" className="sorting">End Time</th>
                  <th width="10%" className="text-center">Duration</th>
                  <th width="25%" className="text-center">Play</th>
                  <th width="10%" className="text-center">Action</th>
                </tr>
              </thead>
              <tbody>
                {this.state.list.map(item =>
                  <tr key={item.itemId}>
                    <td className="text-center">{item.Dialledno}</td>
                    <td>{item.Date}</td>
                    <td className="text-center">{item.sTime}</td>
                    <td className="text-center">{item.eTime}</td>
                    <td className="text-center">{item.Duration}</td>
                    <td className="text-center">
                      <div className="audioPlayer recList">
                        {!this.state.audioPlay ?
                          <i className="material-icons recList" onClick={this.audioPlay}>play_arrow</i>
                          :
                          <i className="material-icons recList" onClick={this.audioPause}>pause</i>
                        }
                        <div className="playLine">
                          <span className="looper"></span>
                        </div>
                        <span className="duration">{item.duration}</span>
                      </div>
                      <audio id={'beep-' + item.id} className="player" preload="false">
                        <source src={'/media/' + item.audio} />
                      </audio>
                    </td>
                    <td className="action-wrap text-center">
                      <LinkWithTooltip tooltip="View" href="javascript:void('0')" id={'tooltip-' - { item }}>
                        <i onClick={this.audioDownload} className="material-icons recList">file_download</i>
                      </LinkWithTooltip>
                      <LinkWithTooltip tooltip="Delete" href="javascript:void('0')" id={'tooltip-' - { item }}>
                        <i onClick={this.audioDelete} className="material-icons recList">delete</i>
                      </LinkWithTooltip>
                    </td>
                  </tr>
                )}
              </tbody>
            </Table>
          </Row>
          <Row>
            <Col md={6} className="allentries">
              {/* Showing 1 to 1 of 1 entries */}
            </Col>
            <Col md={6}>
              <div className="table-pag">
                <Pagination
                  first='fast_rewind'
                  next='play_arrow'
                  prev='play_arrow'
                  last='fast_forward'
                  ellipsis
                  boundaryLinks
                  items={5}
                  maxButtons={5}
                />
              </div>
            </Col>
          </Row>
        </div>
      </div>
    );
  }
}

export default RecordingList;