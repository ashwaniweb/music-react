import React from 'react';
import { Row, Col, Table, FormControl, Pagination, OverlayTrigger, Tooltip, FormGroup, InputGroup, SplitButton, MenuItem, ButtonGroup, Button } from 'react-bootstrap';
import Dropdown from 'react-dropdown';
import { Link } from 'react-router-dom';

// Other file call
import './conferenceList.scss';
var createReactClass = require('create-react-class');
const options = [
  'Non-Live', 'Live'
]
const options2 = [
  'Reserved', 'Un-Reserved'
]

const LinkWithTooltip = createReactClass({
  render() {
    let tooltip = <Tooltip id={this.props.id}>{this.props.tooltip}</Tooltip>;
    return (
      <OverlayTrigger
        overlay={tooltip}
        placement="top"
        delayShow={300}
        delayHide={150}
      >
        <a href={this.props.href}>{this.props.children}</a>
      </OverlayTrigger>
    );
  }
});
const list = [
  {
    id: 1,
    checkBox: 'hello',
    name: 'Meeting',
    totalMember: '10',
    Date: '14/12/2017',
    sTime: '03:30 PM',
    eTime: '11:30 PM',
    status: 'Non-Live',
    type: 'Un-reserved',
    rec: 'View',
    hidden: true
  },
  {
    id: 2,
    checkBox: 'hello',
    name: 'Meeting',
    totalMember: '10',
    Date: '14/12/2017',
    sTime: '03:30 PM',
    eTime: '11:30 PM',
    status: 'Non-Live',
    type: 'Reserved',
    rec: 'View',
    hidden: true
  },
  {
    id: 3,
    checkBox: 'hello',
    name: 'Meeting',
    totalMember: '10',
    Date: '14/12/2017',
    sTime: '03:30 PM',
    eTime: '11:30 PM',
    status: 'Live',
    type: 'Un-reserved',
    rec: 'View',
    hidden: true
  },
  {
    id: 4,
    checkBox: 'hello',
    name: 'Meeting',
    totalMember: '10',
    Date: '14/12/2017',
    sTime: '03:30 PM',
    eTime: '11:30 PM',
    status: 'Non-Live',
    type: 'Un-reserved',
    rec: 'View',
    hidden: true
  },
  {
    id: 5,
    checkBox: 'hello',
    name: 'Meeting',
    totalMember: '10',
    Date: '14/12/2017',
    sTime: '03:30 PM',
    eTime: '11:30 PM',
    status: 'Live',
    type: 'Un-reserved',
    rec: 'View',
    hidden: true
  }
];

class ConferenceList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      list: list
    };
    this.handleClick = this.handleClick.bind(this);
  }

  handleClick(item) {
    let updatedList = this.state.list.map(obj => {
      if (obj.id === item.id) {
        return Object.assign({}, obj, {
          hidden: !item.hidden
        });
      }
      return obj;
    });
    this.setState({
      list: updatedList,
    });
  }

  render() {
    return (
      <div className="ibox">
        <div className="ibox-title">
          <h5>Conference List</h5>
          <div className="topBarbtn">&nbsp;&nbsp;&nbsp;&nbsp;
            <SplitButton title="Dropdown" pullRight id="split-button-pull-right">
              <MenuItem eventKey="3">Download Excel</MenuItem>
              <MenuItem divider />
              <MenuItem eventKey="4">Download</MenuItem>
            </SplitButton>
          </div>
          <div className="centerBtn">
            <ButtonGroup>
              <Button>Active</Button>
              <Button>Non Active</Button>
            </ButtonGroup>
          </div>
        </div>
        <div className="ibox-content">
          <Row className="gTable-new">
            <Table responsive className="table-bordered">
              <thead>
                <tr>
                  <th width="2%">&nbsp;</th>
                  <th width="15%">Conference Name</th>
                  <th width="10%" className="text-center">Total Members</th>
                  <th width="8%" className="sorting">Date</th>
                  <th width="10%" className="sorting">Start Time</th>
                  <th width="10%" className="sorting">End Time</th>
                  <th width="10%" className="text-center">Status</th>
                  <th width="10%" className="text-center">Type</th>
                  <th width="10%" className="text-center">Rec</th>
                  <th width="15%" className="text-center">Action</th>
                </tr>
                <tr>
                  <th>&nbsp;</th>
                  <th>
                    <FormGroup>
                      <InputGroup>
                        <FormControl type="text" placeholder="Search" className="fShadow" />
                        <InputGroup.Addon>
                          <i className="fa fa-search"></i>
                        </InputGroup.Addon>
                      </InputGroup>
                    </FormGroup>
                  </th>
                  <th>&nbsp;</th>
                  <th>
                    <FormGroup>
                      <InputGroup>
                        <FormControl type="text" placeholder="Date" className="fShadow" />
                        <InputGroup.Addon>
                          <i className="fa fa-calendar"></i>
                        </InputGroup.Addon>
                      </InputGroup>
                    </FormGroup>
                  </th>
                  <th>&nbsp;</th>
                  <th>&nbsp;</th>
                  <th><Dropdown options={options} onChange={this._onSelect} placeholder="Select" /></th>
                  <th><Dropdown options={options2} onChange={this._onSelect} placeholder="Select" /></th>
                  <th>&nbsp;</th>
                  <th>&nbsp;</th>
                </tr>
              </thead>
              <tbody>
                {this.state.list.map(item =>
                  [
                    <tr key={item.itemId}>
                      <td>
                        <div className="checkbox checkbox-week checkbox-inline">
                          <input type="checkbox" id="inlineRadio1" value="option1" name="radioInline" />
                          <label htmlFor="inlineRadio1"></label>
                        </div>
                      </td>
                      <td>
                        {item.name}
                        {/* <span onClick={() => this.handleClick(item)} className="material-icons pointer">{!this.state.hidden ? 'keyboard_arrow_down' : 'keyboard_arrow_up'}</span> */}
                      </td>
                      <td className="text-center">{item.totalMember}</td>
                      <td className="text-center">{item.Date}</td>
                      <td className="text-center">{item.sTime}</td>
                      <td className="text-center">{item.eTime}</td>
                      <td className="text-center">{item.status}</td>
                      <td className="text-center">{item.type}</td>
                      <td className="text-center">
                        <Link to="/video/video-management/recording-list">{item.rec}</Link>
                      </td>
                      <td className="action-wrap text-center">
                        <LinkWithTooltip tooltip="View" href="javascript:void('0')" id={'tooltip-' - { item }}>
                          <Link to="/video/video-management/view-conference">
                            <i className="material-icons">remove_red_eye</i>
                          </Link>
                        </LinkWithTooltip>
                        <LinkWithTooltip tooltip="Edit" href="javascript:void('0')" id={'tooltip-' - { item }}>
                          <i className="material-icons">border_color</i>
                        </LinkWithTooltip>
                        <LinkWithTooltip tooltip="Delete" href="javascript:void('0')" id={'tooltip-' - { item }}>
                          <i className="material-icons">delete</i>
                        </LinkWithTooltip>
                        <LinkWithTooltip tooltip="Begin Live Conference" href="javascript:void('0')" id={'tooltip-' - { item }}>
                          <Link to="/begin-live-conference">
                            <i className="material-icons">group_work</i>
                          </Link>
                        </LinkWithTooltip>
                      </td>
                    </tr>
                  ]
                )}
              </tbody>
            </Table>
          </Row>

          <Row>
            <Col md={6} mdPush={6}>
              <div className="table-pag">
                <Pagination
                  first='fast_rewind'
                  next='play_arrow'
                  prev='play_arrow'
                  last='fast_forward'
                  ellipsis
                  boundaryLinks
                  items={4}
                  maxButtons={4}
                />
              </div>
            </Col>
          </Row>
        </div>
      </div>
    );
  }
}

export default ConferenceList;