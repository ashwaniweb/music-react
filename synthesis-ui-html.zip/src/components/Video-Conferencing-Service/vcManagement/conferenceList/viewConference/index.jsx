import React from 'react';
import { Row, Col, OverlayTrigger, Tooltip } from 'react-bootstrap';
// Other file call 
import './viewConference.scss';
var createReactClass = require('create-react-class');

const LinkWithTooltip = createReactClass({
  render() {
    let tooltip = <Tooltip id={this.props.id}>{this.props.tooltip}</Tooltip>;
    return (
      <OverlayTrigger
        overlay={tooltip}
        placement="top"
        delayShow={300}
        delayHide={150}
      >
        <a href={this.props.href}>{this.props.children}</a>
      </OverlayTrigger>
    );
  }
});
const list = [
  {
    id: 1,
    Date: '14/12/2017',
    sTime: '03:30 PM',
    eTime: '04:30 PM',
    Duration: '01h 25m 06s',
    duration: '01:25:06',
    Dialledno: '202-555-0101',
    audio: 'a.mp3'
  },
  {
    id: 2,
    Date: '14/12/2017',
    sTime: '03:30 PM',
    eTime: '04:30 PM',
    Duration: '01h 25m 06s',
    duration: '15:20',
    Dialledno: '202-555-0101',
    audio: 'b.mp3'
  },
  {
    id: 3,
    Date: '14/12/2017',
    sTime: '03:30 PM',
    eTime: '04:30 PM',
    Duration: '01h 25m 06s',
    duration: '10:55',
    Dialledno: '202-555-0101',
    audio: 'c.mp3'
  },
  {
    id: 4,
    Date: '14/12/2017',
    sTime: '03:30 PM',
    eTime: '04:30 PM',
    Duration: '01h 25m 06s',
    duration: '05:10',
    Dialledno: '202-555-0101',
    audio: 'a.mp3'
  },
  {
    id: 5,
    Date: '14/12/2017',
    sTime: '03:30 PM',
    eTime: '04:30 PM',
    Duration: '01h 25m 06s',
    duration: '45:20',
    Dialledno: '202-555-0101',
    audio: 'b.mp3'
  },
  {
    id: 6,
    Date: '14/12/2017',
    sTime: '03:30 PM',
    eTime: '04:30 PM',
    Duration: '01h 25m 06s',
    duration: '25:06',
    Dialledno: '202-555-0101',
    audio: 'c.mp3'
  },
];

class ViewConference extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      list: list,
      audioPlay: false,
      audioPause: false,
      audioDownload: false,
      audioDelete: false
    };
    this.handleClick = this.handleClick.bind(this);
    this.audioPlay = this.audioPlay.bind(this);
    this.audioPause = this.audioPause.bind(this);
    this.audioDownload = this.audioDownload.bind(this);
    this.audioDelete = this.audioDelete.bind(this);
  }

  handleClick(item) {
    let updatedList = this.state.list.map(obj => {
      if (obj.id === item.id) {
        return Object.assign({}, obj, {
          hidden: !item.hidden
        });
      }
      return obj;
    });
    this.setState({
      list: updatedList,
    });
  }
  audioPlay(e) {
    this.setState(
      function (prevState) {
        var audioElement = document.getElementById('beep-' + 1);
        audioElement.setAttribute("preload", "auto");
        audioElement.autobuffer = true;
        audioElement.load();
        audioElement.play();
        return {
          audioPlay: true
        };
      });
  }

  audioPause(e) {
    if (this.state.audioPlay) {
      this.setState({
        audioPlay: false,
      }, function () {
        var audioElement = document.getElementById('beep-' + 1);
        audioElement.pause();
      });
    }
  }

  audioDownload(e) {
    if (this.state.audioDownload) {
      this.setState({
        audioDownload: false,
      }, function () {
        var audioElement = document.getElementById('beep');
        audioElement.download();
      });
    }
  }
  audioDelete(e) {
    alert('Delete');
    if (this.state.audioDelete) {
      this.setState({
        audioDelete: false,
      }, function () {
        var audioElement = document.getElementById('beep');
        audioElement.pause();
      });
    }
  }

  playLine(e) {

  }

  render() {
    return (
      <div className="flex flex-row structure">
        <Col md={6} className="flex flex-row structure-6">
          <div className="ibox flex flex-col">
            <div className="ibox-title">
              <h5>Conference Details</h5>
            </div>
            <div className="ibox-content pl-0 pr-0">
              <Row>
                <Col md={6}>
                  <div className="col-sm-12">
                    <strong>Conference Name</strong><br />
                    Asergis UI/UX Group Call
                  </div>
                </Col>
                <Col md={6}>
                  <div className="col-sm-12">
                    <strong>Date</strong><br />
                    July 28th, 2017
                  </div>
                </Col>
              </Row>
              <Row className="mt-5">
                <Col md={6}>
                  <div className="col-sm-12">
                    <strong>Time</strong><br />
                    05:30 PM
                  </div>
                </Col>
              </Row>

              <Col md={12} className="mt-5">
                <button type="button" className="btn-cancel btn btn-default">Close this Window</button>
              </Col>
            </div>
          </div>
        </Col>
        <Col md={6} className="flex flex-row structure-6">
          <div className="ibox flex flex-col">
            <div className="ibox-title">
              <h5>Default Settings</h5>
            </div>
            <div className="ibox-content pl-0 pr-0">
              <Row>
                <Col md={6}>
                  <div className="col-sm-12">
                    <strong>Record Your Conference</strong><br />
                    Yes <a href="#">(Show)</a>
                  </div>
                </Col>
              </Row>
              <Row className="mt-5">
                <Col md={12}>
                  <div className="col-sm-12">
                    <strong>Added Participants</strong>
                  </div>
                  <div className="col-sm-12 droppable">
                    <span className="dropped-elem">Aleksandar Pavlovikj</span>
                    <span className="dropped-elem">Soumya Bhardwaj</span>
                    <span className="dropped-elem">Shamim Saifi</span>
                    <span className="dropped-elem">Aswani Singh</span>
                    <span className="dropped-elem">Ganga Singh Thakur</span>
                    <span className="dropped-elem">George Victor Adade</span>
                    <span className="dropped-elem">Abdur Rehman Siddiqui</span>
                    <span className="dropped-elem">Manish Badola</span>
                    <span className="dropped-elem">Pinki Sharma</span>
                    <span className="dropped-elem">Pradeep Kaushal</span>
                    <span className="dropped-elem">Navdeep Singh Chawla</span>
                    <span className="dropped-elem">Ankit Lakhera</span>
                  </div>
                </Col>
              </Row>
            </div>
          </div>
        </Col>
      </div>
    );
  }
}

export default ViewConference;