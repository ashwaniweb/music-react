import React from 'react';
import { Row, Col, FormGroup, FormControl, ControlLabel, Button } from 'react-bootstrap';

// Other file call
import './addParticipants.scss';

class AddParticipants extends React.Component {
  render() {
    return (
      <div className="flex flex-col ibox m-l-none">
        <div className="ibox-title">
          <h5>Add Participants</h5>
        </div>
        <div className="ibox-content">
          <div className="form-area">
            <Row>
              <Col md={6}>
                <FormGroup>
                  <ControlLabel>Type Invite</ControlLabel>
                  <FormControl type="text" placeholder="conference name is required" />
                </FormGroup>
              </Col>
              <Col md={4}>
                <Button className="btn-addpar">Add Participants</Button>
              </Col>
            </Row>

            <br />
            <Row>
              <Col md={12}>
                <Button className="btn-submit">Submit</Button>
                <Button className="btn-cancel">Cancel</Button>
              </Col>
            </Row>
          </div>
        </div>
      </div>
    );
  }
}

export default AddParticipants;