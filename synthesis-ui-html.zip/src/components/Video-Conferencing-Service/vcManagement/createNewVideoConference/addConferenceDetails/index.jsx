import React from 'react';
import { Row, Col, FormGroup, FormControl, ControlLabel, InputGroup, Button } from 'react-bootstrap';
// import DateTimeField from 'react-bootstrap-datetimepicker';

// Other file call
import './addConferenceDetails.scss';

class AddConferenceDetails extends React.Component {  
  render() {
    return (
      <div className="flex flex-col ibox">
        <div className="ibox-title">
          <h5>Add Conference Details</h5>
        </div>
        <div className="ibox-content">
          <div className="form-area">
            <Row>
              <Col md={6}>
                <FormGroup>
                  <ControlLabel>Conference Name</ControlLabel>
                  <FormControl type="text" placeholder="conference name is required" />
                </FormGroup>
              </Col>
            </Row>
            <hr/>

            <Row>
              <Col md={12}>
                <ControlLabel>Date & Time </ControlLabel>
              </Col>
              <Col md={4} sm={4}>
                <FormGroup>
                  <InputGroup>
                    <FormControl type="text" placeholder="Select Date" className="fShadow" />
                    <InputGroup.Addon>
                      <i className="fa fa-calendar"></i>
                    </InputGroup.Addon>
                  </InputGroup>
                </FormGroup>
              </Col>
              <Col md={4} sm={4}>
                <FormGroup>
                  <InputGroup>
                    <FormControl type="text" placeholder="Select Time" className="fShadow" />
                    <InputGroup.Addon>
                      <i className="fa fa-clock-o"></i>
                    </InputGroup.Addon>
                  </InputGroup>
                </FormGroup>

              </Col>
            </Row>
            
            <br />
            <Row>
              <Col md={12}>
                <Button className="btn-submit">Submit</Button>
                <Button className="btn-cancel">Cancel</Button>
              </Col>
            </Row>

          </div>
        </div>
      </div>
    );
  }
}

export default AddConferenceDetails;