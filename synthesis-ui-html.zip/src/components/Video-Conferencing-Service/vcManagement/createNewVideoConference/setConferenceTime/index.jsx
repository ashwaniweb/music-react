import React from 'react';
import { Row, Col, FormGroup, FormControl, InputGroup, ControlLabel, OverlayTrigger, Popover } from 'react-bootstrap';

// Other file call
import './setConferenceTime.scss';

const conferenceParticipant = (
  <Popover className="top-pop" title="">
    popover text go here
  </Popover>
);

class SetConferenceTime extends React.Component {
  render() {
    return (
      <div className="flex flex-col ibox">
        <div className="ibox-title">
          <h5>Set Conference Time</h5>
        </div>
        <div className="ibox-content">
          <div className="form-area">
            <Row>
              <Col md={12}>
                <ControlLabel>Date & Time &nbsp;&nbsp;
                  <OverlayTrigger trigger={['hover', 'focus']} placement="top" overlay={conferenceParticipant}>
                    <i className="material-icons">info</i>
                  </OverlayTrigger>
                </ControlLabel>
              </Col>
              <Col md={4} sm={4}>
                <FormGroup>
                  <InputGroup>
                    <FormControl type="text" placeholder="Select Date" className="fShadow" />
                    <InputGroup.Addon>
                      <i className="fa fa-calendar"></i>
                    </InputGroup.Addon>
                  </InputGroup>
                </FormGroup>
              </Col>
              <Col md={4} sm={4}>
                <FormGroup>
                  <InputGroup>
                    <FormControl type="text" placeholder="Select Time" className="fShadow" />
                    <InputGroup.Addon>
                      <i className="fa fa-clock-o"></i>
                    </InputGroup.Addon>
                  </InputGroup>
                </FormGroup>
              </Col>
            </Row>
          </div>
        </div>
      </div>
    );
  }
}

export default SetConferenceTime;