import React from 'react';
import {Col} from 'react-bootstrap';

// Other file call
import AddConferenceDetails from './addConferenceDetails';
import SetConferenceTime from './setConferenceTime';
import DefaultSettings from './defaultSettings';
import AddParticipants from './addParticipants';

class CreateNewVideoConference extends React.Component {
  render() {
    return (
      <div className="flex flex-row structure">
        <Col md={6} className="flex flex-row structure-6">
          <AddConferenceDetails />          
        </Col>
        <Col md={6} className="flex flex-row structure-6">
          <DefaultSettings/>          
        </Col>
      </div>
    );
  }
}

export default CreateNewVideoConference;