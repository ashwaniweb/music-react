import React from 'react';
import { Route, Switch } from 'react-router-dom';

// Other file call
import VideoTopMenu from './videotopMenu';
import VcMiddleSection from './dashBoard';
// import BeginLiveConference from '../Video-Conferencing-Service/vcManagement/beginLiveConference';

class VideoConferencingDashboard extends React.Component {
  render() {
    return (
      <div className="main">
        <VideoTopMenu />
        <VcMiddleSection />
      </div>
    );
  }
}

export default VideoConferencingDashboard;