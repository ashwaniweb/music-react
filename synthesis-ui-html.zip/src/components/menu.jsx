import React from 'react';
import { Button, Navbar, Nav, NavItem, NavDropdown, DropdownButton, FormGroup, MenuItem, FormControl, Col } from 'react-bootstrap';
import { IndexLinkContainer } from 'react-router-bootstrap';
import {
  Link
} from 'react-router-dom'


import {menuList} from './menu.json';

const SecondLevel = (props) => {
  // Here I’m trying to return if the props are not present
  if(!props.items) return null;
  return (
    <ul className="nav navbar-nav level-second">
      {props.items.map((item, index) => {
        return(
          <li key={index}>
            {item.url!=='' ?
            <Link to={item.url} role="button">
              {item.icon && <i className="material-icons">{item.icon}</i>}
              {item.customIcon && <i className={item.customIcon}></i>}
              {item.name}  
            </Link> :
            <span onClick={this.subSubNavbar} role="button">
              {item.icon && <i className="material-icons">{item.icon}</i>}
              {item.customIcon && <i className={item.customIcon}></i>}
              {item.name}
            </span>
            }
            {item.subMenu &&
              <ThirdLevel items={item.subMenu}/> 
            }          
          </li>
        )
      })}
    </ul>
  );
}

const ThirdLevel = (props) => {
  // Here I’m trying to return if the props are not present
  if(!props.items) return null;
  return (
    <ul className="nav navbar-nav level-third">
      {props.items.map((item, index) => {
        return(
          <li key={index}>
            {item.url!=='' ?
            <Link to={item.url} role="button">
              {item.icon && <i className="material-icons">{item.icon}</i>}
              {item.customIcon && <i className={item.customIcon}></i>}
              {item.name}  
            </Link> :
            <span onClick={this.subSubNavbar} role="button">
              {item.icon && <i className="material-icons">{item.icon}</i>}
              {item.customIcon && <i className={item.customIcon}></i>}
              {item.name}
            </span>
            }   
          </li>
        )
      })}
    </ul>
  );
}


class NavMenu extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      menuList: [],
    };
    this.subNavbar = this.subNavbar.bind(this);
    this.subSubNavbar = this.subSubNavbar.bind(this);
  }
  subNavbar() {
    if (!this.state.subNavbar) {
      this.setState({
        subNavbar: true
      })
    } else {
      this.setState({
        subNavbar: false
      })
    }
  }

  subSubNavbar() {
    if (!this.state.subSubNavbar) {
      this.setState({
        subSubNavbar: true
      })
    } else {
      this.setState({
        subSubNavbar: false
      })
    }
  }

  render() {
    return (
      <nav className="navbar bottom navbar-default">
        <div className="container">
          <div className="navbar-collapse collapse">
            <ul className="nav navbar-nav">      
              {menuList.map((item, index) => {
                return(
                  <li key={index}>
                    {item.url!=='' ?
                      <Link to={item.url} role="button">
                        {item.icon && <i className="material-icons">{item.icon}</i>}
                        {item.customIcon && <i className={item.customIcon}></i>}
                        {item.name}  
                      </Link> :
                      <span onClick={this.subSubNavbar} role="button">
                        {item.icon && <i className="material-icons">{item.icon}</i>}
                        {item.customIcon && <i className={item.customIcon}></i>}
                        {item.name}
                      </span>
                    }
                    {item.subMenu &&
                      <SecondLevel items={item.subMenu}/> 
                    }
                  </li>
                )
              })}
            </ul>
          </div>  
        </div>  
      </nav>       
    )
  }
}

export default NavMenu;
