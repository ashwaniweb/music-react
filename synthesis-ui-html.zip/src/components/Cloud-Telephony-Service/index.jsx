import React from 'react';
import { Row, Col, Image } from 'react-bootstrap';

// Other file call
import CloudTopMenu from './cloudtopMenu';
import CloMiddleSection from './dashBoard';

class CloudTelephonyDashboard extends React.Component {
  render() {
    return (
      <div className="main">
        <CloudTopMenu />
        <CloMiddleSection />
      </div>
    );
  }
}

export default CloudTelephonyDashboard;