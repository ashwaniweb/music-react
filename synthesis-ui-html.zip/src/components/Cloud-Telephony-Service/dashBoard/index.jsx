import React from 'react';
import { BrowserRouter as Router, Route, Switch, browserHistory } from 'react-router-dom';
// Other file call
import DashLeftMenu from '../../dashleft';
import DashRightMenu from '../../dashright';

class CloMiddleSection extends React.Component {
  render() {
    return (
      <div className="container-flud">
        <div className="mainArea">
          <DashLeftMenu />
          <div className="middleArea">
            sdfsfasdfdf
            <div className="clearfix"></div>
          </div>
          <DashRightMenu />
        </div>
      </div>
    );
  }
}

export default CloMiddleSection;