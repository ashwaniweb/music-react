import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';

// Other file call
import DashLeftMenu from '../../dashleft';
import DashRightMenu from '../../dashright';
// import MainDashboard from '../../mainDashboard';
import CreateNewConference from '../acManagement/createNewConference/index';
import ConferenceList from '../acManagement/conferenceList';
import ConferenceReport from '../acManagement/conferenceReport';
import GlobalAccessNumbers from '../acManagement/globalAccessNumbers';
import CrdList from '../acManagement/conferenceList/crdList';
import RecordingList from '../acManagement/conferenceList/recordingList';
import AssociatedNumbers from '../acManagement/associatedNumbers';
import EditNewConference from '../acManagement/editNewConference';
import welcomeAudioMessageList from '../audioManagement/welcomeAudioMessageList';
import ListInCallAudioMessageList from '../audioManagement/listInCallAudioMessageList';

class MiddleSection extends React.Component {
  render() {
    return ( 
      <div className="container-flud">
        <div className="mainArea">
          <DashLeftMenu />
          <div className="middleArea">
            <Switch>
              <div>
                <Route exact path="/audio/account-management/create-new-conference" component={CreateNewConference} />
                <Route path="/audio/account-management/conference-list" component={ConferenceList} />
                <Route path="/audio/account-management/conference-report" component={ConferenceReport} />
                <Route path="/audio/account-management/global-access-numbers" component={GlobalAccessNumbers} />
                <Route path="/audio/account-management/CRD-List" component={CrdList} />
                <Route path="/audio/account-management/recording-list" component={RecordingList} />
                <Route path="/audio/account-management/associated-numbers" component={AssociatedNumbers} />
                <Route path="/audio/account-management/edit-new-conference" component={EditNewConference} />
                <Route path="/audio/audio-management/welcome-audio-msg-list" component={welcomeAudioMessageList} />
                <Route path="/audio/audio-management/list-in-call-audio-message-list" component={ListInCallAudioMessageList} />
              </div>
            </Switch>
            <div className="clearfix"></div>
          </div>
          <DashRightMenu />
        </div>
      </div>
    );
  }
}

export default MiddleSection;