import React from 'react';
import Slider, { Range } from 'rc-slider';
import { Row, Col, Grid, FormGroup, FormControl, ControlLabel } from 'react-bootstrap';

// Other file call
import SetConferenceTime from '../editSetConferenceTime/';
import './editConferenceDetails.scss';
import 'rc-slider/assets/index.css';

class AddConferenceDetails extends React.Component {
  
  render() {
    return (
      <div className="ibox">
        <div className="ibox-title">
          <h5>Edit Conference Details</h5>
        </div>
        <div className="ibox-content">
          <div className="form-area">
            <form>
              <Row>
                <Col md={6}>
                  <FormGroup>
                    <ControlLabel>Conference Name</ControlLabel>
                    <FormControl type="text" placeholder="conference name is required" />
                  </FormGroup>
                </Col>
                <Col md={6}>
                  <FormGroup>
                    <ControlLabel>Participant Limit</ControlLabel>
                    <Row>
                      <Col sm={8}>
                        <Slider />
                      </Col>
                      <Col sm={4}>
                        <div className="rc-value">
                          <FormControl type="text" placeholder="10" />
                        </div>
                      </Col>
                    </Row>
                  </FormGroup>
                </Col>
              </Row>
              <hr />

              <Row>
                <Col md={6}>
                  <FormGroup>
                    <ControlLabel>Conference Leader Pin</ControlLabel>
                    <Row className="pinGenrate">
                      <Col md={4}>
                        <FormControl type="text" placeholder="8562142" />
                      </Col>
                      <Col md={8}>
                        <a href="/">Generate New Pin</a>                        
                      </Col>
                    </Row>
                  </FormGroup>
                </Col>
                <Col md={6}>
                  <FormGroup>
                    <ControlLabel>Conference Participant Pin</ControlLabel>
                    <Row className="pinGenrate">
                      <Col md={4}>
                        <FormControl type="text" placeholder="8562142" />
                      </Col>
                      <Col md={8}>
                        <a href="/">Generate New Pin</a>
                      </Col>
                    </Row>
                  </FormGroup>
                </Col>
              </Row>
              <hr />

              <Row>
                <Col md={12}>
                  <FormGroup>
                    <ControlLabel>Preferred AC POP</ControlLabel>
                    <Row>
                      <Col md={12}>
                        <div className="radio radio-info radio-inline">
                          <input type="radio" id="inlineRadio1" value="option1" name="radioInline" defaultChecked />
                          <label htmlFor="inlineRadio1"> Delhi </label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        </div>
                        <div className="radio radio-info radio-inline">
                          <input type="radio" id="inlineRadio2" value="option1" name="radioInline" />
                          <label htmlFor="inlineRadio2"> Bangalore </label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        </div>
                        <div className="radio radio-info radio-inline">
                          <input type="radio" id="inlineRadio3" value="option1" name="radioInline" />
                          <label htmlFor="inlineRadio3"> Mumbai </label>
                        </div>
                      </Col>
                    </Row>
                  </FormGroup>
                </Col>
              </Row>
              <SetConferenceTime />
            </form>
          </div>          
        </div>
      </div>
    );
  }
}

export default AddConferenceDetails;