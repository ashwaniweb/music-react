import React from 'react';
import { Col } from 'react-bootstrap';

import AddConferenceDetails from './editConferenceDetails';
import DefaultSettings from './editDefaultSettings/';
import ConferenceRecurrence from './editConferenceRecurrence/';
import SelectDailinNumber from './editSelectDailinNumber';

// Other file call

class EditNewConference extends React.Component {
  render() {
    return (
      <div className="flex flex-row structure">
        <Col md={7} className="flex flex-row structure-7">
          <AddConferenceDetails />
          <ConferenceRecurrence />
        </Col>
        <Col md={5} className="flex flex-row structure-5">
          <DefaultSettings />
        </Col>
        <Col md={12} className="flex flex-row structure-12">
          <SelectDailinNumber />
        </Col>
      </div>
    );
  }
}

export default EditNewConference;