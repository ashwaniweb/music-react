import React from 'react';
import { Row, Col, Table, FormControl, Pagination, OverlayTrigger, Tooltip, FormGroup, InputGroup, SplitButton, MenuItem, ButtonGroup, Button } from 'react-bootstrap';
import Dropdown from 'react-dropdown';
// import { Link } from 'react-router-dom'

// Other file call
import './associatedNumbers.scss';

var createReactClass = require('create-react-class');
const options = [
  'Paid', 'Toll Free'
]
const options2 = [
  'Active', 'Deactivated', 'Expired'
]
// const options3 = [
//   '1', '5', '10', '50'
// ]

const LinkWithTooltip = createReactClass({
  render() {
    let tooltip = <Tooltip id={this.props.id}>{this.props.tooltip}</Tooltip>;
    return (
      <OverlayTrigger
        overlay={tooltip}
        placement="top"
        delayShow={300}
        delayHide={150}
      >
        <a href={this.props.href}>{this.props.children}</a>
      </OverlayTrigger>
    );
  }
});
const list = [
  {
    id: 1,
    checkBox: 'hello',
    countryName: 'Malta',
    cityName: 'Valletta',
    phoneNumber: '+91-9210740008',
    type: 'Paid',
    status: 'Active'
  },
  {
    id: 2,
    checkBox: 'hello',
    countryName: 'Malta',
    cityName: 'Valletta',
    phoneNumber: '+91-9210740008',
    type: 'Paid',
    status: 'Active'
  },
  {
    id: 3,
    checkBox: 'hello',
    countryName: 'United Kingdom',
    cityName: 'London',
    phoneNumber: '+91-9210740008',
    type: 'Toll Free',
    status: 'Active'
  },
  {
    id: 4,
    checkBox: 'hello',
    countryName: 'India',
    cityName: 'New Delhi',
    phoneNumber: '+91-9210740008',
    type: 'Toll Free',
    status: 'Deactivted'
  },
  {
    id: 5,
    checkBox: 'hello',
    countryName: 'India',
    cityName: 'Noida',
    phoneNumber: '+91-9210740008',
    type: 'Toll Free',
    status: 'Expired'
  },
  {
    id: 6,
    checkBox: 'hello',
    countryName: 'China',
    cityName: 'Beijing',
    phoneNumber: '+91-9210740008',
    type: 'Paid',
    status: 'Deactivted'
  }
];

class AssociatedNumbers extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      list: list
    };
    this.handleClick = this.handleClick.bind(this);
  }

  handleClick(item) {
    let updatedList = this.state.list.map(obj => {
      if (obj.id === item.id) {
        return Object.assign({}, obj, {
          hidden: !item.hidden
        });
      }
      return obj;
    });
    this.setState({
      list: updatedList,
    });
  }

  render() {
    return (
      <div className="ibox">
        <div className="ibox-title">
          <h5>Associated Numbers</h5>
        </div>
        <div className="ibox-content">
          <Row className="m-b-15">
            <Col md={4} className="m-b-15 showD">
              {/* <span>Show</span>
              <span className="droptablelist"><Dropdown options={options3} onChange={this._onSelect} placeholder="0" /></span>
              <span>entries</span> */}
            </Col>
            <Col md={4}>
              <div className="centerBtn">
                <ButtonGroup>
                  <Button>Global Access Numbers</Button>
                  <Button>Dedicated DID Numbers</Button>
                </ButtonGroup>
              </div>
            </Col>
            <Col md={4} className="m-b-15">
              <ul className="tableallSearch">
                {/* <li>Search:</li>
                <li>
                  <FormGroup>
                    <InputGroup>
                      <FormControl type="text" placeholder="Search" className="fShadow" />
                      <a href="/" className="input-group-addon">
                        <i className="fa fa-search"></i>
                      </a>
                    </InputGroup>
                  </FormGroup>
                </li> */}
                <li>
                  <div className="topBarbtn">
                    <SplitButton title="Dropdown" pullRight id="split-button-pull-right">
                      <MenuItem eventKey="3">Download CSV</MenuItem>
                      <MenuItem divider />
                      <MenuItem eventKey="4">Download Excel</MenuItem>
                    </SplitButton>
                  </div>
                </li>
              </ul>
            </Col>
          </Row>

          <Row className="gTable-new">
            <Table responsive className="table-bordered">
              <thead>
                <tr>
                  <th width="2%" className="firstCheck">
                    <div className="checkbox checkbox-week checkbox-inline">
                      <input type="checkbox" id="inlineRadio1" value="option1" name="radioInline" />
                      <label htmlFor="inlineRadio1"></label>
                    </div>
                  </th>
                  <th className="sorting">Country Name</th>
                  <th className="sorting">City Name</th>
                  <th>Phone Number</th>
                  <th>Type</th>
                  <th>Status</th>
                </tr>
                <tr>
                  <th>&nbsp;</th>
                  <th>
                    <FormGroup>
                      <InputGroup>
                        <FormControl type="text" placeholder="country" className="fShadow" />
                        <InputGroup.Addon>
                          <i className="fa fa-search"></i>
                        </InputGroup.Addon>
                      </InputGroup>
                    </FormGroup>
                  </th>
                  <th>
                    <FormGroup>
                      <InputGroup>
                        <FormControl type="text" placeholder="city" className="fShadow" />
                        <InputGroup.Addon>
                          <i className="fa fa-search"></i>
                        </InputGroup.Addon>
                      </InputGroup>
                    </FormGroup>
                  </th>
                  <th>
                    <FormGroup>
                      <InputGroup>
                        <FormControl type="text" placeholder="phone number" className="fShadow" />
                        <InputGroup.Addon>
                          <i className="fa fa-search"></i>
                        </InputGroup.Addon>
                      </InputGroup>
                    </FormGroup>
                  </th>
                  <th><Dropdown options={options} onChange={this._onSelect} placeholder="Select" /></th>
                  <th><Dropdown options={options2} onChange={this._onSelect} placeholder="Select" /></th>
                </tr>
              </thead>
              <tbody>
                {this.state.list.map(item =>
                  [
                    <tr key={item.itemId}>
                      <td>
                        <div className="checkbox checkbox-week checkbox-inline">
                          <input type="checkbox" id="inlineRadio1" value="option1" name="radioInline" />
                          <label htmlFor="inlineRadio1"></label>
                        </div>
                      </td>
                      <td>{item.countryName}</td>
                      <td>{item.cityName}</td>
                      <td>{item.phoneNumber}</td>
                      <td>{item.type}</td>
                      <td
                        className={
                        item.status === 'Active' ? "text-info" 
                        : item.status === 'Deactivted' ? "text-danger" 
                        : ""}
                      >{item.status}</td>
                    </tr>
                  ]
                )}
              </tbody>
            </Table>
          </Row>

          <Row>
            <Col md={6} mdPush={6}>
              <div className="table-pag">
                <Pagination
                  first='fast_rewind'
                  next='play_arrow'
                  prev='play_arrow'
                  last='fast_forward'
                  ellipsis
                  boundaryLinks
                  items={4}
                  maxButtons={4}
                />
              </div>
            </Col>
          </Row>
        </div>
      </div>
    );
  }
}

export default AssociatedNumbers;