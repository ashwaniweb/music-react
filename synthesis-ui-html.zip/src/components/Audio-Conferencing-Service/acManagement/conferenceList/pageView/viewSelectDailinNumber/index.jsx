import React from 'react';
import { Row, Col, ButtonToolbar, Button, Table, FormControl } from 'react-bootstrap';
import Dropdown from 'react-dropdown';

// Other file call
import './selectDailinNumber.scss';

class ViewSelectDailinNumber extends React.Component {
  render() {
    return (
      <div className="ibox m-0">
        <div className="ibox-title">
          <h5>Dail-In Number for Conference</h5>
        </div>
        <div className="ibox-content">
          <Row className="gTable">
            <Table responsive className="table-bordered">
              <thead>
                <tr>
                  <th>Country Name</th>
                  <th>City Name</th>
                  <th>Phone Number</th>
                  <th>Type</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td colSpan="5" className="tdhead">
                    Dedicated
                  </td>
                </tr>
                <tr>
                  <td>Malta</td>
                  <td>Valletta</td>
                  <td>+91-9210740008</td>
                  <td>Paid</td>
                  <td>
                    <span className="active">Active</span>
                  </td>
                </tr> 
                <tr>
                  <td>United Kingdom</td>
                  <td>London</td>
                  <td>+91-9210740090</td>
                  <td>Toll Free</td>
                  <td>
                    <span className="active">Active</span>
                  </td>
                </tr> 
                <tr>
                  <td>India</td>
                  <td>New Delhi</td>
                  <td>+91-9210740008</td>
                  <td>Toll Free</td>
                  <td>
                    <span className="deactive">Deactivated</span>
                  </td>
                </tr> 
                <tr>
                  <td>India</td>
                  <td>Nodia</td>
                  <td>+91-9210740008</td>
                  <td>Toll Free</td>
                  <td>
                    <span className="expired">Expired</span>
                  </td>
                </tr> 
                <tr>
                  <td>China</td>
                  <td>Beijing</td>
                  <td>+91-9210740008</td>
                  <td>Paid</td>
                  <td>
                    <span className="active">Active</span>
                  </td>
                </tr>
                <tr>
                  <td colSpan="5" className="tdhead">
                    Global
                  </td>
                </tr>
                <tr>
                  <td>China</td>
                  <td>Shanghai</td>
                  <td>+696 2563 220</td>
                  <td>Paid</td>
                  <td>
                    <span className="active">Active</span>
                  </td>
                </tr>
                <tr>
                  <td>India</td>
                  <td>New Delhi</td>
                  <td>+91-9210740111</td>
                  <td>Toll Free</td>
                  <td>
                    <span className="deactive">Deactivated</span>
                  </td>
                </tr>               
              </tbody>
            </Table>
          </Row>

          <Row>
            <Col md={12} className="text-center">
              <Button className="btn-submit">View CDR</Button>
              <Button className="btn-cancel">Close this Window</Button>
            </Col>
          </Row>
        </div>
      </div>
    );
  }
}

export default ViewSelectDailinNumber;