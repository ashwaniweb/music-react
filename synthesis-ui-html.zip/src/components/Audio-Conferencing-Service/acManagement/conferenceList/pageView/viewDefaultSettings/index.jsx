import React from 'react';
import { Row, Col} from 'react-bootstrap';
// import { Scrollbars } from 'react-custom-scrollbars';
// import { bootstrapUtils } from 'react-bootstrap/lib/utils';
import { Link } from 'react-router-dom'
// Other file call
import './defaultSettings.scss';

class ViewDefaultSettings extends React.Component {
  render() {
    return (
      <div className="flex flex-col ibox">
        <div className="ibox-title">
          <h5>Default Settings</h5>
        </div>
        <div className="ibox-content">
          <Row>
            <Col md={12}>
              <div className="form-group">
                <strong>Record Your Conference</strong><br />
                Yes <Link to="/">(Show)</Link>
              </div>
            </Col>
            <Col md={12}>
              <div className="form-group">
                <strong>Keep Participants on Hold Until the Leader Joins</strong><br />
                Yes 
              </div>
            </Col>
            <Col md={12}>
              <div className="form-group">
                <strong>Play Music on Hold</strong><br />
                Yes
              </div>
            </Col>
            <Col md={12}>
              <div className="form-group">
                <strong>Added Participants</strong><br />
                <div className="droppable">
                  <span className="dropped-elem">Aleksandar Pavlovikj</span>
                  <span className="dropped-elem">Soumya Bhardwaj</span>
                  <span className="dropped-elem">Shamim Saifi</span>
                  <span className="dropped-elem">Aswani Singh</span>
                  <span className="dropped-elem">Ganga Singh Thakur</span>
                  <span className="dropped-elem">George Victor Adade</span>
                  <span className="dropped-elem">Abdur Rehman Siddiqui</span>
                  <span className="dropped-elem">Manish Badola</span>
                  <span className="dropped-elem">Pinki Sharma</span>
                  <span className="dropped-elem">Pradeep Kaushal</span>
                  <span className="dropped-elem">Navdeep Singh Chawla</span>
                  <span className="dropped-elem">Ankit Lakhera</span>
                </div>
              </div>
            </Col>
          </Row>
        </div>
      </div>
    );
  }
}

export default ViewDefaultSettings;