import React from 'react';
import { Row, Col, FormGroup, FormControl, ControlLabel, ButtonToolbar, Button, InputGroup } from 'react-bootstrap';
import Dropdown from 'react-dropdown';
import { bootstrapUtils } from 'react-bootstrap/lib/utils';
// Other file call
import './conferenceRecurrence.scss';

class ViewConferenceRecurrence extends React.Component {
  render() {
    bootstrapUtils.addStyle(Button, 'conBtn');
    return (
      <div className="ibox">
        <div className="ibox-title">
          <h5>Conference Recurrence</h5>
        </div>
        <div className="ibox-content">
          <div className="form-area">
            <Row>
              <Col md={6}>
                <div className="form-group">
                  <strong>Weekly</strong><br />
                  Reccur every <b className="viewColor">1st</b> week of <b className="viewColor">Sunday, Monday</b>
                </div>
              </Col>
              <Col md={6}>
                <div className="form-group">
                  <strong>Conference End Date</strong><br />
                  July 28th, 2017
                </div>
              </Col>
              <Col md={6}>
                <div className="form-group">
                  <strong>Generate New PIN</strong><br />
                  Yes
                </div>
              </Col>
              <Col md={6}>
                <div className="form-group">
                  <strong>Send Invites</strong><br />
                  Yes
                </div>
              </Col>
            </Row>
          </div>
        </div>
      </div>
    );
  }
}

export default ViewConferenceRecurrence;