import React from 'react';
import Dropdown from 'react-dropdown';
// import ReactDOM from 'react-dom';
import Slider, { Range } from 'rc-slider';
import { Row, Col, Grid, FormGroup, FormControl, ControlLabel } from 'react-bootstrap';

// Other file call
import './viewConferenceDetails.scss';
import 'rc-slider/assets/index.css';

class ViewConferenceDetails extends React.Component {
  render() {
    return (
      <div className="ibox">
        <div className="ibox-title">
          <h5>Conference Details</h5>
        </div>
        <div className="ibox-content">
          <div className="form-area">
            <Row>
              <Col md={6}>
                <div className="form-group">
                  <strong>Conference Name</strong><br />
                  Fresh Brew in to House
                </div>
              </Col>
              <Col md={6}>
                <div className="form-group">
                  <strong>Participant Limit</strong><br />
                  15
                </div>
              </Col>
              <Col md={6}>
                <div className="form-group">
                  <strong>Conference Leader PIN</strong><br />
                  2541263
                </div>
              </Col>
              <Col md={6}>
                <div className="form-group">
                  <strong>Conference Participant PIN</strong><br />
                  2516329
                </div>
              </Col>
              <Col md={6}>
                <div className="form-group">
                  <strong>Nearest Server Location</strong><br />
                  Bangalore
                </div>
              </Col>
              <Col md={6}>
                <div className="form-group">
                  <strong>Auto Dial</strong><br />
                  Yes
                </div>
              </Col>
              <Col md={6}>
                <div className="form-group">
                  <strong>Date</strong><br />
                  July 28th, 2017
                </div>
              </Col>
              <Col md={6}>
                <div className="form-group">
                  <strong>Time</strong><br />
                  05:30 PM
                </div>
              </Col>
              <Col md={6}>
                <div className="form-group">
                  <strong>Duration</strong><br />
                  25 Minutes
                </div>
              </Col>
              <Col md={6}>
                <div className="form-group">
                  <strong>Auto Dial</strong><br />
                  Yes
                </div>
              </Col>
            </Row>
          </div> 
        </div>
      </div>
    );
  }
}

export default ViewConferenceDetails;