import React from 'react';
import { Col } from 'react-bootstrap';

import ViewConferenceDetails from './viewConferenceDetails';
import ViewDefaultSettings from './viewDefaultSettings';
import ViewConferenceRecurrence from './viewConferenceRecurrence';
import ViewSelectDailinNumber from './viewSelectDailinNumber';

// Other file call

class PageView extends React.Component {
  render() {
    return (
      <div className="flex flex-row structure">
        <Col md={7} className="flex flex-row structure-7">
          <ViewConferenceDetails />
          <ViewConferenceRecurrence />
        </Col>
        <Col md={5} className="flex flex-row structure-5">
          <ViewDefaultSettings />
        </Col>
        <Col md={12} className="flex flex-row structure-12">
          <ViewSelectDailinNumber />
        </Col>
      </div>
    );
  }
}

export default PageView;