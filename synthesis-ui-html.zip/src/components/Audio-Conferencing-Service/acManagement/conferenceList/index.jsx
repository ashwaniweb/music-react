import React from 'react';
import { Row, Col, Table, FormControl, Pagination, OverlayTrigger, Tooltip, SplitButton, MenuItem, FormGroup, InputGroup, Modal } from 'react-bootstrap';
import Dropdown from 'react-dropdown';

import { Link } from 'react-router-dom';
import Slider, { Range } from 'rc-slider';
// Other file call
import './conferenceList.scss';

import PageView from './pageView';

var createReactClass = require('create-react-class');

const options = [
  'Reserved', 'Un-Reserved'
]

const LinkWithTooltip = createReactClass({
  render() {
    let tooltip = <Tooltip id={this.props.id}>{this.props.tooltip}</Tooltip>;

    return (
      <OverlayTrigger
        overlay={tooltip}
        placement="top"
        delayShow={300}
        delayHide={150}
      >
        <a href={this.props.href}>{this.props.children}</a>
      </OverlayTrigger>
    );
  }
});
const list = [
  {
    id: 1,
    name: "Meeting",
    participants: "1",
    Date: '14/12/2017',
    sTime: '03:30 PM',
    eTime: '11:30 PM',
    status: 'Non-Live',
    type: 'Un-reserved',
    cdr: 'View',
    rec: 'View',
    hidden: true
  },
  {
    id: 2,
    name: "conssfname",
    participants: "3",
    Date: '11/12/2017',
    sTime: '03:30 PM',
    eTime: '11:30 PM',
    status: 'Non-Live',
    type: 'Un-reserved',
    cdr: 'View',
    rec: 'View',
    hidden: true
  },
  {
    id: 3,
    name: "Test",
    participants: "10",
    Date: '10/12/2017',
    sTime: '03:30 PM',
    eTime: '11:30 PM',
    status: 'Non-Live',
    type: 'Un-reserved',
    cdr: 'View',
    rec: 'View',
    hidden: true
  },
  {
    id: 4,
    name: "Meeting",
    participants: "1",
    Date: '14/12/2017',
    sTime: '03:30 PM',
    eTime: '11:30 PM',
    status: 'Non-Live',
    type: 'Un-reserved',
    cdr: 'View',
    rec: 'View',
    hidden: true
  },
  {
    id: 5,
    name: "conssfname",
    participants: "3",
    Date: '11/12/2017',
    sTime: '03:30 PM',
    eTime: '11:30 PM',
    status: 'Non-Live',
    type: 'Un-reserved',
    cdr: 'View',
    rec: 'View',
    hidden: true
  },
  {
    id: 6,
    name: "Test",
    participants: "10",
    Date: '10/12/2017',
    sTime: '03:30 PM',
    eTime: '11:30 PM',
    status: 'Non-Live',
    type: 'Un-reserved',
    cdr: 'View',
    rec: 'View',
    hidden: true
  },
  {
    id: 7,
    name: "Test",
    participants: "10",
    Date: '10/12/2017',
    sTime: '03:30 PM',
    eTime: '11:30 PM',
    status: 'Non-Live',
    type: 'Un-reserved',
    cdr: 'View',
    rec: 'View',
    hidden: true
  },
  {
    id: 8,
    name: "Test",
    participants: "10",
    Date: '10/12/2017',
    sTime: '03:30 PM',
    eTime: '11:30 PM',
    status: 'Non-Live',
    type: 'Un-reserved',
    cdr: 'View',
    rec: 'View',
    hidden: true
  },
  {
    id: 9,
    name: "Test",
    participants: "10",
    Date: '10/12/2017',
    sTime: '03:30 PM',
    eTime: '11:30 PM',
    status: 'Non-Live',
    type: 'Un-reserved',
    cdr: 'View',
    rec: 'View',
    hidden: true
  },
  {
    id: 10,
    name: "Test",
    participants: "10",
    Date: '10/12/2017',
    sTime: '03:30 PM',
    eTime: '11:30 PM',
    status: 'Non-Live',
    type: 'Un-reserved',
    cdr: 'View',
    rec: 'View',
    hidden: true
  },
];

class ConferenceList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      list: list,
      show: false,
      cancel: false,
      deleteItem: false,
      modalShow: false,
      temp_id: false      
    };
    this.showModal = this.showModal.bind(this);
    this.cancel = this.cancel.bind(this);
    this.handleClick = this.handleClick.bind(this);
    this.handleShow = this.handleShow.bind(this);
    this.handleHide = this.handleHide.bind(this);
  }

  handleClick(item) {
    let updatedList = this.state.list.map(obj => {
      if (obj.id === item.id) {
        return Object.assign({}, obj, {
          hidden: !item.hidden
        });      
      }
      return obj;
    });
    this.setState({
      list: updatedList,
    });
  }

  handleShow() {
    this.setState({ show: true });
  }

  handleHide() {
    this.setState({ show: false });
  }

  cancel() {
    this.setState({
      cancel: !this.state.cancel,
      modalShow: false
    })
  }

  showModal(item) {   
    this.setState({
      cancel: true,
      modalShow: true,        
      temp_id: item
    });
  }

  deleteItem(item){
    const newState = this.state.list;
  	if (newState.indexOf(item) > -1) {
    	newState.splice(newState.indexOf(item), 1);
      this.setState({
        list: newState,
        cancel: false,
        modalShow: false        
      })
    }
  }

  render() {
    return (
      <div className="ibox">
        <div className="ibox-title">
          <h5>Conference List</h5>
          <div className="topBarbtn">
            <SplitButton title="Dropdown" pullRight id="split-button-pull-right">
              <MenuItem eventKey="3">Download CSV</MenuItem>
              <MenuItem divider />
              <MenuItem eventKey="4">Download Excel</MenuItem>
            </SplitButton>
          </div>
        </div>
        <div className="ibox-content">
          <Row className="gTable-new">
            <Table responsive className="table-bordered">
              <thead>
                <tr>
                  <th width="20%" className="sorting">Conference Name</th>
                  <th width="10%" className="sorting">Participants Limit</th>
                  <th width="10%" className="sorting">Date</th>
                  <th width="10%" className="sorting">Start Time</th>
                  <th width="10%" className="sorting">End Time</th>
                  <th width="10%" className="text-center">Type</th>                  
                  <th width="5%" className="text-center">CDR</th>
                  <th width="5%" className="text-center">Rec</th>
                  <th width="10%" className="text-center">Action</th>
                </tr>
                <tr>
                  <th>
                    <FormGroup>
                      <InputGroup>
                        <FormControl type="text" placeholder="Search" className="fShadow" />
                        <InputGroup.Addon>
                          <i className="fa fa-search"></i>
                        </InputGroup.Addon>
                      </InputGroup>
                    </FormGroup>
                  </th>
                  <th>
                    <FormGroup>
                      <InputGroup>
                        <FormControl type="text" placeholder="Search" className="fShadow" />
                        <InputGroup.Addon>
                          <i className="fa fa-search"></i>
                        </InputGroup.Addon>
                      </InputGroup>
                    </FormGroup>
                  </th>
                  <th>&nbsp;</th>
                  <th>&nbsp;</th>
                  <th>&nbsp;</th>
                  <th>
                    <Dropdown options={options} onChange={this._onSelect} placeholder="Select" />
                  </th>
                  <th>&nbsp;</th>
                  <th>&nbsp;</th>
                </tr>
              </thead>
              <tbody>
                {this.state.list.map(item =>
                  [
                    <tr key={item.itemId}>
                      <td>
                        {item.name}
                        <span onClick={() => this.handleClick(item)} className="material-icons pointer">{!this.state.hidden ? 'keyboard_arrow_down':'keyboard_arrow_up'}</span>
                      </td>
                      <td className="text-center">{item.participants}</td>
                      <td className="text-center">{item.Date}</td>
                      <td className="text-center">{item.sTime}</td>
                      <td className="text-center">{item.eTime}</td>
                      <td className="text-center">{item.type}</td>                      
                      <td className="text-center"><Link to="/audio/account-management/CRD-List">{item.cdr}</Link></td>
                      <td className="text-center"><Link to="/audio/account-management/recording-list">{item.rec}</Link></td>
                      <td className="action-wrap text-center">
                        <Link tooltip="View" to={this.handleShow} onClick={this.handleShow} id={'tooltip-' - { item }}>
                          <i className="material-icons">remove_red_eye</i>
                        </Link>
                        <LinkWithTooltip tooltip="Edit" href="/audio/account-management/edit-new-conference" id={'tooltip-' - { item }}>
                          <i className="material-icons">border_color</i>
                        </LinkWithTooltip>
                        <LinkWithTooltip tooltip="Delete" href="javascript:void('0')" id={'tooltip-' - { item }}>
                          <i onClick={() => this.showModal(item)} className="material-icons">delete</i>
                        </LinkWithTooltip>
                        <LinkWithTooltip tooltip="Dial" href="javascript:void('0')" id={'tooltip-' - { item }}>
                          <i className="material-icons">dialpad</i>
                        </LinkWithTooltip>
                      </td>
                    </tr>,
                    <tr hidden={item.hidden} className="details-row"key={item.id}>
                      <td colSpan="10">
                        <div className="details-container">
                          <table className="details-table">
                            <tbody>
                              <tr>
                                <td className="title">
                                  Conference Participant Pin
                                  <span>{item.id}5414{item.id}</span>
                                </td>
                                <td className="title">
                                  Conference Leader Pin
                                  <span>6{item.id}4795</span>
                                </td>
                                <td className="title">
                                  Conference Access/DID/DDI {item.id}
                                  <span>98{item.id}514</span>
                                </td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </td>
                    </tr>
                  ]
                )}
              </tbody>
            </Table>
          </Row>
          <Row>
            <Col md={6} className="allentries">
              Showing 1 to 1 of 1 entries
            </Col>
            <Col md={6}>
              <div className="table-pag">
                <Pagination
                  first='fast_rewind'
                  next='play_arrow'
                  prev='play_arrow'
                  last='fast_forward'
                  ellipsis
                  boundaryLinks
                  items={5}
                  maxButtons={5}
                />
              </div>
            </Col>
          </Row>
        </div>
        
        <Modal
          {...this.props}
          show={this.state.show}
          onHide={this.handleHide}
          dialogClassName="modal-lg audioView"
        >     
          <Modal.Body>
            <Modal.Header closeButton></Modal.Header>            
              <PageView />
          </Modal.Body>
        </Modal>
        <div className={!this.state.modalShow ? 'myModal' : 'myModal show'}>
          <div className='myModal-content modal-sm'>
            <div className="myModal-header"></div>
            <div className="myModal-body">
              <img src="/images/delete.png" alt="Delete" />
              <p>Are you sure you want to delete this conference?</p>
            </div>
            <div className="myModal-footer">
              <button className="btn btn-submit" onClick={() => this.deleteItem(this.state.temp_id)}>Yes</button>
              <button className="btn btn-cancel" onClick={this.cancel}>Cancel</button>
            </div>
          </div>
          <div className={!this.state.modalShow ? 'myModal-overlay' : 'myModal-overlay show'} />
        </div>
      </div>
    );
  }
}

export default ConferenceList;