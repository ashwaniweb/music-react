import React from 'react';
import { Row, Col, Table, FormControl, Pagination, OverlayTrigger, Tooltip, SplitButton, MenuItem, FormGroup, InputGroup } from 'react-bootstrap';
import Dropdown from 'react-dropdown';
// Other file call
import './globalAccessNumbers.scss';
var createReactClass = require('create-react-class');

const options = [
  'Reserved', 'Un-Reserved'
]

const LinkWithTooltip = createReactClass({
  render() {
    let tooltip = <Tooltip id={this.props.id}>{this.props.tooltip}</Tooltip>;
    return (
      <OverlayTrigger
        overlay={tooltip}
        placement="top"
        delayShow={300}
        delayHide={150}
      >
        <a href={this.props.href}>{this.props.children}</a>
      </OverlayTrigger>
    );
  }
});
const list = [
  {
    id: 1,
    name: "Meeting",
    participants: "1",
    Date: '14/12/2017',
    sTime: '03:30 PM',
    eTime: '11:30 PM',
    status: 'Non-Live',
    type: 'Un-reserved',
    cdr: 'View',
    rec: 'View',
    hidden: true
  },
  {
    id: 2,
    name: "conssfname",
    participants: "3",
    Date: '11/12/2017',
    sTime: '03:30 PM',
    eTime: '11:30 PM',
    status: 'Non-Live',
    type: 'Un-reserved',
    cdr: 'View',
    rec: 'View',
    hidden: true
  },
  {
    id: 3,
    name: "Test",
    participants: "10",
    Date: '10/12/2017',
    sTime: '03:30 PM',
    eTime: '11:30 PM',
    status: 'Non-Live',
    type: 'Un-reserved',
    cdr: 'View',
    rec: 'View',
    hidden: true
  },
  {
    id: 4,
    name: "Meeting",
    participants: "1",
    Date: '14/12/2017',
    sTime: '03:30 PM',
    eTime: '11:30 PM',
    status: 'Non-Live',
    type: 'Un-reserved',
    cdr: 'View',
    rec: 'View',
    hidden: true
  },
  {
    id: 5,
    name: "conssfname",
    participants: "3",
    Date: '11/12/2017',
    sTime: '03:30 PM',
    eTime: '11:30 PM',
    status: 'Non-Live',
    type: 'Un-reserved',
    cdr: 'View',
    rec: 'View',
    hidden: true
  },
  {
    id: 6,
    name: "Test",
    participants: "10",
    Date: '10/12/2017',
    sTime: '03:30 PM',
    eTime: '11:30 PM',
    status: 'Non-Live',
    type: 'Un-reserved',
    cdr: 'View',
    rec: 'View',
    hidden: true
  },
  {
    id: 7,
    name: "Test",
    participants: "10",
    Date: '10/12/2017',
    sTime: '03:30 PM',
    eTime: '11:30 PM',
    status: 'Non-Live',
    type: 'Un-reserved',
    cdr: 'View',
    rec: 'View',
    hidden: true
  },
  {
    id: 8,
    name: "Test",
    participants: "10",
    Date: '10/12/2017',
    sTime: '03:30 PM',
    eTime: '11:30 PM',
    status: 'Non-Live',
    type: 'Un-reserved',
    cdr: 'View',
    rec: 'View',
    hidden: true
  },
  {
    id: 9,
    name: "Test",
    participants: "10",
    Date: '10/12/2017',
    sTime: '03:30 PM',
    eTime: '11:30 PM',
    status: 'Non-Live',
    type: 'Un-reserved',
    cdr: 'View',
    rec: 'View',
    hidden: true
  },
  {
    id: 10,
    name: "Test",
    participants: "10",
    Date: '10/12/2017',
    sTime: '03:30 PM',
    eTime: '11:30 PM',
    status: 'Non-Live',
    type: 'Un-reserved',
    cdr: 'View',
    rec: 'View',
    hidden: true
  },
];
// Other file call

class GlobalAccessNumbers extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      list: list
    };
    this.handleClick = this.handleClick.bind(this);
  }

  handleClick(item) {
    let updatedList = this.state.list.map(obj => {
      if (obj.id === item.id) {
        return Object.assign({}, obj, {
          hidden: !item.hidden
        });      
      }
      return obj;
    });
    this.setState({
      list: updatedList,
    });
  }

  render() {
    return (
      <div className="ibox">
        <div className="ibox-title">
          <h5>Global Access Numbers</h5>
          <div className="topBarbtn">
            <SplitButton title="Dropdown" pullRight id="split-button-pull-right">
              <MenuItem eventKey="1">Action</MenuItem>
              <MenuItem eventKey="2">Another action</MenuItem>
              <MenuItem eventKey="3">Something else here</MenuItem>
              <MenuItem divider />
              <MenuItem eventKey="4">Separated link</MenuItem>
            </SplitButton>
          </div>
        </div>
        <div className="ibox-content">
          <Row className="gTable-new">
            <Table responsive className="table-bordered">
              <thead>
                <tr>
                  <th width="20%" className="sorting">Conference Name</th>
                  <th width="10%" className="sorting">Participants Limit</th>
                  <th width="10%" className="sorting">Date</th>
                  <th width="10%" className="sorting">Start Time</th>
                  <th width="10%" className="sorting">End Time</th>
                  <th width="10%" className="text-center">Type</th>                  
                  <th width="5%" className="text-center">CDR</th>
                  <th width="5%" className="text-center">Rec</th>
                  <th width="10%" className="text-center">Action</th>
                </tr>
                <tr>
                  <th>
                    <FormGroup>
                      <InputGroup>
                        <FormControl type="text" placeholder="Search" className="fShadow" />
                        <InputGroup.Addon>
                          <i className="fa fa-search"></i>
                        </InputGroup.Addon>
                      </InputGroup>
                    </FormGroup>
                  </th>
                  <th>
                    <FormGroup>
                      <InputGroup>
                        <FormControl type="text" placeholder="Search" className="fShadow" />
                        <InputGroup.Addon>
                          <i className="fa fa-search"></i>
                        </InputGroup.Addon>
                      </InputGroup>
                    </FormGroup>
                  </th>
                  <th>&nbsp;</th>
                  <th>&nbsp;</th>
                  <th>&nbsp;</th>
                  <th>
                    <Dropdown options={options} onChange={this._onSelect} placeholder="Select" />
                  </th>
                  <th>&nbsp;</th>
                  <th>&nbsp;</th>
                </tr>
              </thead>
              <tbody>
                {this.state.list.map(item =>
                  [
                    <tr key={item.itemId}>
                      <td>
                        {item.name}
                        <span onClick={() => this.handleClick(item)} className="material-icons pointer">{!this.state.hidden ? 'keyboard_arrow_down':'keyboard_arrow_up'}</span>
                      </td>
                      <td className="text-center">{item.participants}</td>
                      <td className="text-center">{item.Date}</td>
                      <td className="text-center">{item.sTime}</td>
                      <td className="text-center">{item.eTime}</td>
                      <td className="text-center">{item.type}</td>                      
                      <td className="text-center">{item.cdr}</td>
                      <td className="text-center">{item.rec}</td>
                      <td className="action-wrap text-center">
                        <LinkWithTooltip tooltip="View" href="javascript:void('0')" id={'tooltip-' - { item }}>
                          <i className="material-icons">remove_red_eye</i>
                        </LinkWithTooltip>
                        <LinkWithTooltip tooltip="Edit" href="javascript:void('0')" id={'tooltip-' - { item }}>
                          <i className="material-icons">border_color</i>
                        </LinkWithTooltip>
                        <LinkWithTooltip tooltip="Delete" href="javascript:void('0')" id={'tooltip-' - { item }}>
                          <i className="material-icons">delete</i>
                        </LinkWithTooltip>
                        <LinkWithTooltip tooltip="Dial" href="javascript:void('0')" id={'tooltip-' - { item }}>
                          <i className="material-icons">dialpad</i>
                        </LinkWithTooltip>
                      </td>
                    </tr>,
                    <tr hidden={item.hidden} className="details-row"key={item.id}>
                      <td colSpan="10">
                        <div className="details-container">
                          <table className="details-table">
                            <tbody>
                              <tr>
                                <td className="title">
                                  Conference Participant Pin
                                  <span>{item.id}5414{item.id}</span>
                                </td>
                                <td className="title">
                                  Conference Leader Pin
                                  <span>6{item.id}4795</span>
                                </td>
                                <td className="title">
                                  Conference Access/DID/DDI {item.id}
                                  <span>98{item.id}514</span>
                                </td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </td>
                    </tr>
                  ]
                )}
              </tbody>
            </Table>
          </Row>
          <Row>
            <Col md={6} className="allentries">
              Showing 1 to 1 of 1 entries
            </Col>
            <Col md={6}>
              <div className="table-pag">
                <Pagination
                  prev="Previous"
                  next="Next"
                  ellipsis
                  boundaryLinks
                  items={5}
                  maxButtons={5}
                />
              </div>
            </Col>
          </Row>
        </div>
      </div>
    );
  }
}

export default GlobalAccessNumbers;