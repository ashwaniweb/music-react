import React from 'react';
import { Row, Col, Grid } from 'react-bootstrap';
// Other file call

class ConferenceList extends React.Component {
  render() {
    return (
      <div>
        <Col md={7}>
          <h5>Hello</h5>
          <table className="table table-bordered">
            <tr>
              <td>hello</td>
              <td>hello</td>
              <td>hello</td>
              <td>hello</td>
              <td>hello</td>
            </tr>
          </table>
        </Col>
      </div>
    );
  }
}

export default ConferenceList;