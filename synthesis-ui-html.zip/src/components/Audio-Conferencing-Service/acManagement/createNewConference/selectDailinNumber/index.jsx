import React from 'react';
import { Row, Col, ButtonToolbar, Button, Table, FormControl } from 'react-bootstrap';
import Dropdown from 'react-dropdown';

// Other file call
import './selectDailinNumber.scss';

const options = [
  'Paid', 'Toll Free'
]
const options2 = [
  'Active', 'Deactivated', 'Expired'
]

class SelectDailinNumber extends React.Component {
  render() {
    return (
      <div className="ibox m-0">
        <div className="ibox-title">
          <h5>Select Dail-In Number for Conference</h5>
        </div>
        <div className="ibox-content">
          <Row className="m-b-15">
            <Col md={12} className="m-b-15">
              <ButtonToolbar>
                <Button bsStyle="conBtn" className="active">Dedicated</Button>
                <Button bsStyle="conBtn">Global</Button>
                <Button bsStyle="conBtn">Both</Button>
              </ButtonToolbar>
            </Col>
          </Row>

          <Row className="gTable">
            <Table responsive className="table-bordered">
              <thead>
                <tr>
                  <th className="text-center no-sorting">
                    <div className="checkbox checkbox-week checkbox-inline">
                      <input type="checkbox" id="inlineRadio1" value="option1" name="radioInline" />
                        <label htmlFor="inlineRadio1"></label>
                    </div>
                  </th>
                  <th className="sorting">Country Name</th>
                  <th className="sorting">City Name</th>
                  <th className="sorting">Phone Number</th>
                  <th className="sorting">Type</th>
                  <th className="sorting">Status</th>
                </tr>
                <tr>
                  <th>&nbsp;</th>
                  <th>
                    <FormControl type="text" placeholder="country name" />
                  </th>
                  <th>
                    <FormControl type="text" placeholder="city name" />
                  </th>
                  <th>
                    <FormControl type="text" placeholder="phone number" />
                  </th>
                  <th>
                    <Dropdown options={options} onChange={this._onSelect} placeholder="Select" />
                  </th>
                  <th>
                    <Dropdown options={options2} onChange={this._onSelect} placeholder="Select" />
                  </th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td colSpan="6" className="tdhead">
                    Dedicated
                  </td>
                </tr>
                <tr>
                  <td className="text-center">
                    <div className="checkbox checkbox-week checkbox-inline">
                      <input type="checkbox" id="inlineRadio1" value="option1" name="radioInline" />
                      <label htmlFor="inlineRadio1"></label>
                    </div>
                  </td>
                  <td>Malta</td>
                  <td>Valletta</td>
                  <td>+91-9210740008</td>
                  <td>Paid</td>
                  <td>
                    <span className="active">Active</span>
                  </td>
                </tr> 
                <tr>
                  <td className="text-center">
                    <div className="checkbox checkbox-week checkbox-inline">
                      <input type="checkbox" id="inlineRadio1" value="option1" name="radioInline" />
                      <label htmlFor="inlineRadio1"></label>
                    </div>
                  </td>
                  <td>United Kingdom</td>
                  <td>London</td>
                  <td>+91-9210740090</td>
                  <td>Toll Free</td>
                  <td>
                    <span className="active">Active</span>
                  </td>
                </tr> 
                <tr>
                  <td className="text-center">
                    <div className="checkbox checkbox-week checkbox-inline">
                      <input type="checkbox" id="inlineRadio1" value="option1" name="radioInline" />
                      <label htmlFor="inlineRadio1"></label>
                    </div>
                  </td>
                  <td>India</td>
                  <td>New Delhi</td>
                  <td>+91-9210740008</td>
                  <td>Toll Free</td>
                  <td>
                    <span className="deactive">Deactivated</span>
                  </td>
                </tr> 
                <tr>
                  <td className="text-center">
                    <div className="checkbox checkbox-week checkbox-inline">
                      <input type="checkbox" id="inlineRadio1" value="option1" name="radioInline" />
                      <label htmlFor="inlineRadio1"></label>
                    </div>
                  </td>
                  <td>India</td>
                  <td>Nodia</td>
                  <td>+91-9210740008</td>
                  <td>Toll Free</td>
                  <td>
                    <span className="expired">Expired</span>
                  </td>
                </tr> 
                <tr>
                  <td className="text-center">
                    <div className="checkbox checkbox-week checkbox-inline">
                      <input type="checkbox" id="inlineRadio1" value="option1" name="radioInline" />
                      <label htmlFor="inlineRadio1"></label>
                    </div>
                  </td>
                  <td>China</td>
                  <td>Beijing</td>
                  <td>+91-9210740008</td>
                  <td>Paid</td>
                  <td>
                    <span className="active">Active</span>
                  </td>
                </tr>
                <tr>
                  <td colSpan="6" className="tdhead">
                    Global
                  </td>
                </tr>
                <tr>
                  <td className="text-center">
                    <div className="checkbox checkbox-week checkbox-inline">
                      <input type="checkbox" id="inlineRadio1" value="option1" name="radioInline" />
                      <label htmlFor="inlineRadio1"></label>
                    </div>
                  </td>
                  <td>China</td>
                  <td>Shanghai</td>
                  <td>+696 2563 220</td>
                  <td>Paid</td>
                  <td>
                    <span className="active">Active</span>
                  </td>
                </tr>
                <tr>
                  <td className="text-center">
                    <div className="checkbox checkbox-week checkbox-inline">
                      <input type="checkbox" id="inlineRadio1" value="option1" name="radioInline" />
                      <label htmlFor="inlineRadio1"></label>
                    </div>
                  </td>
                  <td>India</td>
                  <td>New Delhi</td>
                  <td>+91-9210740111</td>
                  <td>Toll Free</td>
                  <td>
                    <span className="deactive">Deactivated</span>
                  </td>
                </tr>               
              </tbody>
            </Table>
          </Row>

          <Row>
            <Col md={12}>
              <Button className="btn-submit">Submit</Button>
              <Button className="btn-cancel">Cancel</Button>
            </Col>
          </Row>
        </div>
      </div>
    );
  }
}

export default SelectDailinNumber;