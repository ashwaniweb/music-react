import React from 'react';
import { Row, Col, FormGroup, Button, ControlLabel, Modal, OverlayTrigger, Popover, FormControl, InputGroup, ButtonGroup, ButtonToolbar } from 'react-bootstrap';
import { Scrollbars } from 'react-custom-scrollbars';
import { bootstrapUtils } from 'react-bootstrap/lib/utils';

// Other file call
import './defaultSettings.scss';
const joinStart = (
  <Popover className="top-pop" title="" id="popover-trigger-hover-focus">
    This is a information popup
  </Popover>
);
const list = [
  {
    id: 1,
    name: 'Ankit Lakhera',
    email: 'ankitcool481992@hotmail.com',
  },
  {
    id: 2,
    name: 'Ganga Singh Thakur',
    email: 'ganga.s.thakur1990@yahoomail.com',
  },
  {
    id: 3,
    name: 'Pradeep Kaushal',
    email: 'pradeep.kaushal@asergis.in',
  },
  {
    id: 4,
    name: 'Bharat Negi',
    email: 'bharat.negi85@gmail.com',
  },
  {
    id: 5,
    name: 'Shamim Saifi',
    email: 'shamim.saifi@asergis.in',
  },
  {
    id: 6,
    name: 'Ankit Lakhera',
    email: 'ankitcool481992@hotmail.com',
  },
  {
    id: 7,
    name: 'Ganga Singh Thakur',
    email: 'ganga.s.thakur1990@yahoomail.com',
  },
  {
    id: 8,
    name: 'Pradeep Kaushal',
    email: 'pradeep.kaushal@asergis.in',
  },
  {
    id: 9,
    name: 'Bharat Negi',
    email: 'bharat.negi85@gmail.com',
  },
  {
    id: 10,
    name: 'Shamim Saifi',
    email: 'shamim.saifi@asergis.in',
  },
];
const group = [
  {
    id: 1,
    name: 'Don’t Stop Believer',
    noOfPart: '6 Participants',
  },
  {
    id: 2,
    name: 'Fresh Brew in House',
    noOfPart: '4 Participants',
  },
  {
    id: 3,
    name: 'The Outdoors',
    noOfPart: '8 Participants',
  },
  {
    id: 4,
    name: 'Gossip Girl',
    noOfPart: '5 Participants',
  },
  {
    id: 5,
    name: 'Famous NYC',
    noOfPart: '10 Participants',
  }
];

class DefaultSettings extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      show: false,
      list: list,
      group: group,
      participant: true,
      addPart: false,
      modalShow: false
    };
    this.showModal = this.showModal.bind(this);
    this.hideModal = this.hideModal.bind(this);
    this.addPart = this.addPart.bind(this);
    this.cSubmit = this.cSubmit.bind(this);
    this.cancel = this.cancel.bind(this);
    this.partGroup = this.partGroup.bind(this);
  }

  showModal() {
    this.setState({
      show: true
    });
  };

  hideModal() {
    this.setState({
      show: false
    });
  };

  cSubmit() {
    this.setState({
      show: false,
      modalShow:!this.state.modalShow
    });
  };

  cancel() {
    this.setState({
      show: true,
      modalShow:!this.state.modalShow
    });
  };

  partGroup() {
    this.setState({
      participant: !this.state.participant
    });
  };

  addPart() {
    document.body.classList.toggle('darkClass', this.state.addPart);
    this.setState({
      addPart: !this.state.addPart,
    });
  };
  render() {
    bootstrapUtils.addStyle(Button, 'submit', 'cancel', 'addperson', 'addpersonbtn');
    let close = () => this.setState({ show: false });
    return (
      <div className="flex flex-col ibox">
        <div className="ibox-title">
          <h5>Default Settings</h5>
        </div>
        <div className="ibox-content">
          <div className="form-area">
            <form>
              <Row>
                <Col sm={8}>
                  <FormGroup>
                    <ControlLabel>Record your Conference</ControlLabel>
                  </FormGroup>
                </Col>
                <Col sm={4}>
                  <FormGroup>
                    <div className="pull-right">
                      <label className="switch">
                        <input type="checkbox" />
                        <span className="slider round"></span>
                      </label>
                      <div className="yn">No</div>
                    </div>
                  </FormGroup>
                </Col>
              </Row>
              <hr />
              <Row>
                <Col sm={8}>
                  <FormGroup>
                    <ControlLabel>Keep Participant on Mute when they Join</ControlLabel>
                  </FormGroup>
                </Col>
                <Col sm={4}>
                  <FormGroup>
                    <div className="pull-right">
                      <label className="switch">
                        <input type="checkbox" />
                        <span className="slider round"></span>
                      </label>
                      <div className="yn">No</div>
                    </div>
                  </FormGroup>
                </Col>
              </Row>
              <hr />
              <Row>
                <Col sm={8}>
                  <FormGroup>
                    <ControlLabel>Keep Participants on Hold until the Leader Joins</ControlLabel>
                  </FormGroup>
                </Col>
                <Col sm={4}>
                  <FormGroup>
                    <div className="pull-right">
                      <label className="switch">
                        <input type="checkbox" defaultChecked />
                        <span className="slider round"></span>
                      </label>
                      <div className="yn">Yes</div>
                    </div>
                  </FormGroup>
                </Col>
              </Row>
              <hr />
              <Row>
                <Col sm={8}>
                  <FormGroup>
                    <ControlLabel>End Conference when the Leader Hangs Up &nbsp;&nbsp;
                      <OverlayTrigger trigger={['hover', 'focus']} placement="top" overlay={joinStart}>
                        <i className="material-icons">info</i>
                      </OverlayTrigger>
                    </ControlLabel>
                  </FormGroup>
                </Col>
                <Col sm={4}>
                  <FormGroup>
                    <div className="pull-right">
                      <label className="switch">
                        <input type="checkbox" />
                        <span className="slider round"></span>
                      </label>
                      <div className="yn">No</div>
                    </div>
                  </FormGroup>
                </Col>
              </Row>
              <hr />
              <Row>
                <Col sm={8}>
                  <FormGroup>
                    <ControlLabel>Play Sound when Participant Joins</ControlLabel>
                  </FormGroup>
                </Col>
                <Col sm={4}>
                  <FormGroup>
                    <div className="pull-right">
                      <label className="switch">
                        <input type="checkbox" />
                        <span className="slider round"></span>
                      </label>
                      <div className="yn">No</div>
                    </div>
                  </FormGroup>
                </Col>
              </Row>
              <hr />
              <Row>
                <Col sm={8}>
                  <FormGroup>
                    <ControlLabel>Name of Participant Announced when Joins</ControlLabel>
                  </FormGroup>
                </Col>
                <Col sm={4}>
                  <FormGroup>
                    <div className="pull-right">
                      <label className="switch">
                        <input type="checkbox" defaultChecked />
                        <span className="slider round"></span>
                      </label>
                      <div className="yn">Yes</div>
                    </div>
                  </FormGroup>
                </Col>
              </Row>
              <hr />
              <Row>
                <Col sm={8}>
                  <FormGroup>
                    <ControlLabel>Enable Touch Tone</ControlLabel>
                  </FormGroup>
                </Col>
                <Col sm={4}>
                  <FormGroup>
                    <div className="pull-right">
                      <label className="switch">
                        <input type="checkbox" />
                        <span className="slider round"></span>
                      </label>
                      <div className="yn">No</div>
                    </div>
                  </FormGroup>
                </Col>
              </Row>
              <hr />
              <Row>
                <Col sm={8}>
                  <FormGroup>
                    <ControlLabel>Play Music on Hold</ControlLabel>
                  </FormGroup>
                </Col>
                <Col sm={4}>
                  <FormGroup>
                    <div className="pull-right">
                      <label className="switch">
                        <input type="checkbox" />
                        <span className="slider round"></span>
                      </label>
                      <div className="yn">No</div>
                    </div>
                  </FormGroup>
                </Col>
              </Row>
              <hr />
              <Row>
                <Col sm={8}>
                  <FormGroup>
                    <ControlLabel>Add Participant</ControlLabel>
                  </FormGroup>
                </Col>
                <Col sm={4}>
                  <FormGroup>
                    <div className="pull-right">
                      <label className="switch">
                        <input type="checkbox" id="addPart"
                          checked={this.state.show}
                          onChange={this.showModal} />
                        <span className="slider round"></span>
                      </label>
                      <div className="yn">No</div>
                    </div>
                  </FormGroup>
                </Col>
              </Row>
              <hr />
              <Row>
                <Col sm={8}>
                  <FormGroup>
                    <ControlLabel>Send SMS to your Participant(s)</ControlLabel>
                  </FormGroup>
                </Col>
                <Col sm={4}>
                  <FormGroup>
                    <div className="pull-right">
                      <label className="switch">
                        <input type="checkbox" defaultChecked />
                        <span className="slider round"></span>
                      </label>
                      <div className="yn">Yes</div>
                    </div>
                  </FormGroup>
                </Col>
              </Row>
              <hr />
            </form>
          </div>
        </div>
        <Modal
          {...this.props}
          show={this.state.show}
          onHide={this.hideModal}
          bsSize="large"
          dialogClassName="custom-modal"
          backdrop="static"
        >
          {!this.state.addPart ?
            <Modal.Body>
              <Row>
                <Col sm={6}>
                  <h4>
                    Select Participants
                  <ButtonGroup className="pull-right btnGroup">
                      <Button
                        className={this.state.participant ? 'active' : ''}
                        onClick={this.partGroup}>Participant</Button>
                      <Button
                        className={!this.state.participant ? 'active' : ''}
                        onClick={this.partGroup}>Group</Button>
                    </ButtonGroup>
                  </h4>
                </Col>
                <Col sm={6}>
                  <ButtonToolbar className="btnTool">
                    <Button bsStyle="default"><i className="material-icons">person_add</i> <strong>Upload CSV File</strong></Button>
                    <Button bsStyle="default" onClick={this.addPart}><i className="material-icons">note_add</i> <strong>Add New Participant</strong></Button>
                  </ButtonToolbar>
                </Col>
              </Row>
              <Row className="flexRow">
                <Col sm={6}>
                  <Scrollbars className="overlayScroll"
                    autoHeight
                    autoHeightMin={500}
                  >
                    {this.state.participant ?
                      <ul className="partList">
                        {this.state.list.map(item =>
                          <li key={item.id}>
                            <h5>{item.name}</h5>
                            <p>{item.email}</p>
                            <i className="fa fa-arrows"></i>
                          </li>
                        )}
                      </ul> :
                      <ul className="partList">
                        {this.state.group.map(item =>
                          <li key={item.id}>
                            <h5>{item.name}</h5>
                            <p><i className="material-icons">person</i> {item.noOfPart}</p>
                            <i className="fa fa-arrows"></i>
                          </li>
                        )}
                      </ul>
                    }
                  </Scrollbars>
                </Col>
                <Col sm={6}>
                  <div className="droppable">
                    {/* <span className="dropped-elem">
                    Abdur Rehman Siddiqui
                    <i className="fa fa-pencil" aria-hidden="true"></i>
                    <i className="fa fa-times" aria-hidden="true"></i>
                  </span>
                  <span className="dropped-elem">
                    Vaishali Srivastava
                    <i className="fa fa-pencil" aria-hidden="true"></i>
                    <i className="fa fa-times" aria-hidden="true"></i>
                  </span>
                  <span className="dropped-elem edit">
                    <input type="text" value="apj.kalaam@gmail.com" onChange={this.props.handleChange} />
                    <i className="fa fa-check" aria-hidden="true"></i> onClick={this.props.onHide}
                  </span> */}
                    <div className="preDrop">
                      <img src="/images/dragParticipant.png" alt="Drag Participants here to add them" />
                      <p>Drag Participants here to add them</p>
                    </div>
                  </div>
                  <div className="submitArea">
                    <Button bsStyle="submit" onClick={this.cSubmit}>Submit</Button>
                    <Button bsStyle="cancel" onClick={this.hideModal}>Cancel</Button>
                  </div>
                </Col>
              </Row>
            </Modal.Body>
            :
            <Modal.Body>
              <Row>
                <Col sm={12}>
                  <h4>
                    Add New Participant
                  <Button bsStyle="addperson" onClick={this.addPart}><i className="material-icons">arrow_back</i> Go Back</Button>
                  </h4>
                </Col>
              </Row>
              <Row>
                <Col md={4}>
                  <FormGroup>
                    <ControlLabel>First Name</ControlLabel>
                    <FormControl type="text" placeholder="first name" />
                  </FormGroup>
                </Col>
                <Col md={4}>
                  <FormGroup>
                    <ControlLabel>Last Name</ControlLabel>
                    <FormControl type="text" placeholder="last name" />
                  </FormGroup>
                </Col>
                <Col md={4}>
                  <FormGroup>
                    <ControlLabel>Email Address</ControlLabel>
                    <InputGroup className="addparemail">
                      <FormControl type="text" placeholder="email address" />
                      <InputGroup.Addon>
                        <i className="material-icons">info</i>
                      </InputGroup.Addon>
                    </InputGroup>
                  </FormGroup>
                </Col>
              </Row>
              <Row>
                <Col md={4}>
                  <FormGroup>
                    <ControlLabel>Phone Number</ControlLabel>
                    <FormControl type="text" placeholder="phone number" />
                  </FormGroup>
                </Col>
                <Col md={4}>
                  <FormGroup>
                    <ControlLabel>&nbsp;</ControlLabel>
                    <InputGroup className="addparemail">
                      <FormControl type="text" placeholder="phone number" />
                      <InputGroup.Addon>
                        <i className="material-icons">add_circle</i>
                      </InputGroup.Addon>
                    </InputGroup>
                  </FormGroup>
                </Col>
              </Row>
              <Row>
                <Col md={4}>
                  <FormGroup>
                    <ControlLabel>Designation</ControlLabel>
                    <FormControl type="text" placeholder="designation" />
                  </FormGroup>
                </Col>
                <Col md={4}>
                  <FormGroup>
                    <ControlLabel>Department</ControlLabel>
                    <FormControl type="text" placeholder="department" />
                  </FormGroup>
                </Col>
                <Col md={4}>
                  <FormGroup>
                    <ControlLabel>Organisation</ControlLabel>
                    <FormControl type="text" placeholder="organisation" />
                  </FormGroup>
                </Col>
              </Row>
              <br />
              <Row className="text-center">
                <Button bsStyle="submit" onClick={this.addPart}>Submit</Button>
              </Row>
            </Modal.Body>
          }
        </Modal>

        <div className={!this.state.modalShow ? 'myModal' : 'myModal show'}>
          <div className='myModal-content modal-sm'>
            <div className="myModal-header"></div>
            <div className="myModal-body">
              <img src="/images/added.png" alt="Delete" />
              <p>You conference has been created successfully</p>
            </div>
            <div className="myModal-footer">
              <button className="btn btn-cancel" onClick={this.cancel}>Cancel</button>
            </div>
          </div>
          <div className={!this.state.modalShow ? 'myModal-overlay' : 'myModal-overlay show'} />
        </div>
      </div>
    );
  }
}

export default DefaultSettings;