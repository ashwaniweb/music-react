import React from 'react';
import { Row, Col, FormGroup, FormControl, ControlLabel, OverlayTrigger, Popover, InputGroup } from 'react-bootstrap';
import DatePicker from 'react-date-picker';
// import TimeKeeper from 'react-timekeeper';

// Other file call
import './setConferenceTime.scss';

const joinStart = (
  <Popover id="popover-trigger-hover-focus1" className="top-pop" title="">
    popover text go here
  </Popover>
);


class SetConferenceTime extends React.Component {
  render() {
    return (
      <div>
        <div className="ibox-title p-lr-none">
          <h5>Set Conference Time</h5>
        </div>
        <div className="border-t-none">
          <div className="form-area">
            <Row>
              <Col md={12}>
                <ControlLabel>Join Start Date & Time &nbsp;
                  <OverlayTrigger trigger={['hover', 'focus']} placement="top" overlay={joinStart}>
                    <i className="material-icons">info</i>
                  </OverlayTrigger>
                </ControlLabel>
              </Col>
              <Col md={3} sm={4}>
                <FormGroup>
                    <DatePicker 
                      calendarIcon={<i className="fa fa-calendar"></i>}
                      nextLabel={<i className="fa fa-caret-right" aria-hidden="true"></i>}
                      prevLabel={<i className="fa fa-caret-left" aria-hidden="true"></i>}
                    />                    
                    {/* <FormControl type="text" placeholder="Select Date" className="fShadow" /> 
                    <InputGroup.Addon>
                      <i className="fa fa-calendar"></i>
                    </InputGroup.Addon> */}
                </FormGroup>
              </Col>
              <Col md={3} sm={4}>
                <FormGroup>
                  <InputGroup>
                    <FormControl type="text" placeholder="Select Time" className="fShadow" />
                    <InputGroup.Addon>
                      <i className="fa fa-clock-o"></i>
                    </InputGroup.Addon>
                  </InputGroup>
                </FormGroup>
              </Col>
              <Col md={3} sm={4}>
                <FormGroup>
                  <InputGroup>
                    <FormControl type="text" placeholder="Select Duration" className="fShadow" />
                    <InputGroup.Addon>
                      <i className="fa fa-hourglass"></i>
                    </InputGroup.Addon>
                  </InputGroup>
                </FormGroup>
              </Col>
            </Row>
            <hr />
            <Row>
              <Col md={12}>
                <FormGroup>
                  <ControlLabel>Auto Dial &nbsp;
                      <OverlayTrigger trigger={['hover', 'focus']} placement="top" overlay={joinStart}>
                      <i className="material-icons">info</i>
                    </OverlayTrigger>
                  </ControlLabel>
                  <Row>
                    <Col md={12}>
                      <div className="radio radio-info radio-inline">
                        <input type="radio" id="inlineRadio1" value="option1" name="radioInline" defaultChecked />
                        <label htmlFor="inlineRadio1"> Yes </label>
                      </div>
                      <div className="radio radio-info radio-inline">
                        <input type="radio" id="inlineRadio2" value="option1" name="radioInline" />
                        <label htmlFor="inlineRadio2"> No </label>
                      </div>
                    </Col>
                  </Row>
                </FormGroup>
              </Col>
            </Row>
          </div>
        </div>
      </div>
    );
  }
}

export default SetConferenceTime;