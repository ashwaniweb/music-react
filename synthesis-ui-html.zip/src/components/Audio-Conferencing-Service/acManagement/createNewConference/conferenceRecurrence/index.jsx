import React from 'react';
import Switch from 'react-switch_case'
import { Row, Col, FormGroup, FormControl, ControlLabel, ButtonToolbar, Button, InputGroup } from 'react-bootstrap';
import Dropdown from 'react-dropdown';
import { bootstrapUtils } from 'react-bootstrap/lib/utils';
// Other file call
import './conferenceRecurrence.scss';

let Case = Switch.Case
const month1 = [
  'First', 'Second'
]
const month2 = [
  'Monday', 'Tuesday', 'Wednesday'
]

class ConferenceRecurrence extends React.Component {
  
  constructor(props, contex){
    super(props, contex)
    this.state= {
       tab:'none'
    }
    this.changeTab = this.changeTab.bind(this)
  }

  changeTab(type){
    this.setState({
      tab:type
    })
  }

  render() {
    bootstrapUtils.addStyle(Button, 'conBtn');
    return (
      <div className="ibox">
        <div className="ibox-title">
          <h5>Conference Recurrence</h5>
        </div>
        <div className="ibox-content">
          <div className="form-area">
            <form>
              <Row className="m-b-15">
                <Col md={12}>
                  <ButtonToolbar>
                    <Button onClick={() => { this.changeTab('none') }} bsStyle="conBtn" 
                    className={
                      this.state.tab==='none' ? 'active' : ''
                    }>None</Button>
                    <Button onClick={() => { this.changeTab('daily') }} bsStyle="conBtn"                   
                    className={
                      this.state.tab==='daily' ? 'active' : ''
                    }>Daily</Button>
                    <Button onClick={() => { this.changeTab('weekly') }} bsStyle="conBtn" 
                    className={
                      this.state.tab==='weekly' ? 'active' : ''
                    }>Weekly</Button>
                    <Button onClick={() => { this.changeTab('monthly') }} bsStyle="conBtn"
                    className={
                      this.state.tab==='monthly' ? 'active' : ''
                    }>Monthly</Button>
                    <Button onClick={() => { this.changeTab('yearly') }} bsStyle="conBtn"
                    className={
                      this.state.tab==='yearly' ? 'active' : ''
                    }>Yearly</Button>
                  </ButtonToolbar>
                </Col>
              </Row>
              <Switch value={this.state.tab}>
                <Case value="none">                  
                  <Row>
                    <Col md={12}>
                      <FormGroup>
                        <ControlLabel>Add Conference End Date</ControlLabel>
                        <Row>
                          <Col md={2} className="addconf">
                            <div className="radio radio-info radio-inline">
                              <input type="radio" id="inlineRadio1" value="option1" name="radioInline" />
                              <label htmlFor="inlineRadio1"> Yes </label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            </div>
                          </Col>
                          <Col md={4}>
                            <div className="radio radio-info radio-inline">
                              <input type="radio" id="inlineRadio2" value="option1" name="radioInline" defaultChecked />
                              <label htmlFor="inlineRadio2"> End After &nbsp;&nbsp;</label>
                              <input type="text" className="occur" /> &nbsp;&nbsp;<b>Occurrences</b> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            </div>
                          </Col>
                          <Col md={6} className="addconf">
                            <div className="endby">
                              <div className="radio radio-info radio-inline">
                                <input type="radio" id="inlineRadio2" value="option1" name="radioInline" defaultChecked />
                                <label htmlFor="inlineRadio2"> End by: </label>
                              </div>
                            </div>
                            <div className="endby">
                              <InputGroup>
                                <InputGroup.Addon>
                                  <i className="fa fa-calendar"></i>
                                </InputGroup.Addon>
                                <FormControl type="text" placeholder="Select Date" />
                              </InputGroup>
                            </div>
                          </Col>
                        </Row>
                      </FormGroup>
                    </Col>
                  </Row>
                  <hr />

                  <Row>
                    <Col md={12}>
                      <FormGroup>
                        <ControlLabel>Generate New Pin</ControlLabel>
                        <Row>
                          <Col md={12}>
                            <div className="radio radio-info radio-inline">
                              <input type="radio" id="inlineRadio3" value="option2" name="radioInline" />
                              <label htmlFor="inlineRadio3"> Yes </label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            </div>
                            <div className="radio radio-info radio-inline">
                              <input type="radio" id="inlineRadio4" value="option2" name="radioInline" defaultChecked />
                              <label htmlFor="inlineRadio4"> No </label>
                            </div>
                          </Col>
                        </Row>
                      </FormGroup>
                    </Col>
                  </Row>
                  <hr />

                  <Row>
                    <Col md={12}>
                      <FormGroup>
                        <ControlLabel>Send Invites</ControlLabel>
                        <Row>
                          <Col md={12}>
                            <div className="radio radio-info radio-inline">
                              <input type="radio" id="inlineRadio5" value="option3" name="radioInline" />
                              <label htmlFor="inlineRadio1"> Yes </label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            </div>
                            <div className="radio radio-info radio-inline">
                              <input type="radio" id="inlineRadio5" value="option3" name="radioInline" defaultChecked />
                              <label htmlFor="inlineRadio5"> No </label>
                            </div>
                          </Col>
                        </Row>
                      </FormGroup>
                    </Col>
                  </Row>
                </Case>

                <Case value="daily">
                  <Row>
                    <Col md={12}>
                      <FormGroup>
                        <Row>
                          <Col md={4}>
                            <div className="radio radio-info radio-inline">
                              <input type="radio" id="inlineRadio2" value="option1" name="radioInline" defaultChecked />
                              <label htmlFor="inlineRadio2"> Every &nbsp;&nbsp;</label>
                              <input type="text" className="occur" /> &nbsp;&nbsp;<b>Day</b> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            </div>
                          </Col>
                          <Col md={2} className="addconf">
                            <div className="radio radio-info radio-inline">
                              <input type="radio" id="inlineRadio1" value="option1" name="radioInline" />
                              <label htmlFor="inlineRadio1"> Every Weekday </label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            </div>
                          </Col>
                        </Row>
                      </FormGroup>
                    </Col>
                  </Row>
                  <hr />

                  <Row>
                    <Col md={12}>
                      <FormGroup>
                        <ControlLabel>Add Conference End Date</ControlLabel>
                        <Row>
                          <Col md={2} className="addconf">
                            <div className="radio radio-info radio-inline">
                              <input type="radio" id="inlineRadio1" value="option1" name="radioInline" />
                              <label htmlFor="inlineRadio1"> Yes </label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            </div>
                          </Col>
                          <Col md={4}>
                            <div className="radio radio-info radio-inline">
                              <input type="radio" id="inlineRadio2" value="option1" name="radioInline" defaultChecked />
                              <label htmlFor="inlineRadio2"> End After &nbsp;&nbsp;</label>
                              <input type="text" className="occur" /> &nbsp;&nbsp;<b>Occurrences</b> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            </div>
                          </Col>
                          <Col md={6} className="addconf">
                            <div className="endby">
                              <div className="radio radio-info radio-inline">
                                <input type="radio" id="inlineRadio2" value="option1" name="radioInline" defaultChecked />
                                <label htmlFor="inlineRadio2"> End by: </label>
                              </div>
                            </div>
                            <div className="endby">
                              <InputGroup>
                                <InputGroup.Addon>
                                  <i className="fa fa-calendar"></i>
                                </InputGroup.Addon>
                                <FormControl type="text" placeholder="Select Date" />
                              </InputGroup>
                            </div>
                          </Col>
                        </Row>
                      </FormGroup>
                    </Col>
                  </Row>
                  <hr />

                  <Row>
                    <Col md={12}>
                      <FormGroup>
                        <ControlLabel>Generate New Pin</ControlLabel>
                        <Row>
                          <Col md={12}>
                            <div className="radio radio-info radio-inline">
                              <input type="radio" id="inlineRadio3" value="option2" name="radioInline" />
                              <label htmlFor="inlineRadio3"> Yes </label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            </div>
                            <div className="radio radio-info radio-inline">
                              <input type="radio" id="inlineRadio4" value="option2" name="radioInline" defaultChecked />
                              <label htmlFor="inlineRadio4"> No </label>
                            </div>
                          </Col>
                        </Row>
                      </FormGroup>
                    </Col>
                  </Row>
                  <hr />

                  <Row>
                    <Col md={12}>
                      <FormGroup>
                        <ControlLabel>Send Invites</ControlLabel>
                        <Row>
                          <Col md={12}>
                            <div className="radio radio-info radio-inline">
                              <input type="radio" id="inlineRadio5" value="option3" name="radioInline" />
                              <label htmlFor="inlineRadio1"> Yes </label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            </div>
                            <div className="radio radio-info radio-inline">
                              <input type="radio" id="inlineRadio5" value="option3" name="radioInline" defaultChecked />
                              <label htmlFor="inlineRadio5"> No </label>
                            </div>
                          </Col>
                        </Row>
                      </FormGroup>
                    </Col>
                  </Row>                  
                </Case>

                <Case value="weekly">
                  <Row className="m-b-15">
                    <Col md={12} className="recur">
                      <span>Recur every</span>
                      <span className="weeks"><FormControl type="text" placeholder="1" /></span>
                      <span>weeek(s) on:</span>
                    </Col>
                  </Row>

                  <Row className="m-b-15">
                    <Col md={12}>
                      <div className="checkbox checkbox-week checkbox-inline">
                        <input type="checkbox" id="inlineRadio1" value="option1" name="radioInline" />
                        <label htmlFor="inlineRadio1"> Monday </label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      </div>
                      <div className="checkbox checkbox-week checkbox-inline">
                        <input type="checkbox" id="inlineRadio1" value="option1" name="radioInline" />
                        <label htmlFor="inlineRadio1"> Tuesday </label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      </div>
                      <div className="checkbox checkbox-week checkbox-inline">
                        <input type="checkbox" id="inlineRadio1" value="option1" name="radioInline" />
                        <label htmlFor="inlineRadio1"> Wednesday </label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      </div>
                      <div className="checkbox checkbox-week checkbox-inline">
                        <input type="checkbox" id="inlineRadio1" value="option1" name="radioInline" />
                        <label htmlFor="inlineRadio1"> Thursday </label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      </div>
                      <div className="checkbox checkbox-week checkbox-inline">
                        <input type="checkbox" id="inlineRadio1" value="option1" name="radioInline" />
                        <label htmlFor="inlineRadio1"> Friday </label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      </div>
                      <div className="checkbox checkbox-week checkbox-inline">
                        <input type="checkbox" id="inlineRadio1" value="option1" name="radioInline" />
                        <label htmlFor="inlineRadio1"> Saturday </label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      </div>
                      <div className="checkbox checkbox-week checkbox-inline">
                        <input type="checkbox" id="inlineRadio1" value="option1" name="radioInline" />
                        <label htmlFor="inlineRadio1"> Sunday </label>
                      </div>
                    </Col>
                  </Row>
                  <hr/>

                  <Row>
                    <Col md={12}>
                      <FormGroup>
                        <ControlLabel>Add Conference End Date</ControlLabel>
                        <Row>
                          <Col md={2} className="addconf">
                            <div className="radio radio-info radio-inline">
                              <input type="radio" id="inlineRadio1" value="option1" name="radioInline" />
                              <label htmlFor="inlineRadio1"> Yes </label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            </div>
                          </Col>
                          <Col md={4}>
                            <div className="radio radio-info radio-inline">
                              <input type="radio" id="inlineRadio2" value="option1" name="radioInline" defaultChecked />
                              <label htmlFor="inlineRadio2"> End After &nbsp;&nbsp;</label>
                              <input type="text" className="occur" /> &nbsp;&nbsp;<b>Occurrences</b> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            </div>
                          </Col>
                          <Col md={6} className="addconf">
                            <div className="endby">
                              <div className="radio radio-info radio-inline">
                                <input type="radio" id="inlineRadio2" value="option1" name="radioInline" defaultChecked />
                                <label htmlFor="inlineRadio2"> End by: </label>
                              </div>
                            </div>
                            <div className="endby">
                              <InputGroup>
                                <InputGroup.Addon>
                                  <i className="fa fa-calendar"></i>
                                </InputGroup.Addon>
                                <FormControl type="text" placeholder="Select Date" />
                              </InputGroup>
                            </div>
                          </Col>
                        </Row>
                      </FormGroup>
                    </Col>
                  </Row>
                  <hr />

                  <Row>
                    <Col md={12}>
                      <FormGroup>
                        <ControlLabel>Generate New Pin</ControlLabel>
                        <Row>
                          <Col md={12}>
                            <div className="radio radio-info radio-inline">
                              <input type="radio" id="inlineRadio3" value="option2" name="radioInline" />
                              <label htmlFor="inlineRadio3"> Yes </label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            </div>
                            <div className="radio radio-info radio-inline">
                              <input type="radio" id="inlineRadio4" value="option2" name="radioInline" defaultChecked />
                              <label htmlFor="inlineRadio4"> No </label>
                            </div>
                          </Col>
                        </Row>
                      </FormGroup>
                    </Col>
                  </Row>
                  <hr />

                  <Row>
                    <Col md={12}>
                      <FormGroup>
                        <ControlLabel>Send Invites</ControlLabel>
                        <Row>
                          <Col md={12}>
                            <div className="radio radio-info radio-inline">
                              <input type="radio" id="inlineRadio5" value="option3" name="radioInline" />
                              <label htmlFor="inlineRadio1"> Yes </label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            </div>
                            <div className="radio radio-info radio-inline">
                              <input type="radio" id="inlineRadio5" value="option3" name="radioInline" defaultChecked />
                              <label htmlFor="inlineRadio5"> No </label>
                            </div>
                          </Col>
                        </Row>
                      </FormGroup>
                    </Col>
                  </Row>

                </Case>

                <Case value="monthly">
                  <Row>
                    <Col md={12}>
                      <FormGroup>
                        <Row>
                          <Col md={12}>
                            <div className="radio radio-info radio-inline">
                              <input type="radio" id="inlineRadio2" value="option1" name="radioInline" defaultChecked />
                              <label htmlFor="inlineRadio2"> Day &nbsp;&nbsp;</label>
                              <input type="text" className="occur" />&nbsp;&nbsp;<b>Of every</b>&nbsp;&nbsp;
                              <input type="text" className="occur" />&nbsp;&nbsp;<b>month</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            </div>
                          </Col>
                        </Row>
                      </FormGroup>
                    </Col>
                  </Row>

                  <Row>
                    <Col md={12}>
                      <FormGroup>
                        <Row>
                          <Col md={12} className="linedrop">
                            <div className="radio radio-info radio-inline">
                              <div className="one">
                                <input type="radio" id="inlineRadio2" value="option1" name="radioInline" defaultChecked />
                                <label htmlFor="inlineRadio2"> The &nbsp;&nbsp;</label>
                              </div>
                              <Dropdown options={month1} onChange={this._onSelect} placeholder="Select" />
                              <Dropdown options={month2} onChange={this._onSelect} placeholder="Select" />
                              <div className="two">
                                <b>of every</b>&nbsp;&nbsp;<input type="text" className="occur" />&nbsp;&nbsp;<b>month</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                              </div>
                            </div>
                          </Col>
                        </Row>
                      </FormGroup>
                    </Col>
                  </Row>
                  <hr />

                  <Row>
                    <Col md={12}>
                      <FormGroup>
                        <ControlLabel>Add Conference End Date</ControlLabel>
                        <Row>
                          <Col md={2} className="addconf">
                            <div className="radio radio-info radio-inline">
                              <input type="radio" id="inlineRadio1" value="option1" name="radioInline" />
                              <label htmlFor="inlineRadio1"> Yes </label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            </div>
                          </Col>
                          <Col md={4}>
                            <div className="radio radio-info radio-inline">
                              <input type="radio" id="inlineRadio2" value="option1" name="radioInline" defaultChecked />
                              <label htmlFor="inlineRadio2"> End After &nbsp;&nbsp;</label>
                              <input type="text" className="occur" /> &nbsp;&nbsp;<b>Occurrences</b> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            </div>
                          </Col>
                          <Col md={6} className="addconf">
                            <div className="endby">
                              <div className="radio radio-info radio-inline">
                                <input type="radio" id="inlineRadio2" value="option1" name="radioInline" defaultChecked />
                                <label htmlFor="inlineRadio2"> End by: </label>
                              </div>
                            </div>
                            <div className="endby">
                              <InputGroup>
                                <InputGroup.Addon>
                                  <i className="fa fa-calendar"></i>
                                </InputGroup.Addon>
                                <FormControl type="text" placeholder="Select Date" />
                              </InputGroup>
                            </div>
                          </Col>
                        </Row>
                      </FormGroup>
                    </Col>
                  </Row>
                  <hr />

                  <Row>
                    <Col md={12}>
                      <FormGroup>
                        <ControlLabel>Generate New Pin</ControlLabel>
                        <Row>
                          <Col md={12}>
                            <div className="radio radio-info radio-inline">
                              <input type="radio" id="inlineRadio3" value="option2" name="radioInline" />
                              <label htmlFor="inlineRadio3"> Yes </label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            </div>
                            <div className="radio radio-info radio-inline">
                              <input type="radio" id="inlineRadio4" value="option2" name="radioInline" defaultChecked />
                              <label htmlFor="inlineRadio4"> No </label>
                            </div>
                          </Col>
                        </Row>
                      </FormGroup>
                    </Col>
                  </Row>
                  <hr />

                  <Row>
                    <Col md={12}>
                      <FormGroup>
                        <ControlLabel>Send Invites</ControlLabel>
                        <Row>
                          <Col md={12}>
                            <div className="radio radio-info radio-inline">
                              <input type="radio" id="inlineRadio5" value="option3" name="radioInline" />
                              <label htmlFor="inlineRadio1"> Yes </label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            </div>
                            <div className="radio radio-info radio-inline">
                              <input type="radio" id="inlineRadio5" value="option3" name="radioInline" defaultChecked />
                              <label htmlFor="inlineRadio5"> No </label>
                            </div>
                          </Col>
                        </Row>
                      </FormGroup>
                    </Col>
                  </Row>
                </Case>

                <Case value="yearly">
                  <Row className="m-b-15">
                    <Col md={12} className="recur">
                      <span>Recur every</span>
                      <span className="weeks"><FormControl type="text" placeholder="1" /></span>
                      <span>year</span>
                    </Col>
                  </Row>

                  <Row>
                    <Col md={12}>
                      <FormGroup>
                        <Row>
                          <Col md={12} className="linedrop">
                            <div className="radio radio-info radio-inline">
                              <div className="one">
                                <input type="radio" id="inlineRadio2" value="option1" name="radioInline" defaultChecked />
                                <label htmlFor="inlineRadio2"> On &nbsp;&nbsp;</label>
                              </div>
                              <Dropdown options={month1} onChange={this._onSelect} placeholder="Select" />
                              <div className="two">
                                <input type="text" className="occur" />
                              </div>
                            </div>
                          </Col>
                        </Row>
                      </FormGroup>
                    </Col>
                  </Row>

                  <Row>
                    <Col md={12}>
                      <FormGroup>
                        <Row>
                          <Col md={12} className="linedrop">
                            <div className="radio radio-info radio-inline">
                              <div className="one">
                                <input type="radio" id="inlineRadio2" value="option1" name="radioInline" defaultChecked />
                                <label htmlFor="inlineRadio2"> The &nbsp;&nbsp;</label>
                              </div>
                              <Dropdown options={month1} onChange={this._onSelect} placeholder="Select" />
                              <Dropdown options={month2} onChange={this._onSelect} placeholder="Select" />
                              <div className="two yeSpace">
                                <b>of</b>&nbsp;&nbsp;
                              </div>
                              <Dropdown options={month1} onChange={this._onSelect} placeholder="Select" />                              
                            </div>
                          </Col>
                        </Row>
                      </FormGroup>
                    </Col>
                  </Row>
                  <hr/>

                  <Row>
                    <Col md={12}>
                      <FormGroup>
                        <ControlLabel>Add Conference End Date</ControlLabel>
                        <Row>
                          <Col md={2} className="addconf">
                            <div className="radio radio-info radio-inline">
                              <input type="radio" id="inlineRadio1" value="option1" name="radioInline" />
                              <label htmlFor="inlineRadio1"> Yes </label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            </div>
                          </Col>
                          <Col md={4}>
                            <div className="radio radio-info radio-inline">
                              <input type="radio" id="inlineRadio2" value="option1" name="radioInline" defaultChecked />
                              <label htmlFor="inlineRadio2"> End After &nbsp;&nbsp;</label>
                              <input type="text" className="occur" /> &nbsp;&nbsp;<b>Occurrences</b> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            </div>
                          </Col>
                          <Col md={6} className="addconf">
                            <div className="endby">
                              <div className="radio radio-info radio-inline">
                                <input type="radio" id="inlineRadio2" value="option1" name="radioInline" defaultChecked />
                                <label htmlFor="inlineRadio2"> End by: </label>
                              </div>
                            </div>
                            <div className="endby">
                              <InputGroup>
                                <InputGroup.Addon>
                                  <i className="fa fa-calendar"></i>
                                </InputGroup.Addon>
                                <FormControl type="text" placeholder="Select Date" />
                              </InputGroup>
                            </div>
                          </Col>
                        </Row>
                      </FormGroup>
                    </Col>
                  </Row>
                  <hr />

                  <Row>
                    <Col md={12}>
                      <FormGroup>
                        <ControlLabel>Generate New Pin</ControlLabel>
                        <Row>
                          <Col md={12}>
                            <div className="radio radio-info radio-inline">
                              <input type="radio" id="inlineRadio3" value="option2" name="radioInline" />
                              <label htmlFor="inlineRadio3"> Yes </label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            </div>
                            <div className="radio radio-info radio-inline">
                              <input type="radio" id="inlineRadio4" value="option2" name="radioInline" defaultChecked />
                              <label htmlFor="inlineRadio4"> No </label>
                            </div>
                          </Col>
                        </Row>
                      </FormGroup>
                    </Col>
                  </Row>
                  <hr />

                  <Row>
                    <Col md={12}>
                      <FormGroup>
                        <ControlLabel>Send Invites</ControlLabel>
                        <Row>
                          <Col md={12}>
                            <div className="radio radio-info radio-inline">
                              <input type="radio" id="inlineRadio5" value="option3" name="radioInline" />
                              <label htmlFor="inlineRadio1"> Yes </label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            </div>
                            <div className="radio radio-info radio-inline">
                              <input type="radio" id="inlineRadio5" value="option3" name="radioInline" defaultChecked />
                              <label htmlFor="inlineRadio5"> No </label>
                            </div>
                          </Col>
                        </Row>
                      </FormGroup>
                    </Col>
                  </Row>
                </Case>

              </Switch>
            </form>
          </div>
        </div>
      </div>
    );
  }
}

export default ConferenceRecurrence;