import React from 'react';
import { Row, Col, Table, FormControl, Pagination, OverlayTrigger, Tooltip, FormGroup,InputGroup } from 'react-bootstrap';

import MyModal from '../../../modalBox';
import '../../../modalBox/modalBox.scss';
// Other file call
import './recordingList.scss';
var createReactClass = require('create-react-class');

const options = [
  'Reserved', 'Un-Reserved'
]

const LinkWithTooltip = createReactClass({
  render() {
    let tooltip = <Tooltip id={this.props.id}>{this.props.tooltip}</Tooltip>;
    return (
      <OverlayTrigger
        overlay={tooltip}
        placement="top"
        delayShow={300}
        delayHide={150}
      >
        <a href={this.props.href}>{this.props.children}</a>
      </OverlayTrigger>
    );
  }
});
const list = [
  {
    id: 1,
    description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
    audio: 'a.mp3',
    duration: '10:30'
  },
  {
    id: 2,
    description: 'Nunc lacinia pulvinar nisl et tincidunt Nulla diam lacus.',
    audio: 'b.mp3',
    duration: '10:30'
  },
  {
    id: 3,
    description: 'Suspendisse eu aliquam dui, eu vestibulum nisi ut id.',
    audio: 'c.mp3',
    duration: '10:30'
  },
  {
    id: 4,
    description: 'Proin eu nibh risus. Etiam porta ipsum nibh.',
    audio: 'a.mp3',
    duration: '10:30'
  },
  {
    id: 5,
    description: 'Donec in ante non diam tristique bibendum mauris.',
    audio: 'b.mp3',
    duration: '10:30'
  },
  {
    id: 6,
    description: 'Nunc viverra porta purus, porttitor auctor odio.',
    audio: 'c.mp3',
    duration: '10:30'
  },
];

class ListInCallAudioMessageList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      list: list,
      audioPlay: false,
      audioPause: false,
      audioDownload: false,
      audioDelete: false,
      cancel: false,
      deleteItem: false,
      modalShow: false,
      temp_id: false
    };
    this.showModal = this.showModal.bind(this);
    this.cancel = this.cancel.bind(this);
    this.handleClick = this.handleClick.bind(this);
    this.audioPlay = this.audioPlay.bind(this);
    this.audioPause = this.audioPause.bind(this);
    this.audioDownload = this.audioDownload.bind(this);
    this.audioDelete = this.audioDelete.bind(this);
  }

  handleClick(item) {
    let updatedList = this.state.list.map(obj => {
      if (obj.id === item.id) {
        return Object.assign({}, obj, {
          hidden: !item.hidden
        });
      }
      return obj;
    });
    this.setState({
      list: updatedList,
    });
  }

  audioPlay(e) {
    this.setState(
      function (prevState) {
        var audioElement = document.getElementById('beep-' + 1);
        audioElement.setAttribute("preload", "auto");
        audioElement.autobuffer = true;
        audioElement.load();
        audioElement.play();
        return {
          audioPlay: true
        };
      });
  }

  audioPause(e) {
    if (this.state.audioPlay) {
      this.setState({
        audioPlay: false,
      }, function () {
        var audioElement = document.getElementById('beep-' + 1);
        audioElement.pause();
      });
    }
  }

  audioDownload(e) {
    if (this.state.audioDownload) {
      this.setState({
        audioDownload: false,
      }, function () {
        var audioElement = document.getElementById('beep');
        audioElement.download();
      });
    }
  }

  audioDelete(e) {
    if (this.state.audioDelete) {
      this.setState({
        audioDelete: false,
      }, function () {
        var audioElement = document.getElementById('beep');
        audioElement.pause();
      });
    }
  }

  playLine(e) {

  }

  cancel() {
    this.setState({
      cancel: !this.state.cancel,
      modalShow: false
    })
  }

  showModal(item) {   
    this.setState({
      cancel: true,
      modalShow: true,        
      temp_id: item
    });
  }

  deleteItem(item){
    const newState = this.state.list;
  	if (newState.indexOf(item) > -1) {
    	newState.splice(newState.indexOf(item), 1);
      this.setState({
        list: newState,
        cancel: false,
        modalShow: false        
      })
    }
  }


  render() {
    return (
      <div className="ibox">
        <div className="ibox-title">
          <h5>List In Call Audio Message</h5>
        </div>
        <div className="ibox-content">
          <Row className="gTable-new">
            <Table responsive className="table-bordered">
              <thead>
                <tr>
                  <th className="sorting">File Description</th>
                  <th width="35%">Play</th>
                  <th width="12%" className="text-center">Actions</th>
                </tr>
                <tr>
                  <th>
                    <FormGroup>
                      <InputGroup>
                        <FormControl type="text" placeholder="Search" className="fShadow" />
                        <InputGroup.Addon>
                          <i className="fa fa-search"></i>
                        </InputGroup.Addon>
                      </InputGroup>
                    </FormGroup>
                  </th>
                  <th>&nbsp;</th>
                  <th>&nbsp;</th>
                </tr>
              </thead>
              <tbody>
                {this.state.list.map(item =>
                  <tr key={item.itemId}>
                    <td className="text-left">{item.description}</td>
                    <td className="text-center">
                      <div className="audioPlayer recList">
                        {!this.state.audioPlay ?
                          <i className="material-icons recList" onClick={this.audioPlay}>play_arrow</i>
                          :
                          <i className="material-icons recList" onClick={this.audioPause}>pause</i>
                        }
                        <div className="playLine">
                          <span className="looper"></span>
                        </div>
                        <span className="duration">{item.duration}</span>
                      </div>
                      <audio id={'beep-' + item.id} className="player" preload="false">
                        <source src={'/media/' + item.audio} />
                      </audio>
                    </td>
                    <td className="action-wrap text-center">
                      <LinkWithTooltip tooltip="View" href="javascript:void('0')" id={'tooltip-' - { item }}>
                        <i onClick={this.audioDownload} className="material-icons recList">border_color</i>
                      </LinkWithTooltip>
                      <LinkWithTooltip tooltip="Delete" href="javascript:void('0')" id={'tooltip-' - { item }}>
                        <i onClick={() => this.showModal(item)} className="material-icons recList">delete</i>
                      </LinkWithTooltip>
                    </td>
                  </tr>
                )}
              </tbody>
            </Table>
          </Row>
          <Row>
            <Col md={6} className="allentries">
            </Col>
            <Col md={6}>
              <div className="table-pag">
                <Pagination
                  first='fast_rewind'
                  next='play_arrow'
                  prev='play_arrow'
                  last='fast_forward'
                  ellipsis
                  boundaryLinks
                  items={5}
                  maxButtons={5}
                />
              </div>
            </Col>
          </Row>
        </div>
        <div className={!this.state.modalShow ? 'myModal' : 'myModal show'}>
          <div className='myModal-content modal-sm'>
            <div className="myModal-header"></div>
            <div className="myModal-body">
              <img src="/images/delete.png" alt="Delete" />
              <p>Are you sure you want to delete this conference?</p>
            </div>
            <div className="myModal-footer">
              <button className="btn btn-submit" onClick={() => this.deleteItem(this.state.temp_id)}>Yes</button>
              <button className="btn btn-cancel" onClick={this.cancel}>Cancel</button>
            </div>
          </div>
          <div className={!this.state.modalShow ? 'myModal-overlay' : 'myModal-overlay show'} />
        </div>
      </div>
    );
  }
}

export default ListInCallAudioMessageList;