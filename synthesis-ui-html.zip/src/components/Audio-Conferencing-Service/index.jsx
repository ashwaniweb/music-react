import React from 'react';

// Other file call
import AcTopMenu from '../Audio-Conferencing-Service/topMenu/TopMenu';
import DashBoard from '../Audio-Conferencing-Service/dashBoard/DashBoard';

class AudioConferencingDashboard extends React.Component {
  render() {
    return (
      <div className="main">
        <AcTopMenu />
        <DashBoard />
      </div>
    );
  }
}

export default AudioConferencingDashboard;
