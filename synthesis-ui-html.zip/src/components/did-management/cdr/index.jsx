import React from 'react';
import { Row, Col, Table, Pagination, OverlayTrigger, Tooltip, SplitButton, MenuItem } from 'react-bootstrap';
// Other file call
var createReactClass = require('create-react-class');

const LinkWithTooltip = createReactClass({
  render() {
    let tooltip = <Tooltip id={this.props.id}>{this.props.tooltip}</Tooltip>;
    return (
      <OverlayTrigger
        overlay={tooltip}
        placement="top"
        delayShow={300}
        delayHide={150}
      >
        <a href={this.props.href}>{this.props.children}</a>
      </OverlayTrigger>
    );
  }
});
const list = [
  {
    id: 1,
    Date: '14/12/2017',
    sTime: '03:30 PM',
    eTime: '04:30 PM',
    Duration: '01h 25m 06s',
    Dialledno: '202-555-0101',
    bridgeCharge: '$20.00',
    inboundCharge: '$20.00',
    miscCharge: '$20.00',
    totalCost: '$60.00',
    services: 'AC, IVR'
  },
  {
    id: 2,
    Date: '14/12/2017',
    sTime: '03:30 PM',
    eTime: '04:30 PM',
    Duration: '01h 25m 06s',
    Dialledno: '202-555-0101',
    bridgeCharge: '$20.00',
    inboundCharge: '$20.00',
    miscCharge: '$20.00',
    totalCost: '$60.00',
    services: 'AC'
  },
  {
    id: 3,
    Date: '14/12/2017',
    sTime: '03:30 PM',
    eTime: '04:30 PM',
    Duration: '01h 25m 06s',
    Dialledno: '202-555-0101',
    bridgeCharge: '$20.00',
    inboundCharge: '$20.00',
    miscCharge: '$20.00',
    totalCost: '$60.00',
    services: 'AC, IVR'
  },
  {
    id: 4,
    Date: '14/12/2017',
    sTime: '03:30 PM',
    eTime: '04:30 PM',
    Duration: '01h 25m 06s',
    Dialledno: '202-555-0101',
    bridgeCharge: '$20.00',
    inboundCharge: '$20.00',
    miscCharge: '$20.00',
    totalCost: '$60.00',
    services: 'IVR'
  },
  {
    id: 5,
    Date: '14/12/2017',
    sTime: '03:30 PM',
    eTime: '04:30 PM',
    Duration: '01h 25m 06s',
    Dialledno: '202-555-0101',
    bridgeCharge: '$20.00',
    inboundCharge: '$20.00',
    miscCharge: '$20.00',
    totalCost: '$60.00',
    services: 'AC, IVR'
  },
  {
    id: 6,
    Date: '14/12/2017',
    sTime: '03:30 PM',
    eTime: '04:30 PM',
    Duration: '01h 25m 06s',
    Dialledno: '202-555-0101',
    bridgeCharge: '$20.00',
    inboundCharge: '$20.00',
    miscCharge: '$20.00',
    totalCost: '$60.00',
    services: 'AC, IVR'
  },
];

// Other file call
class CallDetailsRecord extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      list: list
    };
    this.handleClick = this.handleClick.bind(this);
  }

  handleClick(item) {
    let updatedList = this.state.list.map(obj => {
      if (obj.id === item.id) {
        return Object.assign({}, obj, {
          hidden: !item.hidden
        });
      }
      return obj;
    });
    this.setState({
      list: updatedList,
    });
  }

  render() {
    return (
      <div className="ibox">
        <div className="ibox-title pt-5 pb-5">
          <h5>CDR List</h5>
          <div className="topBarbtn">
            <SplitButton title="Dropdown" pullRight id="split-button-pull-right">
              <MenuItem eventKey="3">Download CSV</MenuItem>
              <MenuItem divider />
              <MenuItem eventKey="4">Download Excel</MenuItem>
            </SplitButton>
          </div>

          <Row className="cdrGroupinfo">
            <Row>
              <Col md={3}>
                <Row>
                  <div className="form-group">
                    <div className="col-sm-12">
                      DID Number: &nbsp;&nbsp;<span>0123-654-987</span>
                    </div>
                  </div>
                </Row>
              </Col>
              <Col md={3}>
                <Row>
                  <div className="form-group">
                    <div className="col-sm-12">
                      Country: &nbsp;&nbsp;<span>India</span>
                    </div>
                  </div>
                </Row>
              </Col>
              <Col md={3}>
                <Row>
                  <div className="form-group">
                    <div className="col-sm-12">
                      City: &nbsp;&nbsp;<span>Delhi</span>
                    </div>
                  </div>
                </Row>
              </Col>
              <Col md={3}>
                <Row>
                  <div className="form-group">
                    <div className="col-sm-12">
                      Total Duration: &nbsp;&nbsp;<span>11h 02m 15s</span>
                    </div>
                  </div>
                </Row>
              </Col>
            </Row>
            <Row>
              <Col md={3}>
                <Row>
                  <div className="form-group">
                    <div className="col-sm-12">
                      Bridge Rate: &nbsp;&nbsp;<span>$2.00 per minute</span>
                    </div>
                  </div>
                </Row>
              </Col>
              <Col md={3}>
                <Row>
                  <div className="form-group">
                    <div className="col-sm-12">
                      Inbound Rate: &nbsp;&nbsp;<span>$2.00 per minute</span>
                    </div>
                  </div>
                </Row>
              </Col>
              <Col md={3}>
                <Row>
                  <div className="form-group">
                    <div className="col-sm-12">
                      Misc. Rate: &nbsp;&nbsp;<span>$2.00 per minute</span>
                    </div>
                  </div>
                </Row>
              </Col>
            </Row>
          </Row>
        </div>
        <div className="ibox-content">
          <Row className="gTable-new">
            <Table responsive className="table-bordered">
              <thead>
                <tr>
                  <th width="5%" className="text-center">
                    <input type="checkbox" htmlFor="all" id="all" />
                  </th>
                  <th width="8%" className="sorting">Date</th>
                  <th className="sorting">Start Time</th>
                  <th className="sorting">End Time</th>
                  <th >Duration</th>
                  <th >Dialled No.</th>
                  <th className="text-center">Bridge Charge</th>
                  <th className="text-center">Inbound Charge</th>
                  <th className="text-center">Misc Charge</th>
                  <th className="text-center">Total Cost</th>
                  <th className="text-center">Services</th>
                </tr>
              </thead>
              <tbody>
                {this.state.list.map(item =>
                  <tr key={item.itemId}>
                    <td className="text-center"><input type="checkbox" for={item.itemId} id={item.itemId} /></td>
                    <td>{item.Date}</td>
                    <td className="text-center">{item.sTime}</td>
                    <td className="text-center">{item.eTime}</td>
                    <td className="text-center">{item.Duration}</td>
                    <td className="text-center">{item.Dialledno}</td>
                    <td className="text-center">{item.bridgeCharge}</td>
                    <td className="text-center">{item.inboundCharge}</td>
                    <td className="text-center">{item.miscCharge}</td>
                    <td className="text-center">{item.totalCost}</td>
                    <td className="text-center">{item.services}</td>
                  </tr>
                )}
              </tbody>
            </Table>
          </Row>
          <Row>
            {/*<Col md={6} className="allentries">
               Showing 1 to 1 of 1 entries 
            </Col>*/}
            <Col md={12}>
              <div className="table-pag">
                <Pagination
                  first='fast_rewind'
                  next='play_arrow'
                  prev='play_arrow'
                  last='fast_forward'
                  ellipsis
                  boundaryLinks
                  items={5}
                  maxButtons={5}
                />
              </div>
            </Col>
          </Row>
        </div>
      </div>
    );
  }
}

export default CallDetailsRecord;