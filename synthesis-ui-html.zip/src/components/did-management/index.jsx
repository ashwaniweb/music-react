import React from 'react';

// Other file call
import AcTopMenu from '../did-management/topMenu/TopMenu';
import DashBoard from '../did-management/dashBoard/DashBoard';

class DidManagement extends React.Component {
  render() {
    return (
      <div className="main">
        <AcTopMenu />
        <DashBoard />
      </div>
    );
  }
}

export default DidManagement;
