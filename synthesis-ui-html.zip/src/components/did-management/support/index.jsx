import React from 'react';

// Other file call
class Support extends React.Component {
  render() {
    return (
      <div className="main">
        Support
      </div>
    );
  }
}

export default Support;