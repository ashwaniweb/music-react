import React from 'react';

// Other file call
class Request extends React.Component {
  render() {
    return (
      <div className="main">
        Request
      </div>
    );
  }
}

export default Request;