import React from 'react';
import { Row, Col, Table, Pagination, FormGroup, FormControl, InputGroup, OverlayTrigger, Tooltip, SplitButton, MenuItem, Modal, ControlLabel, Form, Button, ButtonToolbar, DropdownButton } from 'react-bootstrap';
// Other file call
var createReactClass = require('create-react-class');

const LinkWithTooltip = createReactClass({
  render() {
    let tooltip = <Tooltip id={this.props.id}>{this.props.tooltip}</Tooltip>;
    return (
      <OverlayTrigger
        overlay={tooltip}
        placement="top"
        delayShow={300}
        delayHide={150}
      >
        <a href={this.props.href}>{this.props.children}</a>
      </OverlayTrigger>
    );
  }
});
const dict = ['Take Action', 'Allocate', 'Unallocated']
const list = [
  {
    id: 1,
    did: '202-555-0101',
    country: 'India',
    city: 'New Delhi',
    type: 'Dedicated',
    date: '25/01/2018',
    cdr: 'View',
    services: 'AC',
    status: 'Enabled',
  },
  {
    id: 2,
    did: '202-555-0175',
    country: 'India',
    city: 'Noida',
    type: 'Global',
    date: '23/01/2018',
    cdr: 'View',
    services: 'IVR',
    status: 'Enabled',
  },
  {
    id: 3,
    did: '202-555-0101',
    country: 'India',
    city: 'Gurugram',
    type: 'Dedicated',
    date: '25/01/2018',
    cdr: 'View',
    services: 'AC',
    status: 'Enabled',
  },
  {
    id: 4,
    did: '202-555-0175',
    country: 'India',
    city: 'Meerut',
    type: 'Global',
    date: '23/01/2018',
    cdr: 'View',
    services: 'IVR',
    status: 'Disabled',
  },
  {
    id: 5,
    did: '202-555-0101',
    country: 'India',
    city: 'New Delhi',
    type: 'Dedicated',
    date: '25/01/2018',
    cdr: 'View',
    services: 'AC',
    status: 'Enabled',
  },
  {
    id: 6,
    did: '202-555-0175',
    country: 'India',
    city: 'Noida',
    type: 'Global',
    date: '23/01/2018',
    cdr: 'View',
    services: 'IVR',
    status: 'Disabled',
  },
  {
    id: 7,
    did: '202-555-0101',
    country: 'India',
    city: 'Gurugram',
    type: 'Dedicated',
    date: '25/01/2018',
    cdr: 'View',
    services: 'AC',
    status: 'Enabled',
  },
  {
    id: 8,
    did: '202-555-0175',
    country: 'India',
    city: 'Meerut',
    type: 'Global',
    date: '23/01/2018',
    cdr: 'View',
    services: 'IVR',
    status: 'Enabled',
  },
];
// Other file call
class Purchased extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      list: list,
      dict: dict,
      show: false,
      title: 'Take Action',
      alertBox: false
    };
    this.handleClick = this.handleClick.bind(this);
    this.handleShow = this.handleShow.bind(this);
    this.handleHide = this.handleHide.bind(this);
    this.onTargetSelect = this.onTargetSelect.bind(this);
    this.alertBox = this.alertBox.bind(this);
  }

  handleHide() {
    this.setState({ show: false });
  }

  handleShow() {
    this.setState({ show: true });
  }

  handleClick(item) {
    let updatedList = this.state.list.map(obj => {
      if (obj.id === item.id) {
        return Object.assign({}, obj, {
          hidden: !item.hidden
        });
      }
      return obj;
    });
    this.setState({
      list: updatedList,
    });
  }

  onTargetSelect(target) {
    this.setState({
      title: target,
      alertBox: !this.state.alertBox
    });
    // this.props.passTargetToParent(target);
  }

  alertBox() {
    this.setState({
      alertBox: !this.state.alertBox
    });
  }

  render() {
    return (
      <div className="ibox">
        <div className="ibox-title pt-5 pb-5">
          <h5>Purchased DID</h5>
          <div className="topBarbtn col-sm-4 p-0">
            <FormGroup className="col-sm-8 form-group p-0 m-0">
              <InputGroup>
                <FormControl type="text" placeholder="country" className="fShadow" />
                <InputGroup.Addon>
                  <i className="fa fa-search"></i>
                </InputGroup.Addon>
              </InputGroup>
            </FormGroup>
            <div className="pull-right">
              <SplitButton title="Dropdown" pullRight id="split-button-pull-right">
                <MenuItem eventKey="3">Download CSV</MenuItem>
                <MenuItem divider />
                <MenuItem eventKey="4">Download Excel</MenuItem>
              </SplitButton>
            </div>
          </div>
        </div>
        <div className="ibox-content">
          <Row className="gTable-new">
            <Table responsive className="table-bordered">
              <thead>
                <tr>
                  <th width="5%" className="text-center">
                    <input type="checkbox" htmlFor="all" id="all" />
                  </th>
                  <th>Dialled No.</th>
                  <th>Country</th>
                  <th>City</th>
                  <th>DID Type</th>
                  <th>Date Purchased</th>
                  <th>CDR</th>
                  <th>Services</th>
                  <th className="text-center">Status</th>
                  <th className="text-center">Action</th>
                </tr>
              </thead>
              <tbody>
                {this.state.list.map(item =>
                  <tr key={item.itemId}>
                    <td className="text-center"><input type="checkbox" htmlFor={item.itemId} id={item.itemId} /></td>
                    <td>{item.did}</td>
                    <td>{item.country}</td>
                    <td>{item.city}</td>
                    <td>{item.type}</td>
                    <td>{item.date}</td>
                    <td>{item.cdr}</td>
                    <td>{item.services}</td>
                    <td className={item.status === 'Disabled' ? 'text-center text-danger' : 'text-center text-info'}>{item.status}</td>
                    <td className="text-center">
                      <i className="material-icons pointer" onClick={this.handleShow}>remove_red_eye</i>
                    </td>
                  </tr>
                )}
              </tbody>
            </Table>
          </Row>
          <Row>
            {/*<Col md={6} className="allentries">
               Showing 1 to 1 of 1 entries 
            </Col>*/}
            <Col md={12}>
              <div className="table-pag">
                <Pagination
                  first='fast_rewind'
                  next='play_arrow'
                  prev='play_arrow'
                  last='fast_forward'
                  ellipsis
                  boundaryLinks
                  items={5}
                  maxButtons={5}
                />
              </div>
            </Col>
          </Row>
        </div>
        {this.state.show &&
          <Modal
            {...this.props}
            show={this.state.show}
            onHide={this.handleHide}
            dialogClassName="modal-md audioView bg-white"
          >
            <Modal.Body>
              <Modal.Header closeButton>
              </Modal.Header>
              <div className="ibox">
                <div className="ibox-title pt-5 pl-5 pr-5 pb-0">
                  <h5>Manage DID</h5>
                  <Row className="cdrGroupinfo row p-0 ml-0 mr-0 no-shadow">
                    <Row>
                      <Col md={6}>
                        <Row>
                          <div className="form-group">
                            <div className="col-sm-12">
                              DID Number: <span>0123-654-987</span>
                            </div>
                          </div>
                        </Row>
                      </Col>
                      <Col md={6}>
                        <Row>
                          <div className="form-group">
                            <div className="col-sm-12">
                              Type: <span>Global</span>
                            </div>
                          </div>
                        </Row>
                      </Col>
                    </Row>
                    <Row>
                      <Col md={6}>
                        <Row>
                          <div className="form-group">
                            <div className="col-sm-12">
                              Country: <span>India</span>
                            </div>
                          </div>
                        </Row>
                      </Col>
                      <Col md={6}>
                        <Row>
                          <div className="form-group">
                            <div className="col-sm-12">
                              City: <span>Delhi</span>
                            </div>
                          </div>
                        </Row>
                      </Col>
                    </Row>
                    <Row>
                      <Col md={6}>
                        <Row>
                          <div className="form-group">
                            <div className="col-sm-12">
                              Date Purchased: <span>27/01/2017</span>
                            </div>
                          </div>
                        </Row>
                      </Col>
                      <Col md={6}>
                        <Row>
                          <div className="form-group">
                            <div className="col-sm-12">
                              Status: <span>Enabled</span>
                            </div>
                          </div>
                        </Row>
                      </Col>
                    </Row>
                  </Row>
                </div>
                <div className="ibox-content ml-5 mr-5 pl-0 pr-0">
                  <Form className="row">
                    <FormGroup controlId="formHorizontalEmail" className='col-sm-12 p-0'>
                      <Col componentClass={ControlLabel} sm={8} className='text-left'>
                        Services Used in
                      </Col>
                      <Col sm={4}>
                        <strong>Status</strong>
                      </Col>
                    </FormGroup>
                    <FormGroup controlId="formHorizontalEmail" className='col-sm-12 p-0'>
                      <Col componentClass={ControlLabel} sm={8} className='text-left'>
                        Audio Conferencing
                    </Col>
                      <Col sm={4}>
                        <SplitButton title={this.state.title} id="dropdown-target">
                          {this.state.dict.map(item =>
                            <MenuItem eventKey={dict[item]} onSelect={() => this.onTargetSelect(item)}>{item}</MenuItem>
                          )}
                        </SplitButton>
                      </Col>
                    </FormGroup>
                    <FormGroup controlId="formHorizontalEmail" className='col-sm-12 p-0'>
                      <Col componentClass={ControlLabel} sm={8} className='text-left'>
                        Video Conferencing
                    </Col>
                      <Col sm={4}>
                        <SplitButton title={this.state.title} id="dropdown-target">
                          {this.state.dict.map(item =>
                            <MenuItem eventKey={dict[item]} onSelect={() => this.onTargetSelect(item)}>{item}</MenuItem>
                          )}
                        </SplitButton>
                      </Col>
                    </FormGroup>
                    <FormGroup controlId="formHorizontalEmail" className='col-sm-12 p-0'>
                      <Col componentClass={ControlLabel} sm={8} className='text-left'>
                        Interactive voice response (IVR)
                    </Col>
                      <Col sm={4}>
                        <SplitButton title={this.state.title} id="dropdown-target">
                          {this.state.dict.map(item =>
                            <MenuItem eventKey={dict[item]} onSelect={() => this.onTargetSelect(item)}>{item}</MenuItem>
                          )}
                        </SplitButton>
                      </Col>
                    </FormGroup>
                    <FormGroup controlId="formHorizontalEmail" className='col-sm-12 p-0'>
                      <Col componentClass={ControlLabel} sm={8} className='text-left'>
                        Voice Over Internet Protocol(VoIP)
                    </Col>
                      <Col sm={4}>
                        <SplitButton title={this.state.title} id="dropdown-target">
                          {this.state.dict.map(item =>
                            <MenuItem eventKey={dict[item]} onSelect={() => this.onTargetSelect(item)}>{item}</MenuItem>
                          )}
                        </SplitButton>
                      </Col>
                    </FormGroup>
                    <FormGroup>
                      <Col sm={12}>
                        <Button className="btn-submit" onClick={this.handleHide}>Submit</Button>
                        <Button className="btn-cancel" onClick={this.handleHide}>Cancel</Button>
                      </Col>
                    </FormGroup>
                  </Form>
                </div>
              </div>
              {this.state.alertBox &&
                <div className='alertBox'>
                  <Col sm={12}>
                    <p>Are you sure you want to <strong>unallocate</strong> this DID from <strong>Audio Conferencing?</strong></p>
                  </Col>
                  <Col sm={12} className='text-center'>
                    <Button className="btn-cancel mr-2 text-info" onClick={this.alertBox}>Yes</Button>
                    <Button className="btn-cancel text-muted" onClick={this.alertBox}>Cancel</Button>
                  </Col>
                </div>
              }
            </Modal.Body>
          </Modal>
        }
      </div>
    );
  }
}

export default Purchased;