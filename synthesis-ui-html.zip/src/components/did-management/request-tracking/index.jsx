import React from 'react';
import { Row, Col, Table, Pagination, OverlayTrigger, Tooltip, SplitButton, MenuItem } from 'react-bootstrap';
// Other file call
var createReactClass = require('create-react-class');

const LinkWithTooltip = createReactClass({
  render() {
    let tooltip = <Tooltip id={this.props.id}>{this.props.tooltip}</Tooltip>;
    return (
      <OverlayTrigger
        overlay={tooltip}
        placement="top"
        delayShow={300}
        delayHide={150}
      >
        <a href={this.props.href}>{this.props.children}</a>
      </OverlayTrigger>
    );
  }
});
const list = [
  {
    id: 1,
    request: '090889',
    didReq: '10',
    country: 'India',
    city: 'New Delhi',
    price: '£15',
    type: 'Dedicated',
    reqDate: '11/02/2018',
    status: 'Request Sent',
  },
  {
    id: 2,
    request: '020614',
    didReq: '15',
    country: 'India',
    city: 'Noida',
    price: '£25',
    type: 'Global',
    reqDate: '19/01/2018',
    status: 'Request Declined',
  },
  {
    id: 3,
    request: '090889',
    didReq: '10',
    country: 'India',
    city: 'New Delhi',
    price: '£15',
    type: 'Dedicated',
    reqDate: '11/02/2018',
    status: 'Request Confirmed',
  },
  {
    id: 4,
    request: '020614',
    didReq: '15',
    country: 'India',
    city: 'Noida',
    price: '£25',
    type: 'Global',
    reqDate: '19/01/2018',
    status: 'Request in Process',
  },
  {
    id: 5,
    request: '090889',
    didReq: '10',
    country: 'India',
    city: 'New Delhi',
    price: '£15',
    type: 'Dedicated',
    reqDate: '11/02/2018',
    status: 'Request Confirmed',
  },
  {
    id: 6,
    request: '020614',
    didReq: '15',
    country: 'India',
    city: 'Noida',
    price: '£25',
    type: 'Global',
    reqDate: '19/01/2018',
    status: 'Request Fulfilled',
  },
  {
    id: 7,
    request: '090889',
    didReq: '10',
    country: 'India',
    city: 'New Delhi',
    price: '£15',
    type: 'Dedicated',
    reqDate: '11/02/2018',
    status: 'Request Sent',
  },
  {
    id: 8,
    request: '020614',
    didReq: '15',
    country: 'India',
    city: 'Noida',
    price: '£25',
    type: 'Global',
    reqDate: '19/01/2018',
    status: 'Request Declined',
  },
  {
    id: 9,
    request: '090889',
    didReq: '10',
    country: 'India',
    city: 'New Delhi',
    price: '£15',
    type: 'Dedicated',
    reqDate: '11/02/2018',
    status: 'Request Confirmed',
  },
  {
    id: 10,
    request: '020614',
    didReq: '15',
    country: 'India',
    city: 'Noida',
    price: '£25',
    type: 'Global',
    reqDate: '19/01/2018',
    status: 'Request in Process',
  },
  {
    id: 11,
    request: '090889',
    didReq: '10',
    country: 'India',
    city: 'New Delhi',
    price: '£15',
    type: 'Dedicated',
    reqDate: '11/02/2018',
    status: 'Request Confirmed',
  },
  {
    id: 12,
    request: '020614',
    didReq: '15',
    country: 'India',
    city: 'Noida',
    price: '£25',
    type: 'Global',
    reqDate: '19/01/2018',
    status: 'Request Fulfilled',
  },
];
// Other file call
class RequestTracking extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      list: list
    };
    this.handleClick = this.handleClick.bind(this);
  }

  handleClick(item) {
    let updatedList = this.state.list.map(obj => {
      if (obj.id === item.id) {
        return Object.assign({}, obj, {
          hidden: !item.hidden
        });
      }
      return obj;
    });
    this.setState({
      list: updatedList,
    });
  }

  render() {
    return (
      <div className="ibox">
        <div className="ibox-title pt-5 pb-5">
          <h5>DID Request Tracking</h5>
        </div>
        <div className="ibox-content">
          <Row className="gTable-new">
            <Table responsive className="table-bordered">
              <thead>
                <tr>
                  <th width="10%">Request No.</th>
                  <th># of DID Required</th>
                  <th>Country</th>
                  <th>City</th>
                  <th>Price</th>
                  <th>Type</th>
                  <th>Requested Date</th>
                  <th>Tracking Status</th>
                </tr>
              </thead>
              <tbody>
                {this.state.list.map(item =>
                  <tr key={item.itemId}>
                    <td>{item.request}</td>
                    <td>{item.didReq}</td>
                    <td>{item.country}</td>
                    <td>{item.city}</td>
                    <td>{item.price}</td>
                    <td>{item.type}</td>
                    <td>{item.reqDate}</td>
                    <td className={item.status==='Request Declined' ? 'text-danger':'text-info'}>{item.status}</td>
                  </tr>
                )}
              </tbody>
            </Table>
          </Row>
          <Row>
            {/*<Col md={6} className="allentries">
               Showing 1 to 1 of 1 entries 
            </Col>*/}
            <Col md={12}>
              <div className="table-pag">
                <Pagination
                  first='fast_rewind'
                  next='play_arrow'
                  prev='play_arrow'
                  last='fast_forward'
                  ellipsis
                  boundaryLinks
                  items={5}
                  maxButtons={5}
                />
              </div>
            </Col>
          </Row>
        </div>
      </div>
    );
  }
}

export default RequestTracking;