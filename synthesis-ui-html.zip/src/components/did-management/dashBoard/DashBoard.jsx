import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';

// Other file call
import DashLeftMenu from '../../dashleft';
import DashRightMenu from '../../dashright';
import CallDetailsRecord from '../cdr';
import Purchased from '../purchased';
import Request from '../request';
import RequestTracking from '../request-tracking';
import Support from '../support';

class MiddleSection extends React.Component {
  render() {
    return (
      <div className="container-flud">
        <div className="mainArea">
          <DashLeftMenu />
          <div className="middleArea">
            <Switch>
              <div>
                <Route exact path="/did-management/call-details-record" component={CallDetailsRecord} />
                <Route exact path="/did-management/purchased" component={Purchased} />
                <Route exact path="/did-management/request" component={Request} />
                <Route exact path="/did-management/request-tracking" component={RequestTracking} />
                <Route exact path="/did-management/support" component={Support} />
              </div>
            </Switch>
            <div className="clearfix"></div>
          </div>
          <DashRightMenu />
        </div>
      </div>
    );
  }
}

export default MiddleSection;