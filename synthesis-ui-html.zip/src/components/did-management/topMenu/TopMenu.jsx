import React from 'react';
import Switch from 'react-switch_case'
import { Button, Navbar, Nav, NavItem, NavDropdown, DropdownButton, FormGroup, MenuItem, FormControl, Col } from 'react-bootstrap';
import { IndexLinkContainer } from 'react-router-bootstrap';
import {
  Link
} from 'react-router-dom'
//import './topMenu.scss';
let Case = Switch.Case

class AcTopMenu extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      popoverMenu: false,
      subNavbar: false,
      subSubNavbar: false,
      subMenu: ''
    };
    this.popoverShow = this.popoverShow.bind(this);
    this.popoverHide = this.popoverHide.bind(this);
    this.subNavbar = this.subNavbar.bind(this);
    this.subSubNavbar = this.subSubNavbar.bind(this);
  }
  popoverShow() {
    this.setState({
      popoverMenu: true
    });
  }
  popoverHide() {
    this.setState({
      popoverMenu: false
    });
  }

  subNavbar() {
    // let subNavbar = this.state.subNavbar ? false : true;
    this.setState({
      subNavbar: !this.state.subNavbar
    })
  }

  subSubNavbar(target) {
    this.setState({
      subMenu: target
    })
  }

  render() {
    return (
      <div className="navigation">
        <Navbar collapseOnSelect className="nav-audioConf">
          <Navbar.Collapse>
            <Nav>
              <Navbar.Brand>
                <Link to="/"><img src="/images/logo.png" alt="Synthesis Dashboard" /></Link>
                <span onClick={() => { this.subNavbar() }}><i className="icon-app pointer"></i></span>
              </Navbar.Brand>
              <Navbar.Toggle />
            </Nav>
            <Navbar.Header>
              <h1>DID MANAGEMENT</h1>
            </Navbar.Header>
            <div className="nav navbar-nav navbar-right">
              <FormGroup controlId="formBasicText" className={!this.state.popoverMenu ? "btnGroup" : "btnGroup focus"}>
                <form name="search-message" onSubmit={this.props.handleSearch} autoComplete="off">
                  <FormControl type="text" name="searchInput" placeholder="Search" onBlur={this.popoverHide} value={this.state.search} onFocus={this.popoverShow}></FormControl>
                  <span className="form-control-feedback material-icons">search</span>
                </form>
              </FormGroup>
              <Nav>
                <NavDropdown eventKey={1}
                  title={
                    <img src='/images/avatar.png' alt="Avatar" />
                  } id="user-dropdown">
                  <MenuItem eventKey={1.1}>Action</MenuItem>
                  <MenuItem eventKey={1.2}>Another action</MenuItem>
                  <MenuItem eventKey={1.3}>Something else here</MenuItem>
                  <MenuItem divider />
                  <MenuItem eventKey={1.4}>Separated link</MenuItem>
                </NavDropdown>
                <NavItem eventKey={2} href="/"><i className="icon-notifications"></i></NavItem>
                <NavItem eventKey={3} href="/"><i className="icon-settings"></i></NavItem>
              </Nav>
            </div>
          </Navbar.Collapse>
        </Navbar>
        {!this.state.subNavbar &&
          <Navbar collapseOnSelect className="nav-audioConf bottom">
            <Navbar.Collapse>
              <Nav>
                <IndexLinkContainer to="/did-management">
                  <NavItem eventKey={1}>Dashboard</NavItem>
                </IndexLinkContainer>
                <IndexLinkContainer to="/did-management/request">
                  <NavItem eventKey={1}>
                    <i className="material-icons">add_circle_outline</i> Request DID
                  </NavItem>
                </IndexLinkContainer>
                <IndexLinkContainer to="/did-management/purchased">
                  <NavItem eventKey={1}>
                    <i className="material-icons">add_circle_outline</i> Purchased DID
                  </NavItem>
                </IndexLinkContainer>
                <IndexLinkContainer to="/did-management/request-tracking">
                  <NavItem eventKey={1}>
                    <i className="material-icons">add_circle_outline</i> DID Request Tracking
                  </NavItem>
                </IndexLinkContainer>
                <IndexLinkContainer to="/did-management/call-details-record">
                  <NavItem eventKey={1}>
                    <i className="material-icons">add_circle_outline</i> Call Details Record
                  </NavItem>
                </IndexLinkContainer>
                <IndexLinkContainer to="/did-management/support">
                  <NavItem eventKey={1}>
                    <i className="material-icons">add_circle_outline</i> Support
                  </NavItem>
                </IndexLinkContainer>
                
                {/* <NavItem eventKey={2} onClick={() => { this.subSubNavbar('ac_management') }}>
                  <i className="material-icons">add_circle_outline</i> Request DID
                </NavItem>
                <NavItem eventKey={2}>
                  <i className="material-icons">add_circle_outline</i> Purchased DID
                </NavItem>
                <NavItem eventKey={2}>
                  <i className="material-icons">add_circle_outline</i> DID Request Tracking
                </NavItem>
                <NavItem eventKey={2} onClick={() => { this.subSubNavbar('audio_management') }}>
                  <i className="material-icons">add_circle_outline</i> Call Details Record
                </NavItem>
                <NavItem eventKey={2}>
                  <i className="material-icons">add_circle_outline</i> Support
                </NavItem> */}
              </Nav>
            </Navbar.Collapse>
            <Switch value={this.state.subMenu}>
              <Case value="ac_management">
                <Navbar.Collapse className="thirdlevelMenu">
                  <Nav>
                    <IndexLinkContainer to="/audio/account-management/create-new-conference">
                      <NavItem eventKey={3}>
                        Create New Conference
                      </NavItem>
                    </IndexLinkContainer>
                    <IndexLinkContainer to="/audio/account-management/conference-list">
                      <NavItem eventKey={3}>
                        Conference list
                      </NavItem>
                    </IndexLinkContainer>
                    <IndexLinkContainer to="/">
                      <NavItem eventKey={3}>
                        Conference Report
                      </NavItem>
                    </IndexLinkContainer>
                    <IndexLinkContainer to="/">
                      <NavItem eventKey={3}>
                        Live Conference
                      </NavItem>
                    </IndexLinkContainer>
                    <IndexLinkContainer to="/">
                      <NavItem eventKey={3}>
                        Conference Schedule
                      </NavItem>
                    </IndexLinkContainer>
                    <IndexLinkContainer to="/audio/account-management/associated-numbers">
                      <NavItem eventKey={3}>
                        Associated Numbers
                      </NavItem>
                    </IndexLinkContainer>
                    <IndexLinkContainer to="/">
                      <NavItem eventKey={3}>
                        Dialout rates
                      </NavItem>
                    </IndexLinkContainer>
                    <IndexLinkContainer to="/">
                      <NavItem eventKey={3}>
                        Outbound Simulator
                      </NavItem>
                    </IndexLinkContainer>
                  </Nav>
                </Navbar.Collapse>
              </Case>
              <Case value="audio_management">
                <Navbar.Collapse className="thirdlevelMenu">
                  <Nav>
                    <IndexLinkContainer to="/dashboard">
                      <NavItem eventKey={1}>
                        Welcome Audio Message
                      </NavItem>
                    </IndexLinkContainer>
                    <IndexLinkContainer to="/audio/audio-management/welcome-audio-msg-list">
                      <NavItem eventKey={2}>
                        Welcome Audio Message List
                      </NavItem>
                    </IndexLinkContainer>
                    <IndexLinkContainer to="/dashboard">
                      <NavItem eventKey={3}>
                        Add In Call Audio Message
                      </NavItem>
                    </IndexLinkContainer>
                    <IndexLinkContainer to="/audio/audio-management/list-in-call-audio-message-list">
                      <NavItem eventKey={4}>
                        List In Call Audio Message
                      </NavItem>
                    </IndexLinkContainer>
                  </Nav>
                </Navbar.Collapse>
              </Case>
            </Switch>

          </Navbar>}
      </div>
    )
  }
}

export default AcTopMenu;