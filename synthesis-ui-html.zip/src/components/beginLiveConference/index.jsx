import React from 'react';
import Switch from 'react-switch_case'
import { Row, Col, Grid, FormGroup, InputGroup, FormControl,  } from 'react-bootstrap';
import { Scrollbars } from 'react-custom-scrollbars';
import { Link } from 'react-router-dom';
// Other file call
import './beginLiveConference.scss';

let Case = Switch.Case

class BeginLiveConference extends React.Component {

  constructor(props, contex) {
    super(props, contex)
    this.state = {
      tab: 'contacts'
    }
    this.changeTab = this.changeTab.bind(this);
  }

  changeTab(type) {
    this.setState({
      tab: type
    })
  }

  render() {
    return (
      <div className="video-section">
        <header className="online-head">
          <Col md={4}>
            <Link to="/dashboard"><img src="/images/logo.png" alt="Synthesis Dashboard" /></Link>
          </Col>
          <Col md={4} className="text-center">
            <p>Weekly Video Conference Call</p>
          </Col>
          <Col md={4} className="text-right">
            <div className="end-conf">
              <button className="btn btn-default">End Conference</button>
            </div>
            <div className="v-time">
              13 Participants
              <b>08:48</b>
            </div>            
          </Col>
        </header>
        <div className="online-body flex flex-row structure">
          <Col md={8} className="member-video">
            <Row>
              <Col md={6}>
                <div className="live-video">
                  <img src="/images/videoConf-img1.jpg" alt="Video Image" />
                  <div className="video-tab">
                    <ul>
                      <li><i class="material-icons">mic_off</i></li>
                      <li><i class="material-icons">aspect_ratio</i></li>
                      <li><i class="material-icons">person_add</i></li>
                      <li><i class="material-icons">pan_tool</i></li>
                    </ul>
                  </div>
                </div>
              </Col>
              <Col md={3}>
                <div className="live-video">
                  <img src="/images/videoConf-img2.jpg" alt="Video Image" />
                  <div className="video-tab">
                    <p>Manish Badola</p>
                  </div>
                </div>
              </Col>
              <Col md={3}>
                <div className="live-video">
                  <img src="/images/videoConf-img3.jpg" alt="Video Image" />
                  <div className="video-tab">
                    <p>Bharat Singh</p>
                  </div>
                </div>
              </Col>
              <Col md={3}>
                <div className="live-video">
                  <img src="/images/videoConf-img4.jpg" alt="Video Image" />
                  <div className="video-tab">
                    <p>Shamim Saifi</p>
                  </div>
                </div>
              </Col>
              <Col md={3}>
                <div className="live-video">
                  <img src="/images/videoConf-img5.jpg" alt="Video Image" />
                  <div className="video-tab">
                    <p>Pradeep Kaushal</p>
                  </div>
                </div>
              </Col>
            </Row>

            <Row>
              <Col md={3}>
                <div className="live-video">
                  <img src="/images/videoConf-img6.jpg" alt="Video Image" />
                  <div className="video-tab">
                    <p>Mellisa Simpson</p>
                  </div>
                </div>
              </Col>
              <Col md={3}>
                <div className="live-video">
                  <img src="/images/videoConf-img7.jpg" alt="Video Image" />
                  <div className="video-tab">
                    <p>Ganga Singh Thakur</p>
                  </div>
                </div>
              </Col>
              <Col md={3}>
                <div className="live-video">
                  <img src="/images/videoConf-img8.jpg" alt="Video Image" />
                  <div className="video-tab">
                    <p>Vaishali Srivastava</p>
                  </div>
                </div>
              </Col>
              <Col md={3}>
                <div className="live-video">
                  <img src="/images/videoConf-img9.jpg" alt="Video Image" />
                  <div className="video-tab">
                    <p>Ashwani Singh</p>
                  </div>
                </div>
              </Col>
              <Col md={3}>
                <div className="live-video">
                  <img src="/images/videoConf-img10.jpg" alt="Video Image" />
                  <div className="video-tab">
                    <p>Ankit Lakhera</p>
                  </div>
                </div>
              </Col>
              <Col md={3}>
                <div className="live-video">
                  <img src="/images/videoConf-img11.jpg" alt="Video Image" />
                  <div className="video-tab">
                    <p>Lazar Seid</p>
                  </div>
                </div>
              </Col>
              <Col md={3}>
                <div className="live-video">
                  <img src="/images/videoConf-img12.jpg" alt="Video Image" />
                  <div className="video-tab">
                    <p>Abdur Siddiqui</p>
                  </div>
                </div>
              </Col>
              <Col md={3}>
                <div className="live-video">
                  <img src="/images/videoConf-img13.jpg" alt="Video Image" />
                  <div className="video-tab">
                    <p>Anlella White</p>
                  </div>
                </div>
              </Col>
            </Row>

          </Col>
          <Col md={4} className="video-chat">
            <div className="chat-menu">
              <ul>
                <li onClick={() => { this.changeTab('contacts') }}
                  className={
                    this.state.tab === 'contacts' ? 'active' : ''
                  }><span><i class="material-icons">portrait</i></span></li>
                <li onClick={() => { this.changeTab('groups') }}
                  className={
                    this.state.tab === 'groups' ? 'active' : ''
                  }><span><i class="material-icons">people</i></span></li>
                <li onClick={() => { this.changeTab('chat') }}
                  className={
                    this.state.tab === 'chat' ? 'active' : ''
                  }><span><i class="material-icons">question_answer</i></span></li>
                <li onClick={() => { this.changeTab('drop') }}
                  className={
                    this.state.tab === 'drop' ? 'active' : ''
                  }><span><i class="material-icons">airplay</i></span></li>
              </ul>
            </div>
            <Switch value={this.state.tab}>
              <Case value="contacts">
                <div className="chat-detailpage">
                  <Col md={12} className="chatHead">
                    <h2>Contacts</h2>
                    <FormGroup>
                      <InputGroup>
                        <FormControl type="text" placeholder="Search" />
                        <InputGroup.Addon>
                          <i className="fa fa-search"></i>
                        </InputGroup.Addon>
                      </InputGroup>
                    </FormGroup>
                  </Col>
                  <ul className="contact">
                    <li>
                      <a href="#">Ankit Lakhera <i class="material-icons">videocam</i></a>
                    </li>
                    <li>
                      <a href="#">Ganga Singh Thakur <i class="material-icons">videocam</i></a>
                    </li>
                    <li>
                      <a href="#">Manish Badola <i class="material-icons">videocam</i></a>
                    </li>
                    <li>
                      <a href="#">Bharat Singh Negi <i class="material-icons">videocam</i></a>
                    </li>
                    <li>
                      <a href="#">Ashwani Kumar <i class="material-icons">videocam</i></a>
                    </li>
                    <li>
                      <a href="#">Pradeep Kumar Kaushal <i class="material-icons">videocam</i></a>
                    </li>
                    <li>
                      <a href="#">Shamim Saifi <i class="material-icons">videocam</i></a>
                    </li>
                    <li>
                      <a href="#">Abdur Rehman Siddiqui <i class="material-icons">videocam</i></a>
                    </li>
                    <li>
                      <a href="#">Vaisahli Srivastava <i class="material-icons">videocam</i></a>
                    </li>
                  </ul>
                </div>
              </Case>
              
              <Case value="groups">
                <div className="chat-detailpage">
                  <Col md={12} className="chatHead">
                    <h2>Group</h2>
                    <FormGroup>
                      <InputGroup>
                        <FormControl type="text" placeholder="Search" />
                        <InputGroup.Addon>
                          <i className="fa fa-search"></i>
                        </InputGroup.Addon>
                      </InputGroup>
                    </FormGroup>
                  </Col>
                  <ul className="group">
                    <li>
                      <a href="#">Ankit Lakhera <span><i class="material-icons">person</i> <b>8</b></span></a>
                    </li>
                    <li>
                      <a href="#">Ganga Singh Thakur <span><i class="material-icons">person</i> <b>5</b></span></a>
                    </li>
                    <li>
                      <a href="#">Manish Badola <span><i class="material-icons">person</i> <b>4</b></span></a>
                    </li>
                    <li>
                      <a href="#">Bharat Singh Negi <span><i class="material-icons">person</i> <b>10</b></span></a>
                    </li>
                    <li>
                      <a href="#">Ashwani Kumar <span><i class="material-icons">person</i> <b>4</b></span></a>
                    </li>
                    <li>
                      <a href="#">Pradeep Kumar Kaushal <span><i class="material-icons">person</i> <b>2</b></span></a>
                    </li>
                    <li>
                      <a href="#">Shamim Saifi <span><i class="material-icons">person</i> <b>4</b></span></a>
                    </li>
                    <li>
                      <a href="#">Abdur Rehman Siddiqui <span><i class="material-icons">person</i> <b>9</b></span></a>
                    </li>
                    <li>
                      <a href="#">Vaisahli Srivastava <span><i class="material-icons">person</i> <b>8</b></span></a>
                    </li>
                  </ul>
                </div>
              </Case>
              
              <Case value="chat">
                <div className="chat-detailpage">
                  <Col md={12} className="chatHead">
                    <h2>Conversation</h2>
                  </Col>
                  <Col md={12} className="chatArea">
                    <Scrollbars className="overlayScroll"
                      autoHeight
                      autoHeightMin={566}
                    >
                      <div className="bubble-one">
                        <h4>Manish Badola  |  <span>06:28 PM</span></h4>
                        <div className="chattext">
                          <p>Hello Team how are you?</p>
                        </div>
                      </div>
                      <div className="bubble-one">
                        <h4>Manish Badola  |  <span>06:28 PM</span></h4>
                        <div className="chattext">
                          <p>Hello Team how are you?</p>
                        </div>
                      </div>
                      <div className="bubble-one">
                        <h4>Manish Badola  |  <span>06:28 PM</span></h4>
                        <div className="chattext">
                          <p>Hello Team how are you?</p>
                        </div>
                      </div>
                      <div className="bubble-one">
                        <h4>Manish Badola  |  <span>06:28 PM</span></h4>
                        <div className="chattext">
                          <p>Hello Team how are you?</p>
                        </div>
                      </div>
                      <div className="bubble-one">
                        <h4>Manish Badola  |  <span>06:28 PM</span></h4>
                        <div className="chattext">
                          <p>Hello Team how are you?</p>
                        </div>
                      </div>
                      <div className="bubble-one">
                        <h4>Manish Badola  |  <span>06:28 PM</span></h4>
                        <div className="chattext">
                          <p>Hello Team how are you?</p>
                        </div>
                      </div>
                      <div className="bubble-one">
                        <h4>Manish Badola  |  <span>06:28 PM</span></h4>
                        <div className="chattext">
                          <p>Hello Team how are you?</p>
                        </div>
                      </div>
                      <div className="bubble-one">
                        <h4>Manish Badola  |  <span>06:28 PM</span></h4>
                        <div className="chattext">
                          <p>Hello Team how are you?</p>
                        </div>
                      </div>
                      <div className="bubble-one">
                        <h4>Manish Badola  |  <span>06:28 PM</span></h4>
                        <div className="chattext">
                          <p>Hello Team how are you?</p>
                        </div>
                      </div>
                      <div className="bubble-one">
                        <h4>Manish Badola  |  <span>06:28 PM</span></h4>
                        <div className="chattext">
                          <p>Hello Team how are you?</p>
                        </div>
                      </div>
                      <div className="bubble-one">
                        <h4>Manish Badola  |  <span>06:28 PM</span></h4>
                        <div className="chattext">
                          <p>Hello Team how are you?</p>
                        </div>
                      </div>
                      <div className="bubble-one">
                        <h4>Manish Badola  |  <span>06:28 PM</span></h4>
                        <div className="chattext">
                          <p>Hello Team how are you?</p>
                        </div>
                      </div>
                    </Scrollbars>
                  </Col>
                  <Col md={12} className="chatFoot">
                    <ul>
                      <li><a href="#"><i class="material-icons">attach_file</i></a></li>
                      <li><a href="#"><i class="material-icons">note_add</i></a></li>
                      <li><a href="#"><i class="material-icons">photo_size_select_actual</i></a></li>
                      <li><a href="#"><i class="material-icons">music_note</i></a></li>
                      <li><a href="#"><i class="material-icons">mood</i></a></li>
                    </ul>
                    <FormGroup>
                      <FormControl type="text" placeholder="type here..." />
                    </FormGroup>
                  </Col>
                </div>
              </Case>

            </Switch>

          </Col>
        </div>
      </div>
    );
  }
}

export default BeginLiveConference;