import React from 'react';
import './modalBox.scss';

class MyModal extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      cancel: false,
      submit: false,
      modalShow: false
    };
    this.showModal = this.showModal.bind(this);
    this.submit = this.submit.bind(this);
    this.cancel = this.cancel.bind(this);
  }

  showModal() {
    this.setState({
      modalShow: !this.setState.modalShow
    })
  }

  cancel() {
    this.setState({
      cancel: !this.state.cancel,
      modalShow: false
    })
  }

  submit() {
    this.setState({
      submit: !this.state.submit,
      modalShow: false
    })
  }

  render() {
    return (
      <div className={!this.state.modalShow ? 'myModal':'myModal show'}>
        <div className='myModal-content modal-sm'>
          <div className="myModal-header"></div>
          <div className="myModal-body">
            <img src="/images/delete.png" alt="Delete" />
            <p>Are you sure you want to delete this conference?</p>
          </div>
          <div className="myModal-footer">
            <button className="btn btn-submit" onClick={this.submit}>Yes</button>
            <button className="btn btn-cancel" onClick={this.cancel}>Cancel</button>
          </div>
        </div>
        <div  className={!this.state.modalShow ? 'myModal-overlay':'myModal-overlay show'} />
      </div>
    )
  }
}

export default MyModal;