import React from 'react';
import { Row, Col, FormControl, Button } from 'react-bootstrap';
import './loginPage.scss'
import { Link } from 'react-router-dom'
// Other file call

// Javascript code
class LoginScreen extends React.Component {
  render() {
    return (
      <div className="signMain">
        <Col md={7}>
          <div className="signLeft">
            <h2><span>Welcome to</span><br />Synthesis Portal</h2>
            <h3>Smart. Simple. Secure</h3>
            <p>Accelerate business growth and profitability in the cloud with Synthesis. Every application and component of the platform is modularized, customizable and can be easily integrated with APIs.</p>
            <img src="/images/devices.png" alt="" />
          </div>
        </Col>

        <Col md={5}>
          {/* Sign in From */}
          <div className="signUpNew">
            <div className="security">
              <img src="images/norton.png" alt="Norton" />
              <img src="images/truste.png" alt="truste" />
            </div>
            <div className="modal-body">
              <p><img className="img-responsive" src="images/login-logo.png" alt="Asergis Logo" /></p>
              <form role="form" autocomplete="off">
                <Row>
                  <Col md={12} className="m-b">
                    <Link to="/" className="btn btn-linkedin btn-block">
                      <i className="fa fa-linkedin"></i>Login with Linkedin
                    </Link>
                  </Col>
                  <Col md={12} className="m-b">
                    <Link to="/" className="btn btn-facebook btn-block">
                      <i className="fa fa-facebook-square"></i>Login with Facebook
                    </Link>
                  </Col>
                  <Col md={12} className="m-b">
                    <Link to="/" className="btn btn-google btn-block">
                      <i className="fa fa-google-plus"></i>Login with Google
                    </Link>
                  </Col>
                </Row>
                <br />
                <Row>
                  <Col sm={12}>
                    <div className="signTxt">
                      <div className="name">Username</div>
                      <FormControl type="text" />
                    </div>
                  </Col>
                  <Col sm={12}>
                    <div className="signTxt">
                      <div className="name">Password</div>
                      <FormControl type="password" />
                    </div>
                  </Col>
                </Row>

                <div className="signBtnNew">
                  <Link to="/dashboard">
                    <Button type="submit" bsclassName="btn-sub">Sign In</Button>
                  </Link>
                </div>

                <Row>
                  <Col md={6} sm={6}>
                    <div className="checkbox">
                      <input id="checkbox5" type="checkbox" />
                      <label htmlFor="checkbox5" className="remb">Remember me</label>
                    </div>
                  </Col>
                  <Col md={6} sm={6}>
                    <Link to="/" className="signForgot">Forgot Password?</Link>
                  </Col>
                </Row>
              </form>
            </div>
            <div className="info">© 2017 synthesis, inc. All rights reserved.</div>
          </div>
        </Col>
      </div>
    );
  }
}

export default LoginScreen;