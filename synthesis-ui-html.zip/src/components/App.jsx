import React from 'react';
import { BrowserRouter as Router, Route } from 'react-router-dom';
import AudioConferencePage from './Audio-Conferencing-Service';
import DashboardPage from './dashboard/DashboardPage';
import VideoConferencingPage from './Video-Conferencing-Service';
import DidManagement from './did-management';
import LoginScreen from './loginPage';
import BeginLiveConference from './beginLiveConference';

import '../scss/style.scss';

const App = (props) => {
  return (
    <Router>
      <div>
        <Route exact path="/" component={LoginScreen} />
        <Route exact path="/dashboard" component={DashboardPage} />
        <Route path="/audio" component={AudioConferencePage} />
        <Route path="/video" component={VideoConferencingPage} />
        <Route path="/did-management" component={DidManagement} />
        <Route path="/begin-live-conference" component={BeginLiveConference} />
      </div>
    </Router>

  );
}
export default App;
